#ifndef __LOCALIZED
#define __LOCALIZED
#ifdef __cplusplus
extern "C" {
#endif
struct __LString {
   struct __LString *Next;
   int CatalogID;
   char Str[0];
};

void InitStrings(void);
extern struct __LString __LTool__0;
#define msg_0 __LTool__0.Str
extern struct __LString __LTool__1;
#define msg_1 __LTool__1.Str
extern struct __LString __LTool__2;
#define msg_2 __LTool__2.Str
extern struct __LString __LTool__3;
#define msg_3 __LTool__3.Str
extern struct __LString __LTool__4;
#define msg_4 __LTool__4.Str
extern struct __LString __LTool__5;
#define msg_5 __LTool__5.Str
extern struct __LString __LTool__6;
#define msg_6 __LTool__6.Str
extern struct __LString __LTool__7;
#define msg_7 __LTool__7.Str
extern struct __LString __LTool__8;
#define msg_8 __LTool__8.Str
extern struct __LString __LTool__9;
#define msg_9 __LTool__9.Str
extern struct __LString __LTool__10;
#define msg_10 __LTool__10.Str
extern struct __LString __LTool__11;
#define msg_11 __LTool__11.Str
extern struct __LString __LTool__12;
#define msg_12 __LTool__12.Str
extern struct __LString __LTool__13;
#define msg_13 __LTool__13.Str
extern struct __LString __LTool__14;
#define msg_14 __LTool__14.Str
extern struct __LString __LTool__15;
#define msg_15 __LTool__15.Str
extern struct __LString __LTool__16;
#define msg_16 __LTool__16.Str
extern struct __LString __LTool__17;
#define msg_17 __LTool__17.Str
extern struct __LString __LTool__18;
#define msg_18 __LTool__18.Str
extern struct __LString __LTool__19;
#define msg_19 __LTool__19.Str
extern struct __LString __LTool__20;
#define msg_20 __LTool__20.Str
extern struct __LString __LTool__21;
#define msg_21 __LTool__21.Str
extern struct __LString __LTool__22;
#define msg_22 __LTool__22.Str
extern struct __LString __LTool__23;
#define msg_23 __LTool__23.Str
extern struct __LString __LTool__24;
#define msg_24 __LTool__24.Str
extern struct __LString __LTool__25;
#define msg_25 __LTool__25.Str
extern struct __LString __LTool__26;
#define msg_26 __LTool__26.Str
extern struct __LString __LTool__27;
#define msg_27 __LTool__27.Str
extern struct __LString __LTool__28;
#define msg_28 __LTool__28.Str
extern struct __LString __LTool__29;
#define msg_29 __LTool__29.Str
extern struct __LString __LTool__30;
#define msg_30 __LTool__30.Str
extern struct __LString __LTool__31;
#define msg_31 __LTool__31.Str
extern struct __LString __LTool__32;
#define msg_32 __LTool__32.Str
extern struct __LString __LTool__33;
#define msg_33 __LTool__33.Str
extern struct __LString __LTool__34;
#define msg_34 __LTool__34.Str
extern struct __LString __LTool__35;
#define msg_35 __LTool__35.Str
extern struct __LString __LTool__36;
#define msg_36 __LTool__36.Str
extern struct __LString __LTool__37;
#define msg_37 __LTool__37.Str
extern struct __LString __LTool__38;
#define msg_38 __LTool__38.Str
extern struct __LString __LTool__39;
#define msg_39 __LTool__39.Str
extern struct __LString __LTool__40;
#define msg_40 __LTool__40.Str
extern struct __LString __LTool__41;
#define msg_41 __LTool__41.Str
extern struct __LString __LTool__42;
#define msg_42 __LTool__42.Str
extern struct __LString __LTool__43;
#define msg_43 __LTool__43.Str
extern struct __LString __LTool__44;
#define msg_44 __LTool__44.Str
extern struct __LString __LTool__45;
#define msg_45 __LTool__45.Str
extern struct __LString __LTool__46;
#define msg_46 __LTool__46.Str
extern struct __LString __LTool__47;
#define msg_47 __LTool__47.Str
extern struct __LString __LTool__48;
#define msg_48 __LTool__48.Str
extern struct __LString __LTool__49;
#define msg_49 __LTool__49.Str
extern struct __LString __LTool__50;
#define msg_50 __LTool__50.Str
extern struct __LString __LTool__51;
#define msg_51 __LTool__51.Str
extern struct __LString __LTool__52;
#define msg_52 __LTool__52.Str
extern struct __LString __LTool__53;
#define msg_53 __LTool__53.Str
extern struct __LString __LTool__54;
#define msg_54 __LTool__54.Str
extern struct __LString __LTool__55;
#define msg_55 __LTool__55.Str
extern struct __LString __LTool__56;
#define msg_56 __LTool__56.Str
extern struct __LString __LTool__57;
#define msg_57 __LTool__57.Str
extern struct __LString __LTool__58;
#define msg_58 __LTool__58.Str
extern struct __LString __LTool__59;
#define msg_59 __LTool__59.Str
extern struct __LString __LTool__60;
#define msg_60 __LTool__60.Str
extern struct __LString __LTool__61;
#define msg_61 __LTool__61.Str
extern struct __LString __LTool__62;
#define msg_62 __LTool__62.Str
extern struct __LString __LTool__63;
#define msg_63 __LTool__63.Str
extern struct __LString __LTool__64;
#define msg_64 __LTool__64.Str
extern struct __LString __LTool__65;
#define msg_65 __LTool__65.Str
extern struct __LString __LTool__66;
#define msg_66 __LTool__66.Str
extern struct __LString __LTool__67;
#define msg_67 __LTool__67.Str
extern struct __LString __LTool__68;
#define msg_68 __LTool__68.Str
extern struct __LString __LTool__69;
#define msg_69 __LTool__69.Str
extern struct __LString __LTool__70;
#define msg_70 __LTool__70.Str
extern struct __LString __LTool__71;
#define msg_71 __LTool__71.Str
extern struct __LString __LTool__72;
#define msg_72 __LTool__72.Str
extern struct __LString __LTool__73;
#define msg_73 __LTool__73.Str
extern struct __LString __LTool__74;
#define msg_74 __LTool__74.Str
extern struct __LString __LTool__75;
#define msg_75 __LTool__75.Str
extern struct __LString __LTool__76;
#define msg_76 __LTool__76.Str
extern struct __LString __LTool__77;
#define msg_77 __LTool__77.Str
extern struct __LString __LTool__78;
#define msg_78 __LTool__78.Str
extern struct __LString __LTool__79;
#define msg_79 __LTool__79.Str
extern struct __LString __LTool__80;
#define msg_80 __LTool__80.Str
extern struct __LString __LTool__81;
#define msg_81 __LTool__81.Str
extern struct __LString __LTool__82;
#define msg_82 __LTool__82.Str
extern struct __LString __LTool__83;
#define msg_83 __LTool__83.Str
extern struct __LString __LTool__84;
#define msg_84 __LTool__84.Str
extern struct __LString __LTool__85;
#define msg_85 __LTool__85.Str
extern struct __LString __LTool__86;
#define msg_86 __LTool__86.Str
extern struct __LString __LTool__87;
#define msg_87 __LTool__87.Str
extern struct __LString __LTool__88;
#define msg_88 __LTool__88.Str
extern struct __LString __LTool__89;
#define msg_89 __LTool__89.Str
extern struct __LString __LTool__90;
#define msg_90 __LTool__90.Str
extern struct __LString __LTool__91;
#define msg_91 __LTool__91.Str
extern struct __LString __LTool__92;
#define msg_92 __LTool__92.Str
extern struct __LString __LTool__93;
#define msg_93 __LTool__93.Str
extern struct __LString __LTool__94;
#define msg_94 __LTool__94.Str
extern struct __LString __LTool__95;
#define msg_95 __LTool__95.Str
extern struct __LString __LTool__96;
#define msg_96 __LTool__96.Str
extern struct __LString __LTool__97;
#define msg_97 __LTool__97.Str
extern struct __LString __LTool__98;
#define msg_98 __LTool__98.Str
extern struct __LString __LTool__99;
#define msg_99 __LTool__99.Str
extern struct __LString __LTool__100;
#define msg_100 __LTool__100.Str
extern struct __LString __LTool__101;
#define msg_101 __LTool__101.Str
extern struct __LString __LTool__102;
#define msg_102 __LTool__102.Str
extern struct __LString __LTool__103;
#define msg_103 __LTool__103.Str
extern struct __LString __LTool__104;
#define msg_104 __LTool__104.Str
extern struct __LString __LTool__105;
#define msg_105 __LTool__105.Str
extern struct __LString __LTool__106;
#define msg_106 __LTool__106.Str
extern struct __LString __LTool__107;
#define msg_107 __LTool__107.Str
extern struct __LString __LTool__108;
#define msg_108 __LTool__108.Str
extern struct __LString __LTool__109;
#define msg_109 __LTool__109.Str
extern struct __LString __LTool__110;
#define msg_110 __LTool__110.Str
extern struct __LString __LTool__111;
#define msg_111 __LTool__111.Str
extern struct __LString __LTool__112;
#define msg_112 __LTool__112.Str
extern struct __LString __LTool__113;
#define msg_113 __LTool__113.Str
extern struct __LString __LTool__114;
#define msg_114 __LTool__114.Str
extern struct __LString __LTool__115;
#define msg_115 __LTool__115.Str
extern struct __LString __LTool__116;
#define msg_116 __LTool__116.Str
extern struct __LString __LTool__117;
#define msg_117 __LTool__117.Str
extern struct __LString __LTool__118;
#define msg_118 __LTool__118.Str
extern struct __LString __LTool__119;
#define msg_119 __LTool__119.Str
extern struct __LString __LTool__120;
#define msg_120 __LTool__120.Str
extern struct __LString __LTool__121;
#define msg_121 __LTool__121.Str
extern struct __LString __LTool__122;
#define msg_122 __LTool__122.Str
extern struct __LString __LTool__123;
#define msg_123 __LTool__123.Str
extern struct __LString __LTool__124;
#define msg_124 __LTool__124.Str
extern struct __LString __LTool__125;
#define msg_125 __LTool__125.Str
extern struct __LString __LTool__126;
#define msg_126 __LTool__126.Str
extern struct __LString __LTool__127;
#define msg_127 __LTool__127.Str
extern struct __LString __LTool__128;
#define msg_128 __LTool__128.Str
extern struct __LString __LTool__129;
#define msg_129 __LTool__129.Str
extern struct __LString __LTool__130;
#define msg_130 __LTool__130.Str
extern struct __LString __LTool__131;
#define msg_131 __LTool__131.Str
extern struct __LString __LTool__132;
#define msg_132 __LTool__132.Str
extern struct __LString __LTool__133;
#define msg_133 __LTool__133.Str
extern struct __LString __LTool__134;
#define msg_134 __LTool__134.Str
extern struct __LString __LTool__135;
#define msg_135 __LTool__135.Str
extern struct __LString __LTool__136;
#define msg_136 __LTool__136.Str
extern struct __LString __LTool__137;
#define msg_137 __LTool__137.Str
extern struct __LString __LTool__138;
#define msg_138 __LTool__138.Str
extern struct __LString __LTool__139;
#define msg_139 __LTool__139.Str
extern struct __LString __LTool__140;
#define msg_140 __LTool__140.Str
extern struct __LString __LTool__141;
#define msg_141 __LTool__141.Str
extern struct __LString __LTool__142;
#define msg_142 __LTool__142.Str
extern struct __LString __LTool__143;
#define msg_143 __LTool__143.Str
extern struct __LString __LTool__144;
#define msg_144 __LTool__144.Str
extern struct __LString __LTool__145;
#define msg_145 __LTool__145.Str
extern struct __LString __LTool__146;
#define msg_146 __LTool__146.Str
extern struct __LString __LTool__147;
#define msg_147 __LTool__147.Str
extern struct __LString __LTool__148;
#define msg_148 __LTool__148.Str
extern struct __LString __LTool__149;
#define msg_149 __LTool__149.Str
extern struct __LString __LTool__150;
#define msg_150 __LTool__150.Str
extern struct __LString __LTool__151;
#define msg_151 __LTool__151.Str
extern struct __LString __LTool__152;
#define msg_152 __LTool__152.Str
extern struct __LString __LTool__153;
#define msg_153 __LTool__153.Str
extern struct __LString __LTool__154;
#define msg_154 __LTool__154.Str
extern struct __LString __LTool__155;
#define msg_155 __LTool__155.Str
extern struct __LString __LTool__156;
#define msg_156 __LTool__156.Str
extern struct __LString __LTool__157;
#define msg_157 __LTool__157.Str
extern struct __LString __LTool__158;
#define msg_158 __LTool__158.Str
extern struct __LString __LTool__159;
#define msg_159 __LTool__159.Str
extern struct __LString __LTool__160;
#define msg_160 __LTool__160.Str
extern struct __LString __LTool__161;
#define msg_161 __LTool__161.Str
extern struct __LString __LTool__162;
#define msg_162 __LTool__162.Str
extern struct __LString __LTool__163;
#define msg_163 __LTool__163.Str
extern struct __LString __LTool__164;
#define msg_164 __LTool__164.Str
extern struct __LString __LTool__165;
#define msg_165 __LTool__165.Str
extern struct __LString __LTool__166;
#define msg_166 __LTool__166.Str
extern struct __LString __LTool__167;
#define msg_167 __LTool__167.Str
extern struct __LString __LTool__168;
#define msg_168 __LTool__168.Str
extern struct __LString __LTool__169;
#define msg_169 __LTool__169.Str
extern struct __LString __LTool__170;
#define msg_170 __LTool__170.Str
extern struct __LString __LTool__171;
#define msg_171 __LTool__171.Str
extern struct __LString __LTool__172;
#define msg_172 __LTool__172.Str
extern struct __LString __LTool__173;
#define msg_173 __LTool__173.Str
extern struct __LString __LTool__174;
#define msg_174 __LTool__174.Str
extern struct __LString __LTool__175;
#define msg_175 __LTool__175.Str
extern struct __LString __LTool__176;
#define msg_176 __LTool__176.Str
extern struct __LString __LTool__177;
#define msg_177 __LTool__177.Str
extern struct __LString __LTool__178;
#define msg_178 __LTool__178.Str
extern struct __LString __LTool__179;
#define msg_179 __LTool__179.Str
extern struct __LString __LTool__180;
#define msg_180 __LTool__180.Str
extern struct __LString __LTool__181;
#define msg_181 __LTool__181.Str
extern struct __LString __LTool__182;
extern struct __LString __LTool__182;
#define msg_182 __LTool__182.Str
extern struct __LString __LTool__183;
#define msg_183 __LTool__183.Str
extern struct __LString __LTool__184;
#define msg_184 __LTool__184.Str
extern struct __LString __LTool__185;
#define msg_185 __LTool__185.Str
extern struct __LString __LTool__186;
#define msg_186 __LTool__186.Str
extern struct __LString __LTool__187;
#define msg_187 __LTool__187.Str
extern struct __LString __LTool__188;
#define msg_188 __LTool__188.Str
extern struct __LString __LTool__189;
#define msg_189 __LTool__189.Str
extern struct __LString __LTool__190;
#define msg_190 __LTool__190.Str
extern struct __LString __LTool__191;
#define msg_191 __LTool__191.Str
extern struct __LString __LTool__192;
#define msg_192 __LTool__192.Str
extern struct __LString __LTool__193;
#define msg_193 __LTool__193.Str
extern struct __LString __LTool__194;
#define msg_194 __LTool__194.Str
extern struct __LString __LTool__195;
#define msg_195 __LTool__195.Str
extern struct __LString __LTool__196;
#define msg_196 __LTool__196.Str
extern struct __LString __LTool__197;
#define msg_197 __LTool__197.Str
extern struct __LString __LTool__198;
#define msg_198 __LTool__198.Str
extern struct __LString __LTool__199;
#define msg_199 __LTool__199.Str
extern struct __LString __LTool__200;
#define msg_200 __LTool__200.Str
extern struct __LString __LTool__201;
#define msg_201 __LTool__201.Str
extern struct __LString __LTool__202;
#define msg_202 __LTool__202.Str
extern struct __LString __LTool__203;
#define msg_203 __LTool__203.Str
extern struct __LString __LTool__204;
#define msg_204 __LTool__204.Str
extern struct __LString __LTool__205;
#define msg_205 __LTool__205.Str
extern struct __LString __LTool__206;
#define msg_206 __LTool__206.Str
extern struct __LString __LTool__207;
#define msg_207 __LTool__207.Str
extern struct __LString __LTool__208;
#define msg_208 __LTool__208.Str
extern struct __LString __LTool__209;
#define msg_209 __LTool__209.Str
extern struct __LString __LTool__210;
#define msg_210 __LTool__210.Str
extern struct __LString __LTool__211;
#define msg_211 __LTool__211.Str
extern struct __LString __LTool__212;
#define msg_212 __LTool__212.Str
extern struct __LString __LTool__213;
#define msg_213 __LTool__213.Str
extern struct __LString __LTool__214;
#define msg_214 __LTool__214.Str
extern struct __LString __LTool__215;
#define msg_215 __LTool__215.Str
extern struct __LString __LTool__216;
#define msg_216 __LTool__216.Str
extern struct __LString __LTool__217;
#define msg_217 __LTool__217.Str
extern struct __LString __LTool__218;
#define msg_218 __LTool__218.Str
extern struct __LString __LTool__219;
#define msg_219 __LTool__219.Str
extern struct __LString __LTool__220;
#define msg_220 __LTool__220.Str
extern struct __LString __LTool__221;
#define msg_221 __LTool__221.Str
extern struct __LString __LTool__222;
#define msg_222 __LTool__222.Str
extern struct __LString __LTool__223;
#define msg_223 __LTool__223.Str
extern struct __LString __LTool__224;
#define msg_224 __LTool__224.Str
extern struct __LString __LTool__225;
#define msg_225 __LTool__225.Str
extern struct __LString __LTool__226;
#define msg_226 __LTool__226.Str
extern struct __LString __LTool__227;
#define msg_227 __LTool__227.Str
extern struct __LString __LTool__228;
#define msg_228 __LTool__228.Str
extern struct __LString __LTool__229;
#define msg_229 __LTool__229.Str
extern struct __LString __LTool__230;
#define msg_230 __LTool__230.Str
extern struct __LString __LTool__231;
#define msg_231 __LTool__231.Str
extern struct __LString __LTool__232;
#define msg_232 __LTool__232.Str
extern struct __LString __LTool__233;
#define msg_233 __LTool__233.Str
extern struct __LString __LTool__234;
#define msg_234 __LTool__234.Str
extern struct __LString __LTool__235;
#define msg_235 __LTool__235.Str
extern struct __LString __LTool__236;
#define msg_236 __LTool__236.Str
extern struct __LString __LTool__237;
#define msg_237 __LTool__237.Str
extern struct __LString __LTool__238;
#define msg_238 __LTool__238.Str
extern struct __LString __LTool__239;
#define msg_239 __LTool__239.Str
extern struct __LString __LTool__240;
#define msg_240 __LTool__240.Str
extern struct __LString __LTool__241;
#define msg_241 __LTool__241.Str
extern struct __LString __LTool__242;
#define msg_242 __LTool__242.Str
extern struct __LString __LTool__243;
#define msg_243 __LTool__243.Str
extern struct __LString __LTool__244;
#define msg_244 __LTool__244.Str
extern struct __LString __LTool__245;
#define msg_245 __LTool__245.Str
extern struct __LString __LTool__246;
#define msg_246 __LTool__246.Str
extern struct __LString __LTool__247;
#define msg_247 __LTool__247.Str
extern struct __LString __LTool__248;
#define msg_248 __LTool__248.Str
extern struct __LString __LTool__249;
#define msg_249 __LTool__249.Str
extern struct __LString __LTool__250;
#define msg_250 __LTool__250.Str
extern struct __LString __LTool__251;
#define msg_251 __LTool__251.Str
extern struct __LString __LTool__252;
#define msg_252 __LTool__252.Str
extern struct __LString __LTool__253;
#define msg_253 __LTool__253.Str
extern struct __LString __LTool__254;
#define msg_254 __LTool__254.Str
extern struct __LString __LTool__255;
#define msg_255 __LTool__255.Str
extern struct __LString __LTool__256;
#define msg_256 __LTool__256.Str
extern struct __LString __LTool__257;
#define msg_257 __LTool__257.Str
extern struct __LString __LTool__258;
#define msg_258 __LTool__258.Str
extern struct __LString __LTool__259;
#define msg_259 __LTool__259.Str
extern struct __LString __LTool__260;
#define msg_260 __LTool__260.Str
extern struct __LString __LTool__261;
#define msg_261 __LTool__261.Str
extern struct __LString __LTool__262;
#define msg_262 __LTool__262.Str
extern struct __LString __LTool__263;
#define msg_263 __LTool__263.Str
extern struct __LString __LTool__264;
#define msg_264 __LTool__264.Str
extern struct __LString __LTool__265;
#define msg_265 __LTool__265.Str
extern struct __LString __LTool__266;
#define msg_266 __LTool__266.Str
extern struct __LString __LTool__267;
#define msg_267 __LTool__267.Str
extern struct __LString __LTool__268;
#define msg_268 __LTool__268.Str
extern struct __LString __LTool__269;
#define msg_269 __LTool__269.Str
extern struct __LString __LTool__270;
#define msg_270 __LTool__270.Str
extern struct __LString __LTool__271;
#define msg_271 __LTool__271.Str
extern struct __LString __LTool__272;
#define msg_272 __LTool__272.Str
extern struct __LString __LTool__273;
#define msg_273 __LTool__273.Str
extern struct __LString __LTool__274;
#define msg_274 __LTool__274.Str
extern struct __LString __LTool__275;
#define msg_275 __LTool__275.Str
extern struct __LString __LTool__276;
#define msg_276 __LTool__276.Str
extern struct __LString __LTool__277;
#define msg_277 __LTool__277.Str
extern struct __LString __LTool__278;
#define msg_278 __LTool__278.Str
extern struct __LString __LTool__279;
#define msg_279 __LTool__279.Str
extern struct __LString __LTool__280;
#define msg_280 __LTool__280.Str
extern struct __LString __LTool__281;
#define msg_281 __LTool__281.Str
extern struct __LString __LTool__282;
#define msg_282 __LTool__282.Str
extern struct __LString __LTool__283;
#define msg_283 __LTool__283.Str
#ifdef __cplusplus
}
#endif

#endif
