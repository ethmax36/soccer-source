
#ifndef ETW_VERSION
#ifndef MOBILE_VERSION
    #define ETW_VERSION "4.0"
#else
// this is version 4.0 of ETW but the first mobile one!
#define ETW_VERSION "1.2"
#endif
#endif

