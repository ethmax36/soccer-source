#ifndef CONTROL_TYPES_H
#define CONTROL_TYPES_H

#define CTRL_JOY    0
#define CTRL_JOYPAD    1
#define CTRL_JOY2B    2
#define CTRL_KEY_1    3
#define CTRL_KEY_2    4
#define CTRL_TOUCH    5

#define CONTROLS    (CTRL_TOUCH+2)

#endif
