#include "mytypes.h"

/* Velocita palla asse X */

int16_t velocita_scivolata_x[32]=
{
 /* Velocita' 40 */
        0,
        5,
        9,
        12,
        14,
        16,
        18,
        19,
        20,
        19,
        18,
        16,
        14,
        12,
        9,
        5,
        0,
        -5,
        -8,
        -12,
        -14,
        -16,
        -18,
        -19,
        -20,
        -19,
        -18,
        -16,
        -14,
        -12,
        -8,
        -5,
};

/* Velocita palla asse Y */

int16_t velocita_scivolata_y[32]=
{
     /* Velocita' 40 */
        -20,
        -19,
        -18,
        -16,
        -14,
        -12,
        -8,
        -5,
        0,
        5,
        9,
        12,
        14,
        16,
        18,
        19,
        20,
        19,
        18,
        16,
        14,
        12,
        9,
        5,
        0,
        -5,
        -8,
        -12,
        -14,
        -16,
        -18,
        -19,
};

