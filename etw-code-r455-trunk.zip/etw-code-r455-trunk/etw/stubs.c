#ifndef MOBILE_VERSION

// this stuff is only used by the mobile version
int has_full_version() { return 1; }
void show_ads(int unused) {}
void hide_ads() {}

#endif
