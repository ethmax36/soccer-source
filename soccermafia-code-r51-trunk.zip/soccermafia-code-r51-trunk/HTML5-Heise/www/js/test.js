var url = "http://localhost:1067/api/Pegel";

$.ajax({
    type: "GET",
    url: url,
    data: "",
    contentType: "",
    processData: false,
    dataType: "json",
    success: function(pegel) {
        alert(pegel.length);
    },
    error: function (req, textStatus, errorThrown) {
        alert("Error: " + req.status);
    }
});

function PegelVM(pegel, isFav, onFavChanged) {
    var $self = this;

    $self.PegelId = ko.observable(pegel.PegelId);
    $self.PegelName = ko.observable(pegel.PegelName);
    $self.Gewaesser = ko.observable(pegel.Gewaesser);
    $self.Wasserstand = ko.observable(pegel.Wasserstand);
    $self.Datum = ko.observable(pegel.Datum);
    $self.Meldestufe = ko.observable(pegel.Meldestufe);

    $self.isFav = ko.observable(isFav);

    $self.toggleFav = function () {
        $self.isFav(!$self.isFav());

        if (onFavChanged) onFavChanged($self);

    }

    $self.color = ko.computed(function () {
        switch ($self.Meldestufe()) {
            case 0: return "black";
            case 1: return "orange";
            case 2: return "red";
        }
    });

}