package de.soccermafia.probability;

/**
 * Diese Klasse berechnet die virtuellen Quoten die Basis f�r die Wetteins�tze sind. Sie h�ngen von der H�he des
 * Manipulationsgeldes ab.
 * 
 * <ul>
 * <li>a: Quote f�r Heimsieg (1)
 * <li>b: Quote f�r Unentschieden (0)
 * <li>b: Quote f�r Ausw�rtssieg (2)
 * </ul>
 * 
 * a,b,c werden als gesetzt und fix angesehen. Es sind realistische Werte (z.B. von einem Online Wettabieter) und bilden
 * die Start-Wahrscheinlichkeit f�r den Spielausgang ab.
 * 
 * @author Martin
 */
public class VirtualQuotaCalculator {

    private double a, b, c;

    private int manipulationWish;

    private Function function;

    /**
     * @param a
     *            Startquote f�r Heimsieg
     * @param b
     *            Startquote f�r Unentschieden
     * @param c
     *            Startquote f�r Ausw�rtssieg
     * @param manipulationWish
     *            <ul>
     *            <li>1: Heimsieg
     *            <li>0: Unentschieden
     *            <li>2: Ausw�rtssieg
     *            </ul>
     * @param function
     *            Abstrakte Funktion welche alle Parameter der Kalkulation abbildet
     */
    public VirtualQuotaCalculator(double a, double b, double c, int manipulationWish, Function function) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.function = function;
        this.manipulationWish = manipulationWish;
    }

    /**
     * Berechnet die Ma�zahl zur Ver�nderung der virtuellen Quoten f�r 0,2 abh�ngig von der Ma�zahl f�r 1
     * 
     * @param x
     * @return
     */
    private double calculate02(double x) {
        return (((a * b * c) - (x * b * c)) / ((a * c) + (a * b)));
    }

    /**
     * Berechnet die Ma�zahl zur Ver�nderung der virtuellen Quoten f�r 1,2 abh�ngig von der Ma�zahl f�r 0
     * 
     * @param x
     * @return
     */
    private double calculate12(double x) {
        return (((a * b * c) - (x * a * c)) / ((a * b) + (b * c)));
    }

    /**
     * Berechnet die Ma�zahl zur Ver�nderung der virtuellen Quoten f�r 1,0 abh�ngig von der Ma�zahl f�r 2
     * 
     * @param x
     * @return
     */
    private double calculate10(double x) {
        return (((a * b * c) - (x * a * b)) / ((a * c) + (b * c)));
    }

    @Override
    public String toString() {
        return "VirtualQuotaCalculator [a=" + a + ", b=" + b + ", c=" + c + ", manipulationWish=" + manipulationWish
                + ", function=" + function + "]";
    }

    /**
     * Berechnet die neuen Quoten auf Basis der gesetzen Parameter.
     * 
     * @return {@link VirtualQuotas}
     */
    public VirtualQuotas calculateNewVirtualQuotas() {

        // x: Ma�zahl um die die Wahrscheinlichkeit zu meinen Gunsten �ndert; nie gr��er als die aktuelle virtuelle
        // Quote, da x/a sonst kleiner 1
        double x = function.calc();

        // Quote soll nicht kleiner werden; falls Manipulationsbetrag zu gering, keine Ver�nderung
        if (x < 1)
            x = 1;

        // regulieren, dass eine Quote nicht �berdimensionert werden kann; sie kann maximal durch sich selbst geteilt
        // werden, sodass die neue Quote 1.0 entsteht.
        if (manipulationWish == 1) {
            if (getA() < x)
                x = getA() - .0001;
        }
        if (manipulationWish == 0) {
            if (getB() < x)
                x = getB() - .0001;
        }
        if (manipulationWish == 2) {
            if (getC() < x)
                x = getC() - .0001;
        }

        if (manipulationWish == 1) {
            double fX = calculate02(x);
            return new VirtualQuotas(x / a, fX / b, fX / c);
        }
        if (manipulationWish == 0) {
            double fX = calculate12(x);
            return new VirtualQuotas(fX / a, x / b, fX / c);
        }
        if (manipulationWish == 2) {
            double fX = calculate10(x);
            return new VirtualQuotas(fX / a, fX / b, x / c);
        }
        throw new IllegalArgumentException("Illegal Manipulation Wish " + manipulationWish);
    }

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }

}
