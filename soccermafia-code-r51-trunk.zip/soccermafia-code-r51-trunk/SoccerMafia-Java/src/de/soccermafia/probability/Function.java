package de.soccermafia.probability;

/**
 * Dieses Interface modelliert eine abtrakte mathematische Funktion mit beliebigen Parametern und Variablen (weil Java
 * halt nicht Scala ist :-) )
 * 
 *                    
 * atan(.01(x+150) / 6 + 1,25
 *       ^    ^
 * Steilheit  Rechts-Achse
 * 
 * 
 * @author Martin
 * 
 */
public interface Function {

    public double calc();

}
