package de.soccermafia.probability;

public class VirtualQuotas {

    private double a, b, c;

    /**
     * @param a
     *            P(A)
     * @param b
     *            P(B)
     * @param c
     *            P(C)
     */
    VirtualQuotas(double a, double b, double c) {
        this.a = 1 / a;
        this.b = 1 / b;
        this.c = 1 / c;
    }

    /**
     * @return Quote f�r Heimsieg
     */
    public double getA() {
        return a;
    }

    /**
     * @return Quote f�r Unentschieden
     */
    public double getB() {
        return b;
    }

    /**
     * @return Quote f�r Ausw�rtssieg
     */
    public double getC() {
        return c;
    }

    @Override
    public String toString() {
        return "VirtualQuatas [a=" + a + ", b=" + b + ", c=" + c + "]";
    }

}
