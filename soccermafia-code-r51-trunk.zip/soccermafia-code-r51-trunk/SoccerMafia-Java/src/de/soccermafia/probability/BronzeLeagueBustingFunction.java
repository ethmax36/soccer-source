package de.soccermafia.probability;

/**
 * Funktion welche die Wahrscheinlichkeit f�r eine Verhaftung, bzw. versch�fte Beobachtung berechnet. P(Bust) h�ngt von
 * der H�he des Wettbetrages und der H�he des Verschleierungsbetrages ab.
 * 
 * @author Martin
 * 
 */
public class BronzeLeagueBustingFunction implements Function {

    private double fogAmount;

    private double betAmount;

    /**
     * @param betAmount
     *            Wetteinsatz
     * @param fogAmount
     *            Betrag f�r Verschleierung
     */
    public BronzeLeagueBustingFunction(double betAmount, double fogAmount) {
        this.betAmount = betAmount;
        this.fogAmount = fogAmount;
    }

    @Override
    public double calc() {
        double result = (-(fogAmount / 1000) / (Math.sqrt(betAmount / 1000))) + 1;
        // if (result > 1)
        // return 1;
        // if (result < 0)
        // return 0;
        return result;
    }

    @Override
    public String toString() {
        return "BronzeLeagueBustingFunction [fogAmount=" + fogAmount + ", betAmount=" + betAmount + "]";
    }
}
