package de.soccermafia.probability;

/**
 * Funktion zur Berechnung der Auswirkung einer Manipulation auf die virtuelle Quote. Parameter f�r diese Funktion sind
 * der Betrag der Manipulation und die aktuelle virtuella Quote des gew�nschten Ergebnisses. Die Quote ist notwendig, da
 * sichergestellt werden muss, dass die Wahrscheinlichkeit f�r den gew�nschten Ausgang nicht �ber 100% steigt.
 * 
 * @author Martin
 * 
 */
public class BronzeLeagueManipulationFunction implements Function {

    private double amount;

    private double virtualQuota;

    /**
     * @param amount
     *            Betrag f�r Manipulation
     * @param virtualQuota
     *            Aktuelle virtuelle Quote f�r die gew�nschte Manipulation
     */
    public BronzeLeagueManipulationFunction(double amount, double virtualQuota) {
        this.amount = amount;
        this.virtualQuota = virtualQuota;
    }

    @Override
    public double calc() {
        double adds = -1 / Math.sqrt((amount / 1000 / 100));
        // adds kann max 0 sein
        return adds + virtualQuota;
    }

}
