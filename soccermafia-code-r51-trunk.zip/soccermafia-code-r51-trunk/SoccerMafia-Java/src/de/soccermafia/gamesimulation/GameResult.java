package de.soccermafia.gamesimulation;

/**
 * Gruppiert gew�rfelte Tendenz und zuf�llig Ergebnis eines Spiels.
 * 
 * @author Martin
 * 
 */
public class GameResult {

    private int tendency;

    private String score;

    GameResult(int tendency, String score) {
        this.tendency = tendency;
        this.score = score;
    }

    /**
     * <ul>
     * <li>1: Heimsieg</li>
     * <li>0: Unentschieden</li>
     * <li>2: Ausw�rtsieg</li>
     * </ul>
     * 
     * @return 1,0,2
     */
    public int getTendency() {
        return tendency;
    }

    /**
     * Genaues Ergebnis
     * 
     * @return
     */
    public String getScore() {
        return score;
    }

    @Override
    public String toString() {
        return "GameResult [tendency=" + tendency + ", score=" + score + "]";
    }

}
