package de.soccermafia.gamesimulation;

import java.util.ArrayList;
import java.util.List;

import de.soccermafia.probability.VirtualQuotas;

/**
 * Simuliert ein Spiel auf Basis der gegeben virtuellen Quoten. Die Tendenz wird entsprechend den Wahrscheinlichkeiten
 * erw�rfelt.
 * 
 * @author Martin
 * 
 */
public class GameSimulator {

    private static List<String> scores1;

    private static List<String> scores0;

    private static List<String> scores2;

    private VirtualQuotas virtualQuotas;

    static {
        scores1 = new ArrayList<String>();
        scores1.add("1:0");
        scores1.add("2:0");
        scores1.add("2:1");
        scores1.add("3:1");

        scores0 = new ArrayList<String>();
        scores0.add("0:0");
        scores0.add("1:1");
        scores0.add("2:2");
        scores0.add("3:3");

        scores2 = new ArrayList<String>();
        scores2.add("0:1");
        scores2.add("1:2");
        scores2.add("0:2");
        scores2.add("2:3");
    }

    /**
     * @param vq
     *            virtuelle Quote des Spiels
     */
    public GameSimulator(VirtualQuotas vq) {
        this.virtualQuotas = vq;
    }

    /**
     * Simuliert ein Spiel
     * 
     * @return Tendenz und Ergebnis
     */
    public GameResult simulate() {
        // seed = 0..1
        double seed = Math.random();

        double a = 1 / virtualQuotas.getA();
        double b = 1 / virtualQuotas.getB();

        if (0 <= seed && seed < a) {
            // heimsieg gew�rfelt
            String score = randomScore(1);
            return new GameResult(1, score);
        }
        if (a <= seed && seed < a + b) {
            // unentschieden
            String score = randomScore(0);
            return new GameResult(0, score);
        }
        if (seed >= a + b) {
            // ausw�rtssieg gew�rfelt
            String score = randomScore(2);
            return new GameResult(2, score);
        }

        return null;

    }

    /**
     * @param i
     *            Tendenz
     * @return zuf�lliges Ergebnis
     */
    private String randomScore(int i) {
        long currentTimeMillis = System.currentTimeMillis();

        Long mod = (currentTimeMillis % 4);

        switch (i) {
            case 1:
                return scores1.get(mod.intValue());
            case 0:
                return scores0.get(mod.intValue());
            case 2:
                return scores2.get(mod.intValue());
            default:
                throw new IllegalArgumentException("Illegal Game Tendency");
        }
    }
}
