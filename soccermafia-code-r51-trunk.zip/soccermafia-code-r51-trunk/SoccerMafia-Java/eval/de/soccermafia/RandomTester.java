package de.soccermafia;

import org.apache.commons.collections.bag.HashBag;

public class RandomTester {

    private static final int NUMBER_OF_RUNS = 1;

    private final static double NUMBER_OF_EVENTS = 100;

    public static void main(String[] args) {

        HashBag bag = new HashBag();

        for (int c = 0; c < NUMBER_OF_RUNS; c++) {
            int i = Double.valueOf(Math.random() * NUMBER_OF_EVENTS).intValue();
            bag.add(i);
        }

        for (int i = 0; i < NUMBER_OF_EVENTS; i++) {
            int count = bag.getCount(i);
            System.err.println("#" + i + "=" + count);

            double diff = (NUMBER_OF_RUNS / NUMBER_OF_EVENTS) - count;
            System.err.println("Diff=" + diff);
            System.err.println("Abweichung vom Mittelwert=" + (diff / NUMBER_OF_RUNS * 100) + "%");
            System.err.println("=====================================================");
        }
    }
}
