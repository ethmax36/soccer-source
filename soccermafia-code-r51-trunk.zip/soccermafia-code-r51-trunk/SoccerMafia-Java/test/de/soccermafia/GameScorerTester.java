package de.soccermafia;

import junit.framework.Assert;

import org.apache.commons.collections.bag.HashBag;
import org.junit.Test;

import de.soccermafia.gamesimulation.GameResult;
import de.soccermafia.gamesimulation.GameSimulator;
import de.soccermafia.probability.BronzeLeagueManipulationFunction;
import de.soccermafia.probability.VirtualQuotaCalculator;
import de.soccermafia.probability.VirtualQuotas;

public class GameScorerTester {

    @Test
    public void scoreGame() {
        System.out.println("############## scoreGame ############");
        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 1, new BronzeLeagueManipulationFunction(
                99999999999999999999999d, 3.2));

        VirtualQuotas vq = vqc.calculateNewVirtualQuotas();

        GameSimulator gs = new GameSimulator(vq);
        GameResult result = gs.simulate();

        Assert.assertNotNull(result);

        System.out.println(vq);
        System.out.println(result);

    }

    @Test
    public void checkCorrectRandomization1() {
        System.out.println("############## checkCorrectRandomization1 ############");

        HashBag bag = new HashBag();

        for (int i = 0; i < 10000; i++) {

            VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 1,
                    new BronzeLeagueManipulationFunction(0, 3.2));

            VirtualQuotas vq = vqc.calculateNewVirtualQuotas();

            // P(1) = 0,3125
            // P(0) = 0,2625
            // P(2) = 0,4250

            GameSimulator gs = new GameSimulator(vq);
            GameResult result = gs.simulate();
            bag.add(result.getTendency());
        }

        System.out.println("#(1)=" + bag.getCount(1));
        System.out.println("#(0)=" + bag.getCount(0));
        System.out.println("#(2)=" + bag.getCount(2));
    }
    
    @Test
    public void checkCorrectRandomization0() {
        System.out.println("############## checkCorrectRandomization0 ############");

        HashBag bag = new HashBag();

        for (int i = 0; i < 10000; i++) {

            VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 0,
                    new BronzeLeagueManipulationFunction(0, 3.4));

            VirtualQuotas vq = vqc.calculateNewVirtualQuotas();

            // P(1) = 0,2796
            // P(0) = 0,2941
            // P(2) = 0,4261

            GameSimulator gs = new GameSimulator(vq);
            GameResult result = gs.simulate();
            bag.add(result.getTendency());
        }

        System.out.println("#(1)=" + bag.getCount(1));
        System.out.println("#(0)=" + bag.getCount(0));
        System.out.println("#(2)=" + bag.getCount(2));
    }

}
