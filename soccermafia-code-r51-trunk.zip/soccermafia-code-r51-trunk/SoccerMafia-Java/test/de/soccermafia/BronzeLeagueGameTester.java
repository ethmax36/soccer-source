package de.soccermafia;

import org.junit.Test;

import de.soccermafia.probability.BronzeLeagueBustingFunction;
import de.soccermafia.probability.BronzeLeagueManipulationFunction;
import de.soccermafia.probability.VirtualQuotaCalculator;

public class BronzeLeagueGameTester {

    @Test
    public void testit() {
        System.out.println("############## testit ############");

        double manipulationAmount = 150000d;
        double fogAmount = 5000d;
        double betAmount = 100000d;

        BronzeLeagueManipulationFunction manipulationFunction = new BronzeLeagueManipulationFunction(
                manipulationAmount, 3.4);

        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 0, manipulationFunction);
        System.out.println(vqc.calculateNewVirtualQuotas());

        BronzeLeagueBustingFunction bustingFunction = new BronzeLeagueBustingFunction(betAmount, fogAmount);
        System.out.println(bustingFunction.calc());
    }
}
