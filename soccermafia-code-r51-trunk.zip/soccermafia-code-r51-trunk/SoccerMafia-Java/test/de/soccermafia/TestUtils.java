package de.soccermafia;

import junit.framework.Assert;
import de.soccermafia.probability.VirtualQuotaCalculator;
import de.soccermafia.probability.VirtualQuotas;

public class TestUtils {

    public static double getCompleteProbability(VirtualQuotaCalculator vqc) {
        double a = vqc.getA();
        double b = vqc.getB();
        double c = vqc.getC();

        return (1 / a) + (1 / b) + (1 / c);
    }

    public static double getCompleteProbability(VirtualQuotas vq) {
        double a = vq.getA();
        double b = vq.getB();
        double c = vq.getC();

        return (1 / a) + (1 / b) + (1 / c);
    }

    public static void assertCorrectProbabilities(VirtualQuotas vq) {
        double a = vq.getA();
        double b = vq.getB();
        double c = vq.getC();

        if (a == 1) {
            Assert.assertTrue(b == Double.POSITIVE_INFINITY);
            Assert.assertTrue(c == Double.POSITIVE_INFINITY);
        } else if (b == 1) {
            Assert.assertTrue(a == Double.POSITIVE_INFINITY);
            Assert.assertTrue(c == Double.POSITIVE_INFINITY);
        } else if (c == 1) {
            Assert.assertTrue(a == Double.POSITIVE_INFINITY);
            Assert.assertTrue(b == Double.POSITIVE_INFINITY);
        }

        else {
            Assert.assertTrue(1 / a < 1);
            Assert.assertTrue(1 / b < 1);
            Assert.assertTrue(1 / c < 1);
        }
    }

}
