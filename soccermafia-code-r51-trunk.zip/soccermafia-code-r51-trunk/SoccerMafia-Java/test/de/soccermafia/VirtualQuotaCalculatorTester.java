package de.soccermafia;

import org.junit.Test;

import de.soccermafia.probability.BronzeLeagueManipulationFunction;
import de.soccermafia.probability.Function;
import de.soccermafia.probability.VirtualQuotaCalculator;
import de.soccermafia.probability.VirtualQuotas;

public class VirtualQuotaCalculatorTester {

    @Test
    public void contantFunction2() {
        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 1, new Function() {

            @Override
            public double calc() {
                return 2;
            }
        });

        VirtualQuotas vq = vqc.calculateNewVirtualQuotas();
        System.out.println("#####################################################");
        System.out.println(vq);
        System.out.println(TestUtils.getCompleteProbability(vq));
        TestUtils.assertCorrectProbabilities(vq);
    }

    @Test
    public void contantFunction3() {
        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 1, new Function() {

            @Override
            public double calc() {
                return 3;
            }
        });

        VirtualQuotas vq = vqc.calculateNewVirtualQuotas();
        System.out.println("#####################################################");
        System.out.println(vq);
        System.out.println(TestUtils.getCompleteProbability(vq));
        TestUtils.assertCorrectProbabilities(vq);
    }

    @Test
    public void complexFunction1() {
        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 2, new BronzeLeagueManipulationFunction(
                150000, 2.1));

        VirtualQuotas vq = vqc.calculateNewVirtualQuotas();
        System.out.println("#####################################################");
        System.out.println(vq);
        System.out.println(TestUtils.getCompleteProbability(vq));
        TestUtils.assertCorrectProbabilities(vq);
    }

    @Test
    public void complexFunction2() {
        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 2, new BronzeLeagueManipulationFunction(
                400000, 2.1));

        VirtualQuotas vq = vqc.calculateNewVirtualQuotas();
        System.out.println("#####################################################");
        System.out.println(vq);
        System.out.println(TestUtils.getCompleteProbability(vq));
        TestUtils.assertCorrectProbabilities(vq);
    }

    @Test
    public void complexFunction3() {
        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(3.2, 3.4, 2.1, 2, new BronzeLeagueManipulationFunction(
                99999999999999999999999d, 2.1));

        VirtualQuotas vq = vqc.calculateNewVirtualQuotas();
        System.out.println("#####################################################");
        System.out.println(vq);
        System.out.println(TestUtils.getCompleteProbability(vq));
        TestUtils.assertCorrectProbabilities(vq);

    }

    @Test
    public void complexFunction4() {
        VirtualQuotaCalculator vqc = new VirtualQuotaCalculator(4, 4, 1.1, 2, new BronzeLeagueManipulationFunction(
                99999999999999999999999d, 2.1));

        VirtualQuotas vq = vqc.calculateNewVirtualQuotas();
        System.out.println("#####################################################");
        System.out.println(vq);
        System.out.println(TestUtils.getCompleteProbability(vq));
        TestUtils.assertCorrectProbabilities(vq);

    }

}
