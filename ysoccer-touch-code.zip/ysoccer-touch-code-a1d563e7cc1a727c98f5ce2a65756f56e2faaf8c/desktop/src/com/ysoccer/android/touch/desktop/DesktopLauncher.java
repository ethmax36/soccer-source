package com.ysoccer.android.touch.desktop;

import com.badlogic.gdx.Files;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.ysoccer.android.touch.YSoccer;

public class DesktopLauncher {

    public static void main(String[] arg) {
        LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
        config.width = 2220;
        config.height = 1080;
        config.forceExit = false;
        config.addIcon("images/icon_128.png", Files.FileType.Internal);
        config.addIcon("images/icon_32.png", Files.FileType.Internal);
        new LwjglApplication(new YSoccer(), config);
    }
}
