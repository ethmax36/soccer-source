package com.ysoccer.android.touch;

import android.content.res.Configuration;
import android.os.Bundle;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import com.ysoccer.android.framework.GLGame;

public class AndroidLauncher extends AndroidApplication {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
        initialize(new YSoccer(), config);
    }

    @Override
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (config.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_NO
                || config.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES) {
            GLGame.inputConfigurationChanged = true;
        }
    }
}
