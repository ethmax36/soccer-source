package com.ysoccer.android.competitions;

import com.ysoccer.android.match.Match;
import com.ysoccer.android.match.Team;

import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;

public class Friendly extends Competition {

    private final Match match;

    public Friendly(String name, Team homeTeam, Team awayTeam) {
        super(Type.FRIENDLY);

        numberOfTeams = 2;

        this.name = name;
        teams.add(homeTeam);
        teams.add(awayTeam);

        match = new Match();
        match.teams[HOME] = 0;
        match.teams[AWAY] = 1;

        weather = Competition.Weather.BY_PITCH_TYPE;
    }

    @Override
    public Match getMatch() {
        return match;
    }

    @Override
    public void onMatchInterrupted() {
    }

    @Override
    public void onMatchCompleted() {
    }
}