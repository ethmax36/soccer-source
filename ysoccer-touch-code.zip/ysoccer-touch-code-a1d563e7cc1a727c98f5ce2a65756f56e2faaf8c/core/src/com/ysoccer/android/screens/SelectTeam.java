package com.ysoccer.android.screens;

import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Widget;
import com.ysoccer.android.match.Team;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class SelectTeam extends GLScreen {

    SelectTeam(GLGame game) {
        super(game);
        background = "images/backgrounds/menu_match.jpg";

        Widget w;

        w = new TitleBar(game.gettext("CHOOSE TEAMS FOR") + " " + game.gettext(game.competition.name), game.stateColor);
        widgets.add(w);

        w = new ComputerButton();
        widgets.add(w);

        w = new ComputerLabel();
        widgets.add(w);

        w = new PlayerButton();
        widgets.add(w);

        w = new PlayerLabel();
        widgets.add(w);

        game.competition.loadTeams();

        List<Widget> list = new ArrayList<Widget>();
        for (Team team : game.competition.teams) {
            w = new TeamButton(team);
            list.add(w);
            widgets.add(w);
        }

        if (list.size() > 0) {
            Collections.sort(list, Widget.widgetComparatorByText);
            Widget.arrange(gui.WIDTH, 290, 30, list);
            setSelectedWidget(list.get(0));
        }

        w = new ExitButton();
        widgets.add(w);

        w = new ContinueButton();
        widgets.add(w);
    }

    private class ComputerButton extends Button {

        ComputerButton() {
            setGeometry(gui.WIDTH / 2 - 300, 80, 60, 26);
            setColors(0x981E1E, 0xC72929, 0x640000);
            setActive(false);
        }
    }

    private class ComputerLabel extends Button {

        ComputerLabel() {
            setGeometry(gui.WIDTH / 2 - 300 + 80, 80, 180, 26);
            setText(game.gettext("CONTROL MODE.COMPUTER"), Font.Align.LEFT, game.font14);
            setActive(false);
        }
    }

    private class PlayerButton extends Button {

        PlayerButton() {
            setGeometry(gui.WIDTH / 2 + 40, 80, 60, 26);
            setColors(0x0000C8, 0x1919FF, 0x000078);
            setActive(false);
        }
    }

    private class PlayerLabel extends Button {

        PlayerLabel() {
            setGeometry(gui.WIDTH / 2 + 40 + 80, 80, 180, 26);
            setText(game.gettext("CONTROL MODE.PLAYER"), Font.Align.LEFT, game.font14);
            setActive(false);
        }
    }

    private class TeamButton extends Button {

        Team team;

        TeamButton(Team team) {
            setSize(300, 28);
            setText(game.gettext("NAMES." + team.name), Font.Align.CENTER, game.font14);
            this.team = team;
        }

        @Override
        public void refresh() {
            switch (team.controlMode) {
                case COMPUTER:
                    setColors(0x981E1E, 0xC72929, 0x640000);
                    break;

                case PLAYER:
                    setColors(0x0000C8, 0x1919FF, 0x000078);
                    break;
            }
        }

        @Override
        public void onFire1Down() {
            for (Team team : game.competition.teams) {
                team.controlMode = Team.ControlMode.COMPUTER;
            }
            team.controlMode = Team.ControlMode.PLAYER;
            refreshAllWidgets();
        }
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH) / 2 - 300 - 30, gui.HEIGHT - 40 - 20, 300, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            clearAndExit();
        }
    }

    @Override
    protected void onKeyBack() {
        clearAndExit();
    }

    private void clearAndExit() {
        game.clearCompetition();
        game.setScreen(new Main(game));
    }

    private class ContinueButton extends Button {

        ContinueButton() {
            setGeometry(gui.WIDTH / 2 + 30, gui.HEIGHT - 40 - 20, 340, 40);
            setText(game.gettext("CONTINUE"), Font.Align.CENTER, game.font14);
        }

        @Override
        public void refresh() {
            setActive(false);
            setColor(0x666666);
            for (Team team : game.competition.teams) {
                if (team.controlMode == Team.ControlMode.PLAYER) {
                    setActive(true);
                    setColor(0x2D855D);
                    break;
                }
            }
        }

        @Override
        protected void onFire1Up() {
            game.competition.start();
            game.setScreen(new PlayCup(game));
        }
    }
}
