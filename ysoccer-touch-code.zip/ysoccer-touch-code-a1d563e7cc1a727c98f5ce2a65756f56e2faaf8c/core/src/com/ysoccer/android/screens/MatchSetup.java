package com.ysoccer.android.screens;

import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.framework.InputDevice;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Gui;
import com.ysoccer.android.gui.Widget;
import com.ysoccer.android.match.Match;
import com.ysoccer.android.match.MatchSettings;
import com.ysoccer.android.match.Pitch;
import com.ysoccer.android.match.Team;
import com.ysoccer.android.framework.EMath;

import java.util.ArrayList;

import static com.ysoccer.android.competitions.Competition.Type.FRIENDLY;
import static com.ysoccer.android.framework.Font.Align.CENTER;
import static com.ysoccer.android.framework.Font.Align.RIGHT;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;

class MatchSetup extends GLScreen {

    private final MatchSettings matchSettings;
    private final TimePicture timePicture;
    private final PitchTypePicture pitchTypePicture;
    private final WeatherButton weatherButton;
    private final WeatherPicture weatherPicture;
    private final ArrayList<KitIndicator>[] kitIndicators = new ArrayList[2];

    public MatchSetup(GLGame game) {
        super(game);

        background = "images/backgrounds/menu_match.jpg";

        Match match = navigation.competition.getMatch();

        Team.kitAutoSelection(match.team[HOME], match.team[AWAY]);

        matchSettings = new MatchSettings(navigation.competition, game.settings);

        Widget w;

        w = new TitleBar(navigation.competition.getMenuTitle(game), game.stateColor);
        widgets.add(w);

        w = new TimeLabel();
        widgets.add(w);

        timePicture = new TimePicture();
        widgets.add(timePicture);

        w = new TimeButton();
        widgets.add(w);

        w = new PitchTypeLabel();
        widgets.add(w);

        pitchTypePicture = new PitchTypePicture();
        widgets.add(pitchTypePicture);

        w = new PitchTypeButton();
        widgets.add(w);

        w = new WeatherLabel();
        widgets.add(w);

        weatherPicture = new WeatherPicture();
        widgets.add(weatherPicture);

        weatherButton = new WeatherButton();
        widgets.add(weatherButton);

        for (int t = HOME; t <= AWAY; t++) {
            w = new TeamNameButton(match.team[t]);
            widgets.add(w);

            w = new KitPicture(match.team[t]);
            widgets.add(w);

            kitIndicators[t] = new ArrayList<>();
            for (int i = 0; i < match.team[t].kits.size(); i++) {
                KitIndicator k = new KitIndicator(match.team[t], i);
                kitIndicators[t].add(k);
                widgets.add(k);
            }

            w = new ControlsButton(match.team[t]);
            widgets.add(w);
        }

        w = new PlayMatchButton();
        widgets.add(w);

        setSelectedWidget(w);

        w = new ExitButton();
        widgets.add(w);
    }

    private class TimeLabel extends Button {

        TimeLabel() {
            setColor(0x800000);
            setGeometry(gui.WIDTH / 2 - 300 + 25, 125 - 40 / 2, 300, 40);
            setText(game.gettext("TIME"), CENTER, game.font14);
            setActive(false);
        }
    }

    private class TimePicture extends Button {

        TimePicture() {
            setColor(0x666666);
            setGeometry(gui.WIDTH / 2 - 300 - 65, 125 - 50 / 2, 50, 50);
            setActive(false);
        }

        @Override
        public void refresh() {
            textureRegion = gui.lightIcons[matchSettings.time.ordinal()];
        }
    }

    private class TimeButton extends Button {

        TimeButton() {
            if (navigation.competition.type == FRIENDLY) {
                setColor(0x3C3C78);
            } else {
                setColor(0x666666);
                setActive(false);
            }
            setGeometry(gui.WIDTH / 2 + 65, 125 - 40 / 2, 300, 40);
            setText("", CENTER, game.font14);
        }

        @Override
        public void refresh() {
            setText(game.gettext(MatchSettings.getTimeLabel(matchSettings.time)));
        }

        @Override
        public void onFire1Down() {
            rotateTime();
        }

        private void rotateTime() {
            matchSettings.rotateTime(1);
            setDirty(true);
            timePicture.setDirty(true);
        }
    }

    private class PitchTypeLabel extends Button {

        PitchTypeLabel() {
            setColor(0x800000);
            setGeometry(gui.WIDTH / 2 - 300 + 25, 185 - 40 / 2, 300, 40);
            setText(game.gettext("PITCH TYPE"), CENTER, game.font14);
            setActive(false);
        }
    }

    private class PitchTypePicture extends Button {

        PitchTypePicture() {
            setColor(0x666666);
            setGeometry(gui.WIDTH / 2 - 300 - 65, 185 - 50 / 2, 50, 50);
            setActive(false);
        }

        @Override
        public void refresh() {
            textureRegion = gui.pitchIcons[matchSettings.pitchType.ordinal()];
        }
    }

    private class PitchTypeButton extends Button {

        PitchTypeButton() {
            if (navigation.competition.type == FRIENDLY) {
                setColor(0x3C3C78);
            } else {
                setColor(0x666666);
                setActive(false);
            }
            setGeometry(gui.WIDTH / 2 + 65, 185 - 40 / 2, 300, 40);
            setText("", CENTER, game.font14);
        }

        @Override
        public void refresh() {
            setText(game.gettext(Pitch.names[matchSettings.pitchType.ordinal()]));
        }

        @Override
        public void onFire1Down() {
            rotatePitchType(1);
        }

        private void rotatePitchType(int n) {
            matchSettings.rotatePitchType(n);
            setDirty(true);
            pitchTypePicture.setDirty(true);
            weatherPicture.setDirty(true);
            weatherButton.setDirty(true);
        }
    }

    private class WeatherLabel extends Button {

        WeatherLabel() {
            setColor(0x800000);
            setGeometry(gui.WIDTH / 2 - 300 + 25, 245 - 40 / 2, 300, 40);
            setText(game.gettext("WEATHER"), CENTER, game.font14);
            setActive(false);
        }
    }

    private class WeatherPicture extends Button {

        WeatherPicture() {
            setColor(0x666666);
            setGeometry(gui.WIDTH / 2 - 300 - 65, 245 - 50 / 2, 50, 50);
            setActive(false);
        }

        @Override
        public void refresh() {
            textureRegion = gui.weatherIcons[matchSettings.weatherOffset()];
        }
    }

    private class WeatherButton extends Button {

        WeatherButton() {
            if (navigation.competition.type == FRIENDLY) {
                setColor(0x3C3C78);
                setActive(true);
            } else {
                setColor(0x666666);
                setActive(false);
            }
            setGeometry(gui.WIDTH / 2 + 65, 245 - 40 / 2, 300, 40);
            setText("", CENTER, game.font14);
        }

        @Override
        public void refresh() {
            setText(game.gettext(matchSettings.getWeatherLabel()));
        }

        @Override
        public void onFire1Down() {
            matchSettings.rotateWeather();
            setDirty(true);
            weatherPicture.setDirty(true);
        }
    }

    private class TeamNameButton extends Button {

        TeamNameButton(Team team) {
            int sign = team.index == 0 ? -1 : 1;
            setGeometry((gui.WIDTH - 320) / 2 + (320 / 2 + 50) * sign, 296, 320, 42);
            if (team.controlMode == Team.ControlMode.PLAYER) {
                setColor(0x0000C8);
            } else {
                setColor(0x981E1E);
            }
            setText(game.gettext("NAMES." + team.name), CENTER, game.font14);
            setActive(false);
        }
    }

    private class KitPicture extends Button {

        Team team;

        KitPicture(Team team) {
            this.team = team;
            int sign = team.index == 0 ? -1 : 1;
            setGeometry((gui.WIDTH - 83) / 2 + 220 * sign, 355, 88, 174);
            setImageScale(0.5f, 0.5f);
            setImagePosition(2, 2);
            setAddShadow(true);
            setActive(true);
        }

        @Override
        public void refresh() {
            textureRegion = team.loadKit(team.kitIndex);
        }

        @Override
        public void onFire1Down() {
            team.kitIndex = EMath.rotate(team.kitIndex, 0, team.kits.size() - 1, 1);
            setDirty(true);
            for (KitIndicator k : kitIndicators[team.index]) {
                k.setDirty(true);
            }
        }
    }

    private class KitIndicator extends Button {

        Team team;
        int index;

        KitIndicator(Team team, int index) {
            this.team = team;
            this.index = index;
            int sign = team.index == 0 ? -1 : 1;
            int tot = team.kits.size();
            int w = 12 * tot + 4 * (tot - 1);
            setGeometry(gui.WIDTH / 2 + 220 * sign + 16 * index - w / 2, 509, 16, 16);
            setActive(false);
        }

        @Override
        public void refresh() {
            if (index == team.kitIndex) {
                setColors(0x51EF43, null, null);
            } else {
                setColors(0x666666, null, null);
            }
        }
    }

    private class ControlsButton extends Button {

        Team team;

        ControlsButton(Team team) {
            this.team = team;
            int sign = team.index == 0 ? -1 : 1;
            setGeometry((gui.WIDTH - 120) / 2 + (120 / 2 + 290) * sign, gui.HEIGHT - 80 - 92, 120, 90);
            setText("", RIGHT, game.font14);
            setImageScale(2f, 2f);
            setImagePosition(10, 9);
            setActive(team.controlMode == Team.ControlMode.PLAYER);
        }

        @Override
        public void refresh() {
            if (team.controlMode == Team.ControlMode.PLAYER) {
                textureRegion = gui.controlsIcons[team.inputDevice.type.ordinal()];
                if (team.inputDevice.type == InputDevice.Type.JOYSTICK) {
                    setText(team.inputDevice.port + 1);
                } else {
                    setText("");
                }
            } else {
                textureRegion = gui.controlsIcons[0];
            }
        }

        @Override
        protected void onFire1Down() {
            team.setInputDevice(game.inputDevices.rotateAvailable(team.inputDevice, 1));
            game.preferredInputDevice = game.inputDevices.indexOf(team.inputDevice);
            setDirty(true);
        }
    }

    private class PlayMatchButton extends Button {

        PlayMatchButton() {
            setGeometry((gui.WIDTH - 250) / 2, 380, 250, 54);
            setColor(0x138B21);
            setText(game.gettext("PLAY MATCH"), CENTER, game.font14);
        }

        @Override
        public void onFire1Down() {
            game.setScreen(new MatchLoading(game, matchSettings, navigation.competition));
        }
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH - 180) / 2, gui.HEIGHT - 40 - 20, 180, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            onKeyBack();
        }
    }

    @Override
    protected void onKeyBack() {
        switch (navigation.competition.type) {
            case FRIENDLY:
                game.setScreen(new SelectTeams(game));
                break;

            case CUP:
                game.setScreen(new PlayCup(game));
                break;
        }
    }
}
