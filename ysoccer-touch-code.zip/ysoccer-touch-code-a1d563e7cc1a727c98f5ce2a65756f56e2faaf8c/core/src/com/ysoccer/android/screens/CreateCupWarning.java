package com.ysoccer.android.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.ysoccer.android.competitions.Competition;
import com.ysoccer.android.competitions.Cup;
import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Label;
import com.ysoccer.android.gui.Widget;

import static com.ysoccer.android.framework.GLGame.State.COMPETITION;
import static com.ysoccer.android.framework.GLGame.json;
import static com.ysoccer.android.util.Constants.competitionsFolder;

class CreateCupWarning extends GLScreen {

    CreateCupWarning(GLGame game) {
        super(game);

        background = "images/backgrounds/menu_match.jpg";

        Widget w;

        w = new TitleBar(game.gettext("NEW CUP"), 0x415600);
        widgets.add(w);

        // warning
        w = new Button();
        w.setGeometry((gui.WIDTH - 580) / 2, 170, 580, 180);
        w.setColors(0xDC0000, 0xFF4141, 0x8C0000);
        w.setActive(false);
        widgets.add(w);

        String msg = game.gettext("YOU ARE ABOUT TO LOSE CURRENT COMPETITION");
        int cut = msg.indexOf(" ", msg.length() / 2);

        w = new Label();
        w.setText(msg.substring(0, cut), Font.Align.CENTER, game.font14);
        w.setPosition(gui.WIDTH / 2, 240);
        widgets.add(w);

        w = new Label();
        w.setText(msg.substring(cut + 1), Font.Align.CENTER, game.font14);
        w.setPosition(gui.WIDTH / 2, 280);
        widgets.add(w);

        w = new ContinueButton();
        widgets.add(w);

        w = new AbortButton();
        widgets.add(w);

        setSelectedWidget(w);
    }

    private class ContinueButton extends Button {

        ContinueButton() {
            setGeometry((gui.WIDTH - 220) / 2, gui.HEIGHT -128, 220, 48);
            setColors(0x568200, 0x77B400, 0x243E00);
            setText(game.gettext("CONTINUE"), Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Down() {
            game.clearCompetition();

            FileHandle fileHandle = Gdx.files.internal(competitionsFolder).child("cup.json");
            Cup cup = json.fromJson(Cup.class, fileHandle.readString("UTF-8"));
            cup.category = Competition.Category.PRESET_COMPETITION;
            game.setState(COMPETITION);
            game.setCompetition(cup);
            game.setScreen(new SelectTeam(game));
        }
    }

    private class AbortButton extends Button {

        AbortButton() {
            setGeometry((gui.WIDTH - 180) / 2, gui.HEIGHT - 40 - 20, 180, 40);
            setColors(0xC84200, 0xFF6519, 0x803300);
            setText(game.gettext("ABORT"), Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Down() {
            game.setScreen(new Main(game));
        }
    }
}
