package com.ysoccer.android.screens;

import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Widget;

class DeveloperTools extends GLScreen {

    DeveloperTools(GLGame game) {
        super(game);
        background = "images/backgrounds/menu_game_options.jpg";
        Widget w;

        w = new TitleBar(game.gettext("DEVELOPER TOOLS"), 0x191FB0);
        widgets.add(w);

        w = new TouchTestButton();
        widgets.add(w);

        setSelectedWidget(w);

        w = new ExitButton();
        widgets.add(w);

    }

    private class TouchTestButton extends Button {

        TouchTestButton() {
            setColor(0x7D42A1);
            setGeometry((gui.WIDTH - 260) / 2, 300, 260, 36);
            setText("TOUCH TEST", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.setScreen(new TouchTest(game));
        }
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH - 180) / 2, gui.HEIGHT - 40 - 20, 180, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            backToMain();
        }
    }

    @Override
    protected void onKeyBack() {
        backToMain();
    }

    private void backToMain() {
        game.setScreen(new Main(game));
    }
}
