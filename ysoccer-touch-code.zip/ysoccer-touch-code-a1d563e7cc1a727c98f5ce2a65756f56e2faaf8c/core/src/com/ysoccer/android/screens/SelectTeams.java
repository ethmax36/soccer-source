package com.ysoccer.android.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.ysoccer.android.competitions.Friendly;
import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Widget;
import com.ysoccer.android.match.Team;
import com.ysoccer.android.util.Constants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.ysoccer.android.framework.Font.Align.CENTER;
import static com.ysoccer.android.framework.GLGame.json;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;
import static com.ysoccer.android.match.Team.ControlMode.PLAYER;
import static com.ysoccer.android.util.Constants.teamsRootFolder;

class SelectTeams extends GLScreen {

    private final Team[] teams;

    SelectTeams(GLGame game) {
        super(game);
        background = "images/backgrounds/menu_match.jpg";

        teams = new Team[2];

        Widget w;

        w = new TitleBar(game.gettext("CHOOSE TEAMS FOR") + " " + game.gettext("FRIENDLY"), game.stateColor);
        widgets.add(w);

        w = new ComputerButton();
        widgets.add(w);

        w = new ComputerLabel();
        widgets.add(w);

        w = new PlayerButton();
        widgets.add(w);

        w = new PlayerLabel();
        widgets.add(w);

        List<Team> teamList = new ArrayList<>();
        FileHandle[] teamFileHandles = Gdx.files.internal(teamsRootFolder).list(Constants.teamFilenameFilter);
        for (FileHandle teamFileHandle : teamFileHandles) {
            Team team = json.fromJson(Team.class, teamFileHandle.readString("UTF-8"));
            team.path = Constants.getRelativeTeamPath(teamFileHandle);
            teamList.add(team);
        }

        List<Widget> list = new ArrayList<>();
        for (Team team : teamList) {
            w = new TeamButton(team);
            list.add(w);
            widgets.add(w);
        }

        if (list.size() > 0) {
            Collections.sort(list, Widget.widgetComparatorByText);
            Widget.arrange(gui.WIDTH, 290, 30, list);
            setSelectedWidget(list.get(0));
        }

        w = new ExitButton();
        widgets.add(w);

        w = new PlayMatchButton();
        widgets.add(w);
    }

    private class ComputerButton extends Button {

        ComputerButton() {
            setGeometry(gui.WIDTH / 2 - 300, 80, 60, 26);
            setColor(0x981E1E);
            setActive(false);
        }
    }

    private class ComputerLabel extends Button {

        ComputerLabel() {
            setGeometry(gui.WIDTH / 2 - 300 + 80, 80, 180, 26);
            setText(game.gettext("CONTROL MODE.COMPUTER"), Font.Align.LEFT, game.font14);
            setActive(false);
        }
    }

    private class PlayerButton extends Button {

        PlayerButton() {
            setGeometry(gui.WIDTH / 2 + 40, 80, 60, 26);
            setColor(0x0000C8);
            setActive(false);
        }
    }

    private class PlayerLabel extends Button {

        PlayerLabel() {
            setGeometry(gui.WIDTH / 2 + 40 + 80, 80, 180, 26);
            setText(game.gettext("CONTROL MODE.PLAYER"), Font.Align.LEFT, game.font14);
            setActive(false);
        }
    }

    private class TeamButton extends Button {

        Team team;

        TeamButton(Team team) {
            setSize(300, 28);
            setText(game.gettext("NAMES." + team.name), CENTER, game.font14);
            this.team = team;
        }

        @Override
        public void refresh() {
            switch (team.controlMode) {
                case UNDEFINED:
                    setColors(0x98691E, 0xC88B28, 0x3E2600);
                    break;

                case COMPUTER:
                    setColors(0x981E1E, 0xC72929, 0x640000);
                    break;

                case PLAYER:
                    setColors(0x0000C8, 0x1919FF, 0x000078);
                    break;
            }
        }

        @Override
        protected void onFire1Up() {
            Team home = teams[0];
            Team away = teams[1];

            switch (team.controlMode) {
                case UNDEFINED:
                    if (away != null) {
                        team.controlMode = away.controlMode;
                        away.controlMode = Team.ControlMode.UNDEFINED;
                        replaceTeam(team);
                    } else {
                        if (home != null && home != team && home.controlMode == PLAYER) {
                            team.controlMode = Team.ControlMode.COMPUTER;
                        } else {
                            team.controlMode = PLAYER;
                        }
                        addTeam(team);
                    }
                    break;

                case COMPUTER:
                    team.controlMode = Team.ControlMode.UNDEFINED;
                    removeTeam(team);
                    break;

                case PLAYER:
                    if (home != null && home != team && home.controlMode == Team.ControlMode.COMPUTER) {
                        team.controlMode = Team.ControlMode.UNDEFINED;
                        removeTeam(team);
                    } else if (away != null && away != team && away.controlMode == Team.ControlMode.COMPUTER) {
                        team.controlMode = Team.ControlMode.UNDEFINED;
                        removeTeam(team);
                    } else {
                        team.controlMode = Team.ControlMode.COMPUTER;
                        addTeam(team);
                    }
                    break;
            }
            refreshAllWidgets();
        }
    }

    private void addTeam(Team buttonTeam) {
        if (teams[0] == null) {
            teams[0] = buttonTeam;
        } else if (buttonTeam != teams[0] && teams[1] == null) {
            teams[1] = buttonTeam;
        }
    }

    private void removeTeam(Team buttonTeam) {
        if (teams[0] == buttonTeam) {
            teams[0] = teams[1];
        }
        teams[1] = null;
    }

    private void replaceTeam(Team buttonTeam) {
        teams[1] = buttonTeam;
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH) / 2 - 300 - 30, gui.HEIGHT - 40 - 20, 300, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            backToMain();
        }
    }

    private class PlayMatchButton extends Button {

        PlayMatchButton() {
            setGeometry(gui.WIDTH / 2 + 30, gui.HEIGHT - 40 - 20, 300, 40);
            setText(game.gettext("PLAY MATCH"), CENTER, game.font14);
        }

        @Override
        public void refresh() {
            boolean active = teams[0] != null && teams[1] != null;
            setActive(active);
            setColor(active ? 0x138B21 : 0x666666);
        }

        @Override
        public void onFire1Up() {
            Friendly friendly = new Friendly(game.gettext("FRIENDLY"), teams[0], teams[1]);
            navigation.competition = friendly;
            friendly.setMatchTeams();

            // set input devices
            game.inputDevices.setAvailability(true);
            for (int t = HOME; t <= AWAY; t++) {
                if (teams[t].controlMode == PLAYER) {
                    teams[t].setInputDevice(game.inputDevices.assignThisOrFirstAvailable(game.preferredInputDevice));
                } else {
                    teams[t].setInputDevice(null);
                }
                teams[t].releaseNonAiInputDevices();
            }

            game.setScreen(new MatchSetup(game));
        }
    }

    @Override
    protected void onKeyBack() {
        backToMain();
    }

    private void backToMain() {
        game.setScreen(new Main(game));
    }
}
