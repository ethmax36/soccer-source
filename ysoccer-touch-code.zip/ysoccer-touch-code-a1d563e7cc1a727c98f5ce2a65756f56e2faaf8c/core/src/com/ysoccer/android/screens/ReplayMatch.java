package com.ysoccer.android.screens;

import com.ysoccer.android.competitions.Friendly;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Widget;
import com.ysoccer.android.match.Match;

import static com.ysoccer.android.framework.Font.Align.CENTER;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;

class ReplayMatch extends GLScreen {

    private Match match;

    ReplayMatch(GLGame game, Match match) {
        super(game);
        this.match = match;

        background = "images/backgrounds/menu_match.jpg";

        Widget w;

        w = new TitleBar(match.competition.name, game.stateColor);
        widgets.add(w);

        w = new ReplayButton();
        widgets.add(w);

        setSelectedWidget(w);

        w = new ExitButton();
        widgets.add(w);
    }

    private class ReplayButton extends Button {

        ReplayButton() {
            setGeometry((gui.WIDTH - 240) / 2, gui.HEIGHT - 150, 240, 50);
            setColor(0x138B21);
            setText(game.gettext("REPLAY MATCH"), CENTER, game.font14);
        }

        @Override
        public void onFire1Down() {
            Friendly friendly = new Friendly(game.gettext("FRIENDLY"), match.team[HOME], match.team[AWAY]);
            friendly.setMatchTeams();

            game.setScreen(new MatchLoading(game, match.getSettings(), friendly));
        }
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH - 180) / 2, gui.HEIGHT - 40 - 20, 180, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            onKeyBack();
        }
    }

    @Override
    protected void onKeyBack() {
        game.setScreen(new Main(game));
    }
}