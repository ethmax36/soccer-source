package com.ysoccer.android.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.controllers.Controller;
import com.badlogic.gdx.controllers.ControllerListener;
import com.badlogic.gdx.controllers.Controllers;
import com.badlogic.gdx.controllers.PovDirection;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.math.Vector3;
import com.ysoccer.android.competitions.Competition;
import com.ysoccer.android.competitions.Cup;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.framework.InputDevice;
import com.ysoccer.android.framework.Settings;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Label;
import com.ysoccer.android.gui.Widget;

import static com.ysoccer.android.framework.Font.Align.CENTER;
import static com.ysoccer.android.framework.GLGame.State.COMPETITION;
import static com.ysoccer.android.framework.GLGame.json;
import static com.ysoccer.android.util.Constants.competitionsFolder;

public class Main extends GLScreen implements ControllerListener {

    public Main(GLGame game) {
        super(game);
        background = "images/backgrounds/menu_main.jpg";
        catchBackKey = false;

        Widget w;

        w = new GameSettingsButton();
        widgets.add(w);

        setSelectedWidget(w);

        w = new ControlsButton();
        widgets.add(w);

        w = new FriendlyButton();
        widgets.add(w);

        w = new CupButton();
        widgets.add(w);

        if (game.hasCompetition()) {
            w = new ReplayContinueCompetitionButton();
            widgets.add(w);
        }

        w = new HomePageLabel();
        widgets.add(w);

        if (Settings.development) {
            w = new DeveloperToolsButton();
            widgets.add(w);
        }
    }

    @Override
    public void connected(Controller controller) {
        GLGame.inputConfigurationChanged = true;
    }

    @Override
    public void disconnected(Controller controller) {
        GLGame.inputConfigurationChanged = true;
    }

    @Override
    public boolean buttonDown(Controller controller, int buttonCode) {
        return false;
    }

    @Override
    public boolean buttonUp(Controller controller, int buttonCode) {
        return false;
    }

    @Override
    public boolean axisMoved(Controller controller, int axisCode, float value) {
        return false;
    }

    @Override
    public boolean povMoved(Controller controller, int povCode, PovDirection value) {
        return false;
    }

    @Override
    public boolean xSliderMoved(Controller controller, int sliderCode, boolean value) {
        return false;
    }

    @Override
    public boolean ySliderMoved(Controller controller, int sliderCode, boolean value) {
        return false;
    }

    @Override
    public boolean accelerometerMoved(Controller controller, int accelerometerCode, Vector3 value) {
        return false;
    }

    private class GameSettingsButton extends Button {

        GameSettingsButton() {
            setGeometry(gui.WIDTH / 2 - 30 - 320, 290, 320, 36);
            setColor(0x536B90);
            setText(game.gettext("GAME OPTIONS"), CENTER, game.font14);
        }

        @Override
        protected void onFire1Up() {
            game.setScreen(new GameOptions(game));
        }
    }

    private class ControlsButton extends Button {

        ControlsButton() {
            setGeometry(gui.WIDTH / 2 - 30 - 320, 340, 320, 36);
            setColor(0x83079C);
            setText(game.gettext("CONTROLS"), CENTER, game.font14);
        }

        @Override
        protected void onFire1Up() {
            game.setScreen(new SetupControls(game));
        }
    }

    private class FriendlyButton extends Button {

        FriendlyButton() {
            setGeometry(gui.WIDTH / 2 + 30, 290, 320, 36);
            setColor(0x2D855D);
            setText(game.gettext("FRIENDLY"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.setState(GLGame.State.FRIENDLY);
            game.setScreen(new SelectTeams(game));
        }
    }

    private class CupButton extends Button {

        CupButton() {
            setColor(0x415600);
            setGeometry(gui.WIDTH / 2 + 30, 340, 320, 36);
            setText(game.gettext("CUP"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {

            if (game.hasCompetition()) {
                game.setScreen(new CreateCupWarning(game));
            } else {
                FileHandle fileHandle = Gdx.files.internal(competitionsFolder).child("cup.json");
                Cup cup = json.fromJson(Cup.class, fileHandle.readString("UTF-8"));
                cup.category = Competition.Category.PRESET_COMPETITION;
                game.setState(COMPETITION);
                game.setCompetition(cup);
                game.setScreen(new SelectTeam(game));
            }
        }
    }

    private class ReplayContinueCompetitionButton extends Button {

        ReplayContinueCompetitionButton() {
            setColors(0x568200, 0x77B400, 0x243E00);
            setGeometry((gui.WIDTH - 600) / 2, 400, 600, 32);
            String s = game.gettext(game.competition.isEnded() ? "REPLAY %s" : "CONTINUE %s");
            setText(s.replace("%s", game.gettext(game.competition.name)), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            if (game.competition.isEnded()) {
                game.competition.restart();
            }

            switch (game.competition.type) {
                case CUP:
                    game.setScreen(new PlayCup(game));
                    break;
            }
        }
    }

    private class HomePageLabel extends Label {

        HomePageLabel() {
            setGeometry(gui.WIDTH - 174, gui.HEIGHT - 22, 174, 22);
            setText("YSOCCER.SF.NET", CENTER, game.font10);
        }
    }

    private class DeveloperToolsButton extends Button {

        DeveloperToolsButton() {
            setColor(0x191FB0);
            setGeometry((gui.WIDTH - 300) / 2, 450, 300, 32);
            setText("DEVELOPER TOOLS", CENTER, game.font10);
        }

        @Override
        public void onFire1Up() {
            game.setScreen(new DeveloperTools(game));
        }
    }

    @Override
    public void hide() {
        super.hide();
        Controllers.removeListener(this);
    }

    @Override
    public void pause() {
        super.pause();
        Controllers.removeListener(this);
    }

    @Override
    public void resume() {
        super.resume();
        Controllers.addListener(this);
    }

    @Override
    public void show() {
        super.show();
        Controllers.addListener(this);
    }

    @Override
    public void render(float deltaTime) {
        super.render(deltaTime);
        if (paused) return;

        batch.begin();
        batch.draw(gui.logo, gui.WIDTH / 2.0f - 175, 107);
        drawInputDevices();
        batch.end();
    }

    private void drawInputDevices() {
        float x = gui.WIDTH / 2f - 36 * game.inputDevices.size() / 2f + 8 * (game.inputDevices.size() - 1);
        for (InputDevice inputDevice : game.inputDevices) {
            batch.draw(gui.controlsIcons[inputDevice.type.ordinal()], x, gui.HEIGHT - 40);
            x += 44;
        }
    }
}
