package com.ysoccer.android.screens;

import com.ysoccer.android.competitions.Competition;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.match.Match;
import com.ysoccer.android.match.MatchSettings;

public class MatchLoading extends GLScreen {

    private final Match match;

    MatchLoading(GLGame game, MatchSettings matchSettings, Competition competition) {
        super(game);

        playMenuMusic = false;

        matchSettings.setup();

        match = competition.getMatch();
        match.init(game, matchSettings, competition);
    }

    @Override
    public void render(float deltaTime) {
        super.render(deltaTime);

        game.setScreen(new MatchScreen(game, match));
    }
}
