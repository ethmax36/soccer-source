package com.ysoccer.android.screens;

import com.ysoccer.android.competitions.Cup;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.match.Match;
import com.ysoccer.android.match.MatchRenderer;

import static com.ysoccer.android.framework.Touch.TouchEvent.Type.TOUCH_DOWN;
import static com.ysoccer.android.framework.Touch.TouchEvent.Type.TOUCH_DRAGGED;
import static com.ysoccer.android.framework.Touch.TouchEvent.Type.TOUCH_UP;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;

public class MatchScreen extends GLScreen {

    private final Match match;
    private final MatchRenderer matchRenderer;
    private boolean matchStarted;
    private boolean matchPaused;
    private boolean matchEnded;

    MatchScreen(GLGame game, Match match) {
        super(game);
        this.match = match;
        this.matchRenderer = match.getRenderer();

        playMenuMusic = false;

        matchStarted = false;
        matchPaused = false;
        matchEnded = false;
        game.glGraphics.light = 0;

        match.listener = new Match.MatchListener() {
            public void quitMatch(boolean matchCompleted) {
                quit(matchCompleted);
            }
        };
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        if (match.hasTouchControls()) {
            game.touchInput.addTouchEvent(TOUCH_DOWN, screenX, screenY);
        }
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        if (match.hasTouchControls()) {
            game.touchInput.addTouchEvent(TOUCH_UP, screenX, screenY);
        }
        return true;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        if (match.hasTouchControls()) {
            game.touchInput.addTouchEvent(TOUCH_DRAGGED, screenX, screenY);
        }
        return true;
    }

    @Override
    protected void loadAssets() {
        super.loadAssets();
        matchRenderer.loadAssets();
        if (match.hasTouchControls()) {
            game.touchInput.loadAssets(assetManager);
        }
    }

    @Override
    protected void getAssets() {
        super.getAssets();
        matchRenderer.getAssets();
        if (match.hasTouchControls()) {
            game.touchInput.getAssets(assetManager);
        }
    }

    @Override
    protected void unloadAssets() {
        super.unloadAssets();
        if (match.hasTouchControls()) {
            game.touchInput.unloadAssets(assetManager);
        }
        matchRenderer.unloadAssets();
    }

    @Override
    public void render(float deltaTime) {
        super.render(deltaTime);

        if (!matchStarted) {
            match.start();
            matchStarted = true;
        }

        if (!matchPaused) {
            match.update(deltaTime);
        }

        if (!matchEnded) {
            match.render();
        }
    }

    @Override
    public void resize(int width, int height) {
        super.resize(width, height);

        match.resize(width, height);
    }

    private void quit(boolean matchCompleted) {
        matchEnded = true;

        for (int t = HOME; t <= AWAY; t++) {
            match.team[t].lineup.clear();
        }

        if (matchCompleted) {
            match.competition.onMatchCompleted();
        } else if (match.clock > 0) {
            match.competition.onMatchInterrupted();
        }

        // ugly hack
        game.menuInput.reset();

        switch (match.competition.type) {
            case FRIENDLY:
                game.setScreen(new ReplayMatch(game, match));
                break;

            case CUP:
                Cup cup = (Cup) match.competition;
                if (!cup.isLastMatchOfLeg() && matchCompleted) {
                    cup.nextMatch();
                }

                game.setScreen(new PlayCup(game));
                break;
        }
    }

    @Override
    public void pause() {
        super.pause();
        match.onScreenPaused();
    }

    @Override
    protected void onKeyBack() {
        match.onKeyBack();
    }
}
