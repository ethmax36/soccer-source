package com.ysoccer.android.screens;

import com.ysoccer.android.framework.EMath;
import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.framework.Settings;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Widget;
import com.ysoccer.android.match.SceneRenderer;
import com.ysoccer.android.match.WeatherEffects;

import java.util.Arrays;
import java.util.List;

class GameOptions extends GLScreen {

    private final MusicButton musicButton;
    private final SfxButton sfxButton;
    private final LengthButton lengthButton;
    private final WeatherButton weatherButton;
    private final ZoomButton zoomButton;

    GameOptions(GLGame game) {
        super(game);
        background = "images/backgrounds/menu_game_options.jpg";

        Widget w;

        w = new TitleBar(game.gettext("GAME OPTIONS"), 0x536B90);
        widgets.add(w);

        w = new MusicVolumeLabel();
        widgets.add(w);

        w = new MusicMinusButton();
        widgets.add(w);

        setSelectedWidget(w);

        musicButton = new MusicButton();
        widgets.add(musicButton);

        w = new MusicPlusButton();
        widgets.add(w);

        w = new SfxVolumeLabel();
        widgets.add(w);

        w = new SfxMinusButton();
        widgets.add(w);

        sfxButton = new SfxButton();
        widgets.add(sfxButton);

        w = new SfxPlusButton();
        widgets.add(w);

        w = new MatchLengthLabel();
        widgets.add(w);

        w = new LengthMinusButton();
        widgets.add(w);

        lengthButton = new LengthButton();
        widgets.add(lengthButton);

        w = new LengthPlusButton();
        widgets.add(w);

        w = new WeatherEffectsLabel();
        widgets.add(w);

        w = new WeatherMinusButton();
        widgets.add(w);

        weatherButton = new WeatherButton();
        widgets.add(weatherButton);

        w = new WeatherPlusButton();
        widgets.add(w);

        w = new ZoomLabel();
        widgets.add(w);

        w = new ZoomMinusButton();
        widgets.add(w);

        zoomButton = new ZoomButton();
        widgets.add(zoomButton);

        w = new ZoomPlusButton();
        widgets.add(w);

        w = new RadarLabel();
        widgets.add(w);

        w = new RadarButton();
        widgets.add(w);

        w = new AutoReplaysLabel();
        widgets.add(w);

        w = new AutoReplayButton();
        widgets.add(w);

        w = new ExitButton();
        widgets.add(w);
    }

    private class MusicVolumeLabel extends Button {

        MusicVolumeLabel() {
            setGeometry(gui.WIDTH / 2 - 400 - 30, 100, 400, 40);
            setColor(0x800000);
            setText(game.gettext("MUSIC.VOLUME"), Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    private class MusicMinusButton extends Button {

        MusicMinusButton() {
            setGeometry(gui.WIDTH / 2 + 30, 100, 100, 40);
            setColor(0x3C3C78);
            setText("-", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.settings.musicVolume = EMath.slide(game.settings.musicVolume, 0, 100, -10);
            musicButton.setDirty(true);
        }
    }

    private class MusicButton extends Button {

        MusicButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 100, 100, 200, 40);
            setColor(0x1F1F95);
            setText("", Font.Align.CENTER, game.font14);
            setActive(false);
        }

        @Override
        public void refresh() {
            if (game.settings.musicVolume == 0) {
                setText(game.gettext("MUSIC.OFF"));
            } else {
                setText(game.settings.musicVolume / 10);
            }
        }
    }

    private class MusicPlusButton extends Button {

        MusicPlusButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 300, 100, 100, 40);
            setColor(0x3C3C78);
            setText("+", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.settings.musicVolume = EMath.slide(game.settings.musicVolume, 0, 100, 10);
            musicButton.setDirty(true);
        }
    }

    private class SfxVolumeLabel extends Button {

        SfxVolumeLabel() {
            setGeometry(gui.WIDTH / 2 - 400 - 30, 150, 400, 40);
            setColor(0x800000);
            setText(game.gettext("MATCH OPTIONS.SOUND VOLUME"), Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    private class SfxMinusButton extends Button {

        SfxMinusButton() {
            setGeometry(gui.WIDTH / 2 + 30, 150, 100, 40);
            setColor(0x3C3C78);
            setText("-", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.settings.soundVolume = EMath.slide(game.settings.soundVolume, 0, 100, -10);
            sfxButton.setDirty(true);
        }
    }

    private class SfxButton extends Button {

        SfxButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 100, 150, 200, 40);
            setColor(0x1F1F95);
            setText("", Font.Align.CENTER, game.font14);
            setActive(false);
        }

        @Override
        public void refresh() {
            if (game.settings.soundVolume == 0) {
                setText(game.gettext("MATCH OPTIONS.SOUND VOLUME.OFF"));
            } else {
                setText(game.settings.soundVolume / 10);
            }
        }
    }

    private class SfxPlusButton extends Button {

        SfxPlusButton() {
            setColor(0x3C3C78);
            setGeometry(gui.WIDTH / 2 + 30 + 300, 150, 100, 40);
            setText("+", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.settings.soundVolume = EMath.slide(game.settings.soundVolume, 0, 100, 10);
            sfxButton.setDirty(true);
        }
    }

    private class MatchLengthLabel extends Button {

        MatchLengthLabel() {
            setGeometry(gui.WIDTH / 2 - 400 - 30, 200, 400, 40);
            setColor(0x800000);
            setText(game.gettext("FRIENDLY GAME LENGTH"), Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    private class LengthMinusButton extends Button {

        List<Integer> matchLengths;

        LengthMinusButton() {
            matchLengths = Arrays.asList(Settings.matchLengths);
            setGeometry(gui.WIDTH / 2 + 30, 200, 100, 40);
            setColor(0x3C3C78);
            setText("-", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            int index = matchLengths.indexOf(game.settings.matchLength);
            game.settings.matchLength = matchLengths.get(EMath.slide(index, 0, matchLengths.size() - 1, -1));
            lengthButton.setDirty(true);
        }
    }

    private class LengthButton extends Button {

        LengthButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 100, 200, 200, 40);
            setColor(0x1F1F95);
            setText("", Font.Align.CENTER, game.font14);
            setActive(false);
        }

        @Override
        public void refresh() {
            setText(game.gettext("%n MINUTES").replaceFirst("%n", "" + game.settings.matchLength));
        }
    }

    private class LengthPlusButton extends Button {

        List<Integer> matchLengths;

        LengthPlusButton() {
            matchLengths = Arrays.asList(Settings.matchLengths);
            setGeometry(gui.WIDTH / 2 + 30 + 300, 200, 100, 40);
            setColor(0x3C3C78);
            setText("+", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            int index = matchLengths.indexOf(game.settings.matchLength);
            game.settings.matchLength = matchLengths.get(EMath.slide(index, 0, matchLengths.size() - 1, +1));
            lengthButton.setDirty(true);
        }
    }

    private class WeatherEffectsLabel extends Button {

        WeatherEffectsLabel() {
            setGeometry(gui.WIDTH / 2 - 400 - 30, 250, 400, 40);
            setColor(0x800000);
            setText(game.gettext("WEATHER.EFFECTS"), Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    private class WeatherMinusButton extends Button {

        WeatherMinusButton() {
            setGeometry(gui.WIDTH / 2 + 30, 250, 100, 40);
            setColor(0x3C3C78);
            setText("-", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.settings.weatherMaxStrength = EMath.slide(game.settings.weatherMaxStrength, WeatherEffects.Strength.NONE, WeatherEffects.Strength.STRONG, -1);
            weatherButton.setDirty(true);
        }
    }

    private class WeatherButton extends Button {

        WeatherButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 100, 250, 200, 40);
            setColor(0x1F1F95);
            setText("", Font.Align.CENTER, game.font14);
            setActive(false);
        }

        @Override
        public void refresh() {
            setText(game.gettext(WeatherEffects.Strength.names[game.settings.weatherMaxStrength]));
        }
    }

    private class WeatherPlusButton extends Button {

        WeatherPlusButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 300, 250, 100, 40);
            setColor(0x3C3C78);
            setText("+", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            game.settings.weatherMaxStrength = EMath.slide(game.settings.weatherMaxStrength, WeatherEffects.Strength.NONE, WeatherEffects.Strength.STRONG, +1);
            weatherButton.setDirty(true);
        }
    }

    private class ZoomLabel extends Button {

        ZoomLabel() {
            setGeometry(gui.WIDTH / 2 - 400 - 30, 300, 400, 40);
            setColor(0x800000);
            setText(game.gettext("ZOOM"), Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    private class ZoomMinusButton extends Button {

        ZoomMinusButton() {
            setGeometry(gui.WIDTH / 2 + 30, 300, 100, 40);
            setColor(0x3C3C78);
            setText("-", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            updateZoom(-1);
        }
    }

    private class ZoomButton extends Button {

        ZoomButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 100, 300, 200, 40);
            setColor(0x1F1F95);
            setText("", Font.Align.CENTER, game.font14);
            setActive(false);
        }

        @Override
        public void refresh() {
            setText(game.settings.zoom + "%");
        }
    }

    private class ZoomPlusButton extends Button {

        ZoomPlusButton() {
            setGeometry(gui.WIDTH / 2 + 30 + 300, 300, 100, 40);
            setColor(0x3C3C78);
            setText("+", Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            updateZoom(+1);
        }
    }

    private void updateZoom(int n) {
        game.settings.zoom = EMath.slide(game.settings.zoom, SceneRenderer.zoomMin(), SceneRenderer.zoomMax(), 5 * n);
        zoomButton.setDirty(true);
    }

    private class RadarLabel extends Button {

        RadarLabel() {
            setGeometry(gui.WIDTH / 2 - 400 - 30, 350, 400, 40);
            setColor(0x800000);
            setText(game.gettext("RADAR"), Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    private class RadarButton extends Button {

        RadarButton() {
            setGeometry(gui.WIDTH / 2 + 30, 350, 400, 40);
            setColor(0x3C3C78);
            setText("", Font.Align.CENTER, game.font14);
        }

        @Override
        public void refresh() {
            setText(game.gettext(game.settings.radar ? "RADAR.ON" : "RADAR.OFF"));
        }

        @Override
        public void onFire1Down() {
            game.settings.radar = !game.settings.radar;
            setDirty(true);
        }
    }

    private class AutoReplaysLabel extends Button {

        AutoReplaysLabel() {
            setGeometry(gui.WIDTH / 2 - 400 - 30, 400, 400, 40);
            setColor(0x800000);
            setText(game.gettext("AUTO REPLAYS"), Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    private class AutoReplayButton extends Button {

        AutoReplayButton() {
            setGeometry(gui.WIDTH / 2 + 30, 400, 400, 40);
            setColor(0x3C3C78);
            setText("", Font.Align.CENTER, game.font14);
        }

        @Override
        public void refresh() {
            setText(game.gettext(game.settings.autoReplays ? "AUTO REPLAYS.ON" : "AUTO REPLAYS.OFF"));
        }

        @Override
        public void onFire1Down() {
            game.settings.autoReplays = !game.settings.autoReplays;
            setDirty(true);
        }
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH - 180) / 2, gui.HEIGHT - 40 - 20, 180, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), Font.Align.CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            saveAndExit();
        }
    }

    @Override
    protected void onKeyBack() {
        saveAndExit();
    }

    private void saveAndExit() {
        game.settings.save();
        game.setScreen(new Main(game));
    }
}
