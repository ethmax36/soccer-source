package com.ysoccer.android.screens;

import com.badlogic.gdx.assets.loaders.TextureLoader;
import com.badlogic.gdx.graphics.Texture;
import com.ysoccer.android.competitions.Cup;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.EMath;
import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.framework.RgbPair;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Label;
import com.ysoccer.android.gui.Widget;
import com.ysoccer.android.match.Match;
import com.ysoccer.android.match.Team;

import java.util.ArrayList;
import java.util.List;

import static com.ysoccer.android.framework.Font.Align.CENTER;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;
import static com.ysoccer.android.match.Team.ControlMode.PLAYER;

class PlayCup extends GLScreen {

    private final Font font10green;
    private final int VISIBLE_MATCHES = 5;

    private final Cup cup;
    private final ArrayList<Match> matches;
    private int offset;

    PlayCup(GLGame game) {
        super(game);

        background = "images/backgrounds/menu_match.jpg";

        font10green = new Font(10, 13, 17, 12, 16);

        cup = (Cup) game.competition;

        Widget w;

        w = new TitleBar(cup.getMenuTitle(game), game.stateColor);
        widgets.add(w);

        matches = cup.getMatches();
        offset = 0;
        if ((matches.size() > VISIBLE_MATCHES) && (cup.currentMatch > VISIBLE_MATCHES / 2)) {
            offset = Math.min(cup.currentMatch - VISIBLE_MATCHES / 2, matches.size() - VISIBLE_MATCHES);
        }

        // calendar
        for (int matchIndex = 0; matchIndex < matches.size(); matchIndex++) {
            Match match = matches.get(matchIndex);

            w = new TeamButton(HOME, matchIndex, match, Font.Align.RIGHT);
            widgets.add(w);

            w = new ResultLabel(HOME, matchIndex, match, Font.Align.RIGHT);
            widgets.add(w);

            w = new VersusLabel(matchIndex, match);
            widgets.add(w);

            w = new ResultLabel(AWAY, matchIndex, match, Font.Align.LEFT);
            widgets.add(w);

            w = new TeamButton(AWAY, matchIndex, match, Font.Align.LEFT);
            widgets.add(w);

            w = new StatusLabel(matchIndex, cup.getMatchStatus(game, match));
            widgets.add(w);
        }

        Widget exitButton = new ExitButton();
        widgets.add(exitButton);

        w = new ScrollButton(118, -1);
        widgets.add(w);

        w = new ScrollButton(374, +1);
        widgets.add(w);

        if (cup.isEnded()) {

            setSelectedWidget(exitButton);

        } else {
            if (cup.isLastMatchOfLeg() && cup.getMatch().isEnded()) {
                w = new NextRoundButton();
            } else {
                if (cup.bothComputers()) {
                    w = new ResultButton();
                } else {
                    w = new PlayMatchButton();
                }
            }
            widgets.add(w);
            setSelectedWidget(w);
        }
    }

    private void setPositionAndVisibility(Widget w, int matchIndex) {
        if (matches.size() < VISIBLE_MATCHES) {
            w.y = 100 + 64 * (matchIndex + (VISIBLE_MATCHES - matches.size()) / 2);
        } else {
            if ((matchIndex >= offset) && (matchIndex < (offset + VISIBLE_MATCHES))) {
                w.y = 120 + 64 * (matchIndex - offset);
                w.setVisible(true);
            } else {
                w.setVisible(false);
            }
        }
    }

    @Override
    protected void onKeyBack() {
        game.setScreen(new Main(game));
    }

    private class TeamButton extends Button {

        private final int matchIndex;

        TeamButton(int side, int matchIndex, Match match, Font.Align align) {
            this.matchIndex = matchIndex;
            setGeometry(gui.WIDTH / 2 + (side == HOME ? -320 - 65 : 65), 0, 320, 28);
            int bodyColor = 0;
            Team team = cup.teams.get(match.teams[side]);
            switch (team.controlMode) {
                case COMPUTER:
                    bodyColor = 0x981E1E;
                    break;

                case PLAYER:
                    bodyColor = 0x0000C8;
                    break;
            }
            int qualified = cup.getLeg().getQualifiedTeam(match);
            int borderColor = (qualified == match.teams[side]) ? 0x21E337 : 0x1A1A1A;
            setColors(bodyColor, borderColor, borderColor);
            setText(game.gettext("NAMES." + team.name), align, game.font14);
            setActive(false);
        }

        @Override
        public void refresh() {
            setPositionAndVisibility(this, matchIndex);
        }
    }

    private class ResultLabel extends Label {

        private final int matchIndex;

        ResultLabel(int side, int matchIndex, Match match, Font.Align align) {
            this.matchIndex = matchIndex;
            setGeometry(gui.WIDTH / 2 + (side == HOME ? -45 : +15), 0, 30, 28);
            setText("", align, game.font14);
            if (match.getResult() != null) {
                setText(match.getResult()[side]);
            }
        }

        @Override
        public void refresh() {
            setPositionAndVisibility(this, matchIndex);
        }
    }

    private class VersusLabel extends Label {

        private final int matchIndex;
        private final Match match;

        VersusLabel(int matchIndex, Match match) {
            this.matchIndex = matchIndex;
            this.match = match;
            setGeometry((gui.WIDTH - 30) / 2, 0, 30, 26);
            setText(game.gettext("ABBREVIATIONS.VERSUS"), CENTER, game.font14);
        }

        @Override
        public void refresh() {
            setPositionAndVisibility(this, matchIndex);
            if (match.isEnded()) {
                setText("-");
            }
        }
    }

    private class StatusLabel extends Label {

        private final int matchIndex;

        StatusLabel(int matchIndex, String status) {
            this.matchIndex = matchIndex;
            setGeometry(gui.WIDTH / 2 - 360, 0, 720, 26);
            setText(status, CENTER, font10green);
        }

        @Override
        public void refresh() {
            setPositionAndVisibility(this, matchIndex);
            y += 32;
        }
    }

    private class ScrollButton extends Button {

        int direction;

        ScrollButton(int y, int direction) {
            this.direction = direction;
            setGeometry(gui.WIDTH - 78, y, 32, 32);
            setText("" + (char) (direction == 1 ? 17 : 18), CENTER, game.font14);
            setAddShadow(true);
        }

        @Override
        public void onFire1Down() {
            scroll(direction);
        }

        @Override
        public void onFire1Hold() {
            scroll(direction);
        }

        private void scroll(int direction) {
            offset = EMath.slide(offset, 0, matches.size() - VISIBLE_MATCHES, direction);
            refreshAllWidgets();
        }

        @Override
        public void refresh() {
            boolean v = matches.size() > VISIBLE_MATCHES;
            if (direction == 1) {
                v &= offset < (matches.size() - VISIBLE_MATCHES);
            } else {
                v &= offset > 0;
            }
            setVisible(v);
        }
    }

    private class ResultButton extends Button {

        ResultButton() {
            setGeometry(gui.WIDTH / 2 + 30, gui.HEIGHT - 40 - 20, 300, 40);
            setColor(0x138B21);
            setText(game.gettext("RESULT"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            viewResult();
        }

        private void viewResult() {
            cup.generateResult();
            if (!cup.isLastMatchOfLeg()) {
                cup.nextMatch();
            }
            game.setScreen(new PlayCup(game));
        }
    }

    private class PlayMatchButton extends Button {

        PlayMatchButton() {
            setGeometry(gui.WIDTH / 2 + 30, gui.HEIGHT - 40 - 20, 300, 40);
            setColor(0x138B21);
            setText(game.gettext("PLAY MATCH"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            cup.setMatchTeams();

            // set input devices
            Team[] teams = cup.getMatch().team;
            game.inputDevices.setAvailability(true);
            for (int t = HOME; t <= AWAY; t++) {
                if (teams[t].controlMode == PLAYER) {
                    teams[t].setInputDevice(game.inputDevices.assignThisOrFirstAvailable(game.preferredInputDevice));
                } else {
                    teams[t].setInputDevice(null);
                }
                teams[t].releaseNonAiInputDevices();
            }

            navigation.competition = cup;
            game.setScreen(new MatchSetup(game));
        }
    }

    private class NextRoundButton extends Button {

        NextRoundButton() {
            setGeometry(gui.WIDTH / 2 + 30, gui.HEIGHT - 40 - 20, 300, 40);
            setColors(0x138B21, 0x1BC12F, 0x004814);
            setText(game.gettext("NEXT ROUND"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            nextRound();
        }

        private void nextRound() {
            cup.nextMatch();
            game.setScreen(new PlayCup(game));
        }
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH) / 2 - 300 - 30, gui.HEIGHT - 40 - 20, 300, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            onKeyBack();
        }
    }

    @Override
    protected void loadAssets() {
        super.loadAssets();
        TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
        List<RgbPair> rgbPairs = new ArrayList<>();
        rgbPairs.add(new RgbPair(0xFCFCFC, 0x21E337));
        parameter.textureData = Assets.loadTextureData("images/font_10.png", rgbPairs);
        assetManager.load("font10green", Texture.class, parameter);
    }

    @Override
    protected void getAssets() {
        super.getAssets();
        Texture texture = assetManager.get("font10green");
        font10green.setTexture(texture);
    }

    @Override
    protected void unloadAssets() {
        super.unloadAssets();
        assetManager.unload("font10green");
    }
}
