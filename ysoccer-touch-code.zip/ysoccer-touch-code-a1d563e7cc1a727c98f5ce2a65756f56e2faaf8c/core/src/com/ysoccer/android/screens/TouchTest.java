package com.ysoccer.android.screens;

import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLScreen;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Widget;

import static com.ysoccer.android.framework.Font.Align.CENTER;
import static com.ysoccer.android.framework.Touch.TouchEvent.Type.TOUCH_DOWN;
import static com.ysoccer.android.framework.Touch.TouchEvent.Type.TOUCH_DRAGGED;
import static com.ysoccer.android.framework.Touch.TouchEvent.Type.TOUCH_UP;

class TouchTest extends GLScreen {

    TouchTest(GLGame game) {
        super(game);

        Widget w;

        w = new TitleBar("TOUCH TEST", 0x7D42A1);
        widgets.add(w);

        w = new TestButton(gui.WIDTH / 2 - 150, 80);
        widgets.add(w);

        w = new TestButton(gui.WIDTH / 2 + 50, 80);
        widgets.add(w);

        w = new TestButton(gui.WIDTH / 2 - 150, 200);
        widgets.add(w);

        w = new TestButton(gui.WIDTH / 2 + 50, 200);
        widgets.add(w);

        w = new ExitButton();
        widgets.add(w);

        setSelectedWidget(w);
    }

    private class TestButton extends Button {

        private int i;

        public TestButton(int x, int y) {
            setGeometry(x, y, 100, 100);
            setColors(0x000000, 0x88AAFF, 0x88AAFF);
            setText("", Font.Align.CENTER, game.font14);
        }

        @Override
        protected void onFire1Down() {
            i++;
            setDirty(true);
        }

        @Override
        public void refresh() {
            setText("" + i);
        }
    }

    private class ExitButton extends Button {

        ExitButton() {
            setGeometry((gui.WIDTH - 180) / 2, gui.HEIGHT - 40 - 20, 180, 40);
            setColor(0xC84200);
            setText(game.gettext("EXIT"), CENTER, game.font14);
        }

        @Override
        public void onFire1Up() {
            onKeyBack();
        }
    }

    @Override
    protected void onKeyBack() {
        game.setScreen(new DeveloperTools(game));
    }

    @Override
    public void render(float deltaTime) {
        super.render(deltaTime);

        game.touchInput.render(batch);
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        game.touchInput.addTouchEvent(TOUCH_DOWN, screenX, screenY);
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        game.touchInput.addTouchEvent(TOUCH_UP, screenX, screenY);
        return true;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        game.touchInput.addTouchEvent(TOUCH_DRAGGED, screenX, screenY);
        return true;
    }

    @Override
    protected void loadAssets() {
        super.loadAssets();
        game.touchInput.loadAssets(assetManager);
    }

    @Override
    protected void getAssets() {
        super.getAssets();
        game.touchInput.getAssets(assetManager);
    }

    @Override
    protected void unloadAssets() {
        super.unloadAssets();
        game.touchInput.unloadAssets(assetManager);
    }
}
