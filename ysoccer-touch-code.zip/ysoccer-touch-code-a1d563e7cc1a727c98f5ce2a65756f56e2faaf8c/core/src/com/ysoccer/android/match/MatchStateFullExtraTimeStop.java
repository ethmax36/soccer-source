package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.FOLLOW_BALL;
import static com.ysoccer.android.match.ActionCamera.Speed.NORMAL;
import static com.ysoccer.android.match.Const.TEAM_SIZE;
import static com.ysoccer.android.match.MatchFsm.STATE_END_POSITIONS;
import static com.ysoccer.android.match.MatchFsm.STATE_FINAL_CELEBRATION;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_CELEBRATION;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_IDLE;
import static com.ysoccer.android.match.SceneFsm.ActionType.NEW_FOREGROUND;

class MatchStateFullExtraTimeStop extends MatchState {

    MatchStateFullExtraTimeStop(MatchFsm fsm) {
        super(fsm);

        displayTime = true;
        displayWindVane = true;
        displayRadar = true;
    }

    @Override
    void entryActions() {
        super.entryActions();

        match.clock = match.length * 120f / 90f;
        getFsm().matchCompleted = true;

        sceneRenderer.sounds.play("end", 1f);

        match.resetAutomaticInputDevices();
        match.setPlayersState(STATE_IDLE, null);

        Team winner = match.competition.getWinner();
        if (winner != null) {
            for (int i = 1; i < TEAM_SIZE; i++) {
                Player player = winner.lineup.get(i);
                player.setState(STATE_CELEBRATION);
            }
        }
    }

    @Override
    void onResume() {
        super.onResume();

        sceneRenderer.actionCamera
                .setMode(FOLLOW_BALL)
                .setSpeed(NORMAL);
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            if (match.subframe % GLGame.SUBFRAMES == 0) {
                match.updateAi();
            }

            match.updateBall();
            match.ball.inFieldKeep();

            match.updatePlayers(false);

            match.nextSubframe();

            sceneRenderer.save();

            sceneRenderer.actionCamera.update();

            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if (timer > 3 * GLGame.VIRTUAL_REFRESH_RATE) {
            if (match.competition.getFinalWinner() != null) {
                return newAction(NEW_FOREGROUND, STATE_FINAL_CELEBRATION);
            } else {
                return newAction(NEW_FOREGROUND, STATE_END_POSITIONS);
            }
        }

        return checkCommonConditions();
    }
}
