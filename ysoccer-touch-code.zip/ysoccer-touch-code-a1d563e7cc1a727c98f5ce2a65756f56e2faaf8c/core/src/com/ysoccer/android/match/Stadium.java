package com.ysoccer.android.match;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.TextureLoader;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLSpriteBatch;
import com.ysoccer.android.framework.RgbPair;

import java.util.ArrayList;
import java.util.List;

public class Stadium {

    private final GLSpriteBatch batch;
    private final Match match;

    private final Sprite goalTopA;
    private final Sprite goalTopB;
    private TextureRegion goalBottom;
    private final TextureRegion[][] textureRegions = new TextureRegion[4][4];
    List<JumperSprite> jumperSprites = new ArrayList<>();

    private final Crowd crowd;

    Stadium(GLSpriteBatch batch, Match match) {
        this.batch = batch;
        this.match = match;

        goalTopA = new GoalTopA(batch);
        goalTopB = new GoalTopB(batch);

        for (int xSide = -1; xSide <= 1; xSide += 2) {
            for (int ySide = -1; ySide <= 1; ySide += 2) {
                jumperSprites.add(new JumperSprite(batch, xSide, ySide));
            }
        }

        crowd = new Crowd(match);
    }

    void addSprites(List<Sprite> sprites) {
        sprites.addAll(jumperSprites);
        sprites.add(goalTopA);
        sprites.add(goalTopB);
    }

    void loadTextures(AssetManager assetManager, SceneSettings sceneSettings) {
        String paletteName = sceneSettings.pitchType.toString().toLowerCase();

        switch (sceneSettings.time) {
            case DAY:
                switch (sceneSettings.sky) {
                    case Sky.CLEAR:
                        paletteName += "_sunny.pal";
                        break;

                    case Sky.CLOUDY:
                        paletteName += "_cloudy.pal";
                        break;
                }
                break;

            case NIGHT:
                paletteName += "_night.pal";
                break;
        }

        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
                parameter.textureData = Assets.loadTextureData("images/stadium/generic_" + c + "" + r + ".png", "images/stadium/palettes/" + paletteName);
                assetManager.load("stadium_" + c + "" + r, Texture.class, parameter);
            }
        }

        assetManager.load("images/stadium.atlas", TextureAtlas.class);

        crowd.loadTexture(assetManager, match.team[Match.HOME]);
    }

    void getTextureRegions(AssetManager assetManager) {
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                Texture t = assetManager.get("stadium_" + c + "" + r);
                textureRegions[r][c] = new TextureRegion(t);
                textureRegions[r][c].flip(false, true);
            }
        }


        // atlas
        TextureAtlas atlas = assetManager.get("images/stadium.atlas");

        TextureAtlas.AtlasRegion atlasRegion;

        atlasRegion = atlas.findRegion("goal_top_a");
        goalTopA.textureRegion = new TextureRegion(atlasRegion);
        goalTopA.textureRegion.flip(false, true);

        atlasRegion = atlas.findRegion("goal_top_b");
        goalTopB.textureRegion = new TextureRegion(atlasRegion);
        goalTopB.textureRegion.flip(false, true);

        atlasRegion = atlas.findRegion("goal_bottom");
        goalBottom = new TextureRegion(atlasRegion);
        goalBottom.flip(false, true);

        atlasRegion = atlas.findRegion("jumper");
        for (JumperSprite j : jumperSprites) {
            j.textureRegion = new TextureRegion(atlasRegion);
            j.textureRegion.flip(false, true);
        }

        crowd.getTextureRegions(assetManager);
    }

    void unloadTextures(AssetManager assetManager) {
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                assetManager.unload("stadium_" + c + "" + r);
            }
        }

        assetManager.unload("images/stadium.atlas");

        crowd.unloadTexture(assetManager);
    }

    void draw() {
        batch.disableBlending();
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                batch.draw(textureRegions[r][c], -Const.CENTER_X + 512 * c, -Const.CENTER_Y + 512 * r);
            }
        }
        batch.enableBlending();

        crowd.draw(batch);
    }

    void redrawBottomGoal() {
        batch.draw(goalBottom, Const.GOAL_BTM_X, Const.GOAL_BTM_Y);
    }

    private static class Crowd {

        private int maxRank;
        private final Group[] groups;
        public final TextureRegion[] textureRegions = new TextureRegion[5];

        private static class Group {
            int x;
            int y;
            int type;
            int rank;
        }

        public Crowd(Match match) {
            FileHandle fileHandle = Gdx.files.internal("images/stadium/crowd.json");
            groups = GLGame.json.fromJson(Group[].class, fileHandle);
            for (Group group : groups) {
                group.x -= Const.CENTER_X;
                group.y -= Const.CENTER_Y;
            }
            setMaxRank(match.getRank());
        }

        private void setMaxRank(int l) {
            maxRank = Math.max(0, l);
        }

        void draw(SpriteBatch batch) {
            for (Group group : groups) {
                if (group.rank <= maxRank) {
                    batch.draw(textureRegions[group.type], group.x, group.y);
                }
            }
        }

        void loadTexture(AssetManager assetManager, Team team) {
            List<RgbPair> rgbPairs = new ArrayList<>();
            TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
            team.kits.get(0).addKitColors(rgbPairs);
            parameter.textureData = Assets.loadTextureData("images/stadium/crowd.png", rgbPairs);
            assetManager.load("crowd", Texture.class, parameter);
        }

        void getTextureRegions(AssetManager assetManager) {
            Texture texture = assetManager.get("crowd");
            textureRegions[0] = new TextureRegion(texture, 0, 0, 47, 35);
            textureRegions[0].flip(false, true);
            textureRegions[1] = new TextureRegion(texture, 70, 0, 47, 35);
            textureRegions[1].flip(false, true);
            textureRegions[2] = new TextureRegion(texture, 0, 38, 47, 26);
            textureRegions[2].flip(false, true);
            textureRegions[3] = new TextureRegion(texture, 49, 29, 23, 35);
            textureRegions[3].flip(false, true);
            textureRegions[4] = new TextureRegion(texture, 105, 29, 23, 35);
            textureRegions[4].flip(false, true);
        }

        void unloadTexture(AssetManager assetManager) {
            assetManager.unload("crowd");
        }
    }
}
