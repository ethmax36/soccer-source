package com.ysoccer.android.match;

import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

public class Coach implements Json.Serializable {

    public String name;
    public String nationality;
    public Team team;

    public float x;
    public float y;
    public int fmx;

    @Override
    public void read(Json json, JsonValue jsonData) {
        json.readFields(this, jsonData);
    }

    @Override
    public void write(Json json) {
        json.writeValue("name", name);
        json.writeValue("nationality", nationality);
    }
}
