package com.ysoccer.android.match;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.GLColor;
import com.ysoccer.android.framework.RgbPair;

import java.util.ArrayList;
import java.util.List;

public class Kit implements Json.Serializable {

    public String style;
    public int shirt1;
    public int shirt2;
    public int shirt3;
    public int shorts;
    public int socks;

    @Override
    public void write(Json json) {
        json.writeValue("style", style);
        json.writeValue("shirt1", GLColor.toHexString(shirt1));
        json.writeValue("shirt2", GLColor.toHexString(shirt2));
        json.writeValue("shirt3", GLColor.toHexString(shirt3));
        json.writeValue("shorts", GLColor.toHexString(shorts));
        json.writeValue("socks", GLColor.toHexString(socks));
    }

    @Override
    public void read(Json json, JsonValue jsonMap) {
        style = jsonMap.getString("style");
        shirt1 = GLColor.valueOf(jsonMap.getString("shirt1"));
        shirt2 = GLColor.valueOf(jsonMap.getString("shirt2"));
        shirt3 = GLColor.valueOf(jsonMap.getString("shirt3", "#000000"));
        shorts = GLColor.valueOf(jsonMap.getString("shorts"));
        socks = GLColor.valueOf(jsonMap.getString("socks"));
    }

    public TextureRegion loadImage() {
        List<RgbPair> rgbPairs = new ArrayList<RgbPair>();
        addKitColors(rgbPairs);
        return Assets.loadTextureRegion("images/kit/" + style + ".png", rgbPairs);
    }

    public void addKitColors(List<RgbPair> rgbPairs) {

        // shirt1
        rgbPairs.add(new RgbPair(0xE20020, shirt1));
        rgbPairs.add(new RgbPair(0xBF001B, GLColor.darker(shirt1, 0.9)));
        rgbPairs.add(new RgbPair(0x9C0016, GLColor.darker(shirt1, 0.8)));
        rgbPairs.add(new RgbPair(0x790011, GLColor.darker(shirt1, 0.7)));

        // shirt2
        rgbPairs.add(new RgbPair(0x01FFC6, shirt2));
        rgbPairs.add(new RgbPair(0x00C79B, GLColor.darker(shirt2, 0.9)));
        rgbPairs.add(new RgbPair(0x008B6C, GLColor.darker(shirt2, 0.8)));
        rgbPairs.add(new RgbPair(0x006A52, GLColor.darker(shirt2, 0.7)));

        // shirt3
        rgbPairs.add(new RgbPair(0xCC00FF, shirt3));
        rgbPairs.add(new RgbPair(0x8600A7, GLColor.darker(shirt3, 0.9)));
        rgbPairs.add(new RgbPair(0x610079, GLColor.darker(shirt3, 0.8)));
        rgbPairs.add(new RgbPair(0x420052, GLColor.darker(shirt3, 0.7)));

        // shorts
        rgbPairs.add(new RgbPair(0xF6FF00, shorts));
        rgbPairs.add(new RgbPair(0xCDD400, GLColor.darker(shorts, 0.9)));
        rgbPairs.add(new RgbPair(0xA3A900, GLColor.darker(shorts, 0.8)));
        rgbPairs.add(new RgbPair(0x7A7E00, GLColor.darker(shorts, 0.7)));

        // socks
        rgbPairs.add(new RgbPair(0x0097EE, socks));
        rgbPairs.add(new RgbPair(0x0088D6, GLColor.darker(socks, 0.9)));
        rgbPairs.add(new RgbPair(0x0079BF, GLColor.darker(socks, 0.8)));
        rgbPairs.add(new RgbPair(0x006AA7, GLColor.darker(socks, 0.7)));
    }

    public static float colorDifference(Kit homeKit, Kit awayKit) {
        int homeColor1 = homeKit.shirt1;
        int homeColor2 = homeKit.shirt2;
        int awayColor1 = awayKit.shirt1;
        int awayColor2 = awayKit.shirt2;
        float differencePair = GLColor.difference(homeColor1, awayColor1) + GLColor.difference(homeColor2, awayColor2);
        float differenceSwap = GLColor.difference(homeColor1, awayColor2) + GLColor.difference(homeColor2, awayColor1);
        return Math.min(differencePair, differenceSwap);
    }
}
