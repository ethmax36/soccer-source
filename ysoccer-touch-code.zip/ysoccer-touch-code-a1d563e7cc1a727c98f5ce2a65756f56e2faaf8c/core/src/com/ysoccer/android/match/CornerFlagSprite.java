package com.ysoccer.android.match;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLSpriteBatch;

class CornerFlagSprite extends Sprite {

    private final Wind wind;
    private final SceneSettings.Time time;
    private final CornerFlagSprites sprites;

    CornerFlagSprite(GLSpriteBatch batch, SceneSettings sceneSettings, int sideX, int sideY, CornerFlagSprites sprites) {
        super(batch);
        this.sprites = sprites;
        wind = sceneSettings.wind;
        time = sceneSettings.time;
        x = sideX * Const.TOUCH_LINE;
        y = sideY * Const.GOAL_LINE;
    }

    @Override
    public void draw(int subframe) {
        int frameX = 2;
        int frameY = 1;
        if (wind.speed > 0) {
            frameX = 2 * (1 + wind.dirX);
            frameX += ((subframe / GLGame.SUBFRAMES) >> (4 - wind.speed)) % 2;
            frameY = 1 + wind.dirY;
        }
        batch.draw(sprites.cornerFlags[frameX][frameY], x - 22, y - 35);
    }

    void drawShadow(int subframe) {
        int frameX = 2;
        int frameY = 1;
        if (wind.speed > 0) {
            frameX = 2 * (1 + wind.dirX);
            frameX += ((subframe / GLGame.SUBFRAMES) >> (4 - wind.speed)) % 2;
            frameY = 1 + wind.dirY;
        }
        TextureRegion[] frame = sprites.cornerFlagsShadows[frameX][frameY];

        batch.draw(frame[0], x - 12, y + 1);
        if (time == MatchSettings.Time.NIGHT) {
            batch.draw(frame[1], x - 28, y + 1);
            batch.draw(frame[2], x - 28, y - 10);
            batch.draw(frame[3], x - 12, y - 10);
        }
    }
}
