package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.REACH_TARGET;
import static com.ysoccer.android.match.ActionCamera.Speed.NORMAL;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;

class MatchStateEnd extends MatchState {

    MatchStateEnd(MatchFsm fsm) {
        super(fsm);

        displayStatistics = true;

        checkReplayKey = false;
        checkPauseKey = false;
    }

    @Override
    void entryActions() {
        super.entryActions();

        match.period = Match.Period.UNDEFINED;

        sceneRenderer.actionCamera
                .setMode(REACH_TARGET)
                .setTarget(0, 0)
                .setSpeed(NORMAL);
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            match.nextSubframe();

            sceneRenderer.save();

            sceneRenderer.actionCamera.update();

            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if (match.team[HOME].fire1Up() != null
                || match.team[AWAY].fire1Up() != null
                || timer > 20 * GLGame.VIRTUAL_REFRESH_RATE) {
            quitMatch();
            return null;
        }

        return checkCommonConditions();
    }
}
