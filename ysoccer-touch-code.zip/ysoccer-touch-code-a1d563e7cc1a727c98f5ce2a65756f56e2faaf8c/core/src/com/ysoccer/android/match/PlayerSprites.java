package com.ysoccer.android.match;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.TextureLoader;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLSpriteBatch;
import com.ysoccer.android.framework.RgbPair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;

class PlayerSprites extends ArrayList<PlayerSprite> {

    private final Match match;
    private final AssetManager assetManager;

    Integer[][][] keeperOrigins;
    Integer[][][] playerOrigins;
    Integer[][][] keeperHairMap;    // row, column, (frameX, frameY, posX, posY)
    Integer[][][] playerHairMap;    // row, column, (frameX, frameY, posX, posY)

    final TextureRegion[][][] keeperShadow = new TextureRegion[8][19][4];
    final TextureRegion[][][] playerShadow = new TextureRegion[8][16][4];
    final TextureRegion[][][][] keeper = new TextureRegion[2][10][8][19];
    final TextureRegion[][][][] player = new TextureRegion[2][10][8][16];

    boolean[][] keeperSkinFlags = new boolean[2][10];
    boolean[][] playerSkinFlags = new boolean[2][10];

    public final List<Map<String, TextureRegion[][]>> hairs = new ArrayList<>();

    public PlayerSprites(Match match, AssetManager assetManager, GLSpriteBatch batch) {
        this.assetManager = assetManager;
        this.match = match;

        for (int i = 0; i < Hair.Color.values().length; i++) {
            Map<String, TextureRegion[][]> m = new HashMap<>();
            hairs.add(m);
        }

        for (int t = HOME; t <= AWAY; t++) {
            for (Player player : match.team[t].lineup) {
                PlayerSprite playerSprite = new PlayerSprite(batch, player, this);
                add(playerSprite);

                flagSkins(t, player);

                hairs.get(player.hairColor.ordinal()).put(player.hairStyle, null);
            }
        }
    }

    private void flagSkins(int t, Player player) {
        if (player.role == Player.Role.GOALKEEPER) {
            keeperSkinFlags[t][player.skinColor.ordinal()] = true;
        } else {
            playerSkinFlags[t][player.skinColor.ordinal()] = true;
        }
    }

    void drawShadows(int subframe, SceneSettings.Time time) {
        for (PlayerSprite playerSprite : this) {
            playerSprite.drawShadow(subframe, time);
        }
    }

    void loadAssets() {
        loadOrigins();
        loadTextures();
        loadHairMaps();
    }

    void getAssets() {
        getOrigins();
        getTextureRegions();
        getHairMaps();
    }

    void unloadAssets() {
        unloadHairMaps();
        unloadTextures();
        unloadOrigins();
    }

    private void loadOrigins() {
        assetManager.load("configs/keeper_origins.json", String.class);
        assetManager.load("configs/player_origins.json", String.class);
    }

    private void getOrigins() {
        String s = assetManager.get("configs/keeper_origins.json");
        keeperOrigins = GLGame.json.fromJson(Integer[][][].class, s);
        s = assetManager.get("configs/player_origins.json");
        playerOrigins = GLGame.json.fromJson(Integer[][][].class, s);
    }

    private void unloadOrigins() {
        assetManager.unload("configs/keeper_origins.json");
        assetManager.unload("configs/player_origins.json");
    }

    private void loadTextures() {
        for (int i = 0; i < 4; i++) {
            assetManager.load("images/player/shadows/keeper_" + i + ".png", Texture.class);
            assetManager.load("images/player/shadows/player_" + i + ".png", Texture.class);
        }
        for (int t = HOME; t <= AWAY; t++) {
            Kit kit = match.team[t].kits.get(match.team[t].kitIndex);
            for (int skin = 0; skin < 10; skin++) {
                if (keeperSkinFlags[t][skin]) {
                    loadKeeperTexture(t, skin);
                }
                if (playerSkinFlags[t][skin]) {
                    loadPlayerTexture(t, kit, skin);
                }
            }
        }

        for (Hair.Color hairColor : Hair.Color.values()) {
            for (String hairStyle : hairs.get(hairColor.ordinal()).keySet()) {
                List<RgbPair> rgbPairs = new ArrayList<>();
                Hair.addHairColors(hairColor, rgbPairs);
                TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
                parameter.textureData = Assets.loadTextureData("images/player/hairstyles/" + hairStyle + ".png", rgbPairs);
                assetManager.load("hair_" + hairColor + "_" + hairStyle, Texture.class, parameter);
            }
        }
    }

    private void loadKeeperTexture(int t, int skin) {
        List<RgbPair> rgbPairs = new ArrayList<>();
        Skin.addSkinColors(rgbPairs, skin);
        TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
        parameter.textureData = Assets.loadTextureData("images/player/keeper.png", rgbPairs);
        assetManager.load("keeper_" + t + "_" + skin, Texture.class, parameter);
    }

    private void loadPlayerTexture(int t, Kit kit, int skin) {
        List<RgbPair> rgbPairs = new ArrayList<>();
        kit.addKitColors(rgbPairs);
        Skin.addSkinColors(rgbPairs, skin);
        TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
        parameter.textureData = Assets.loadTextureData("images/player/" + kit.style + ".png", rgbPairs);
        assetManager.load("player_" + t + "_" + skin, Texture.class, parameter);
    }

    private void getTextureRegions() {
        for (int i = 0; i < 4; i++) {
            Texture texture = assetManager.get("images/player/shadows/keeper_" + i + ".png");
            for (int frameX = 0; frameX < 8; frameX++) {
                for (int frameY = 0; frameY < 19; frameY++) {
                    keeperShadow[frameX][frameY][i] = new TextureRegion(texture, 50 * frameX, 50 * frameY, 50, 50);
                    keeperShadow[frameX][frameY][i].flip(false, true);
                }
            }
            texture = assetManager.get("images/player/shadows/player_" + i + ".png");
            for (int frameX = 0; frameX < 8; frameX++) {
                for (int frameY = 0; frameY < 16; frameY++) {
                    playerShadow[frameX][frameY][i] = new TextureRegion(texture, 32 * frameX, 32 * frameY, 32, 32);
                    playerShadow[frameX][frameY][i].flip(false, true);
                }
            }
        }

        for (int t = HOME; t <= AWAY; t++) {
            for (int s = 0; s < 10; s++) {
                if (keeperSkinFlags[t][s]) {
                    Texture texture = assetManager.get("keeper_" + t + "_" + s);
                    for (int frameX = 0; frameX < 8; frameX++) {
                        for (int frameY = 0; frameY < 19; frameY++) {
                            keeper[t][s][frameX][frameY] = new TextureRegion(texture, 50 * frameX, 50 * frameY, 50, 50);
                            keeper[t][s][frameX][frameY].flip(false, true);
                        }
                    }
                }
                if (playerSkinFlags[t][s]) {
                    Texture texture = assetManager.get("player_" + t + "_" + s);
                    for (int frameX = 0; frameX < 8; frameX++) {
                        for (int frameY = 0; frameY < 16; frameY++) {
                            player[t][s][frameX][frameY] = new TextureRegion(texture, 32 * frameX, 32 * frameY, 32, 32);
                            player[t][s][frameX][frameY].flip(false, true);
                        }
                    }
                }
            }
        }

        for (Hair.Color hairColor : Hair.Color.values()) {
            Map<String, TextureRegion[][]> hairStyles = hairs.get(hairColor.ordinal());
            for (String hairStyle : hairStyles.keySet()) {
                Texture texture = assetManager.get("hair_" + hairColor + "_" + hairStyle);
                TextureRegion[][] textureRegion = new TextureRegion[8][10];
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 10; j++) {
                        textureRegion[i][j] = new TextureRegion(texture, 21 * i, 21 * j, 20, 20);
                        textureRegion[i][j].flip(false, true);
                    }
                }
                hairStyles.put(hairStyle, textureRegion);
            }
        }
    }

    private void unloadTextures() {
        for (int i = 0; i < 4; i++) {
            assetManager.unload("images/player/shadows/keeper_" + i + ".png");
            assetManager.unload("images/player/shadows/player_" + i + ".png");
        }
        for (int t = HOME; t <= AWAY; t++) {
            for (int s = 0; s < 10; s++) {
                if (keeperSkinFlags[t][s]) {
                    assetManager.unload("keeper_" + t + "_" + s);
                }
                if (playerSkinFlags[t][s]) {
                    assetManager.unload("player_" + t + "_" + s);
                }
            }
        }
        for (Hair.Color hairColor : Hair.Color.values()) {
            Map<String, TextureRegion[][]> hairStyles = hairs.get(hairColor.ordinal());
            for (String hairStyle : hairStyles.keySet()) {
                assetManager.unload("hair_" + hairColor + "_" + hairStyle);
            }
        }
    }

    private void loadHairMaps() {
        assetManager.load("configs/keeper_hair_map.json", String.class);
        assetManager.load("configs/player_hair_map.json", String.class);
    }

    private void getHairMaps() {
        String s = assetManager.get("configs/keeper_hair_map.json");
        keeperHairMap = GLGame.json.fromJson(Integer[][][].class, s);
        s = assetManager.get("configs/player_hair_map.json");
        playerHairMap = GLGame.json.fromJson(Integer[][][].class, s);
    }

    private void unloadHairMaps() {
        assetManager.unload("configs/keeper_hair_map.json");
        assetManager.unload("configs/player_hair_map.json");
    }
}
