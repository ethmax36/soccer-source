package com.ysoccer.android.match;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.TextureLoader;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.GLSpriteBatch;
import com.ysoccer.android.framework.RgbPair;

import java.util.ArrayList;
import java.util.List;

class CoachSprite extends Sprite {

    private final Coach coach;
    private final TextureRegion[] textureRegions = new TextureRegion[6];

    CoachSprite(GLSpriteBatch batch, Coach coach) {
        super(batch);
        this.coach = coach;
    }

    @Override
    public void draw(int subframe) {
        batch.draw(textureRegions[coach.fmx], coach.x - 7, coach.y - 25);
    }

    void loadTexture(AssetManager assetManager) {
        List<RgbPair> rgbPairs = new ArrayList<>();
        coach.team.kits.get(0).addKitColors(rgbPairs);
        TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
        parameter.textureData = Assets.loadTextureData("images/coach.png", rgbPairs);
        assetManager.load("coach_" + coach.team.index, Texture.class, parameter);
    }

    void getTextureRegions(AssetManager assetManager) {
        Texture texture = assetManager.get("coach_" + coach.team.index);
        for (int i = 0; i < 6; i++) {
            textureRegions[i] = new TextureRegion(texture, 21 * i, 0, 21, 29);
            textureRegions[i].flip(false, true);
        }
    }

    void unloadTexture(AssetManager assetManager) {
        assetManager.unload("coach_" + coach.team.index);
    }
}
