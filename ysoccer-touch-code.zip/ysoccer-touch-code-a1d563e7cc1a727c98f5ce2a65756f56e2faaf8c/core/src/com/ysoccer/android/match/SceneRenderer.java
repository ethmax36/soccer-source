package com.ysoccer.android.match;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.ysoccer.android.framework.GLGraphics;
import com.ysoccer.android.framework.GLShapeRenderer;
import com.ysoccer.android.framework.GLSpriteBatch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ysoccer.android.util.Constants.GUI_WIDTH;

public abstract class SceneRenderer {

    private static final float VISIBLE_FIELD_WIDTH_MAX = 0.85f;
    private static final float VISIBLE_FIELD_WIDTH_OPT = 0.75f;
    private static final float VISIBLE_FIELD_WIDTH_MIN = 0.55f;

    public static int zoomMin() {
        return 5 * (int) (20.0f * VISIBLE_FIELD_WIDTH_OPT / VISIBLE_FIELD_WIDTH_MAX);
    }

    public static int zoomMax() {
        return 5 * (int) (20.0f * VISIBLE_FIELD_WIDTH_OPT / VISIBLE_FIELD_WIDTH_MIN);
    }

    static final float guiAlpha = 0.9f;

    final Scene scene;
    final GLSpriteBatch batch;
    protected GLShapeRenderer shapeRenderer;
    OrthographicCamera camera;
    int screenWidth;
    int screenHeight;
    int zoom;
    int light;
    final int guiWidth = GUI_WIDTH;
    int guiHeight;

    public ActionCamera actionCamera;
    final int[] vCameraX = new int[Const.REPLAY_SUBFRAMES];
    final int[] vCameraY = new int[Const.REPLAY_SUBFRAMES];

    Ball ball;

    final AssetManager assetManager;

    final List<Sprite> allSprites = new ArrayList<>();
    final Sprite.SpriteComparator spriteComparator = new Sprite.SpriteComparator();

    final WeatherEffects weatherEffects;

    final Sounds sounds;

    protected SceneRenderer(GLGraphics glGraphics, Scene scene) {
        this.scene = scene;
        this.batch = glGraphics.batch;
        this.shapeRenderer = glGraphics.shapeRenderer;
        this.assetManager = scene.game.assetManager;
        this.weatherEffects = new WeatherEffects(this);
        this.sounds = new Sounds(scene);
    }

    abstract public void render();

    void resize(int width, int height, int newZoom) {
        screenWidth = width;
        screenHeight = height;
        float zoomMin = width / (VISIBLE_FIELD_WIDTH_MAX * 2 * Const.TOUCH_LINE);
        float zoomOpt = width / (VISIBLE_FIELD_WIDTH_OPT * 2 * Const.TOUCH_LINE);
        float zoomMax = width / (VISIBLE_FIELD_WIDTH_MIN * 2 * Const.TOUCH_LINE);
        zoom = 20 * (int) (5.0f * Math.min(Math.max(0.01f * newZoom * zoomOpt, zoomMin), zoomMax));

        actionCamera.setScreenParameters(screenWidth, screenHeight, zoom);

        guiHeight = guiWidth * height / width;
    }

    abstract void save();

    void renderSprites() {

        drawShadows();

        spriteComparator.setSubframe(scene.subframe);
        Collections.sort(allSprites, spriteComparator);

        for (Sprite sprite : allSprites) {
            sprite.draw(scene.subframe);
        }
    }

    abstract void drawShadows();

    void fadeRect(int x0, int y0, int x1, int y1, float alpha, int color) {
        shapeRenderer.setColor(color, alpha);
        shapeRenderer.rect(x0, y0, x1 - x0, y1 - y0);
    }

    void drawFrame(int x, int y, int w, int h) {
        int r = x + w;
        int b = y + h;

        // top
        shapeRenderer.rect(x + 5, y, w - 8, 1);
        shapeRenderer.rect(x + 3, y + 1, w - 4, 1);

        // top-left
        shapeRenderer.rect(x + 2, y + 2, 4, 1);
        shapeRenderer.rect(x + 2, y + 3, 1, 3);
        shapeRenderer.rect(x + 3, y + 3, 1, 1);

        // top-right
        shapeRenderer.rect(r - 4, y + 2, 4, 1);
        shapeRenderer.rect(r - 1, y + 3, 1, 3);
        shapeRenderer.rect(r - 2, y + 3, 1, 1);

        // left
        shapeRenderer.rect(x, y + 5, 1, h - 8);
        shapeRenderer.rect(x + 1, y + 3, 1, h - 4);

        // right
        shapeRenderer.rect(r + 1, y + 5, 1, h - 8);
        shapeRenderer.rect(r, y + 3, 1, h - 4);

        // bottom-left
        shapeRenderer.rect(x + 2, b - 4, 1, 3);
        shapeRenderer.rect(x + 2, b - 1, 4, 1);
        shapeRenderer.rect(x + 3, b - 2, 1, 1);

        // bottom-right
        shapeRenderer.rect(r - 1, b - 4, 1, 3);
        shapeRenderer.rect(r - 4, b - 1, 4, 1);
        shapeRenderer.rect(r - 2, b - 2, 1, 1);

        // bottom
        shapeRenderer.rect(x + 5, b + 1, w - 8, 1);
        shapeRenderer.rect(x + 3, b, w - 4, 1);
    }

    void loadAssets() {
        weatherEffects.loadTextures(assetManager);
        sounds.loadAssets(assetManager);
    }

    void getAssets() {
        weatherEffects.getTextureRegions(assetManager);
        sounds.getAssets(assetManager);
    }

    void unloadAssets() {
        weatherEffects.unloadTextures(assetManager);
        sounds.unloadAssets(assetManager);
    }

    void quit() {
    }
}
