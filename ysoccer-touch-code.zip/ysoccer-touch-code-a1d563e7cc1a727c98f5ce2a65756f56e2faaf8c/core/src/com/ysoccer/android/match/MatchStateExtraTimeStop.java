package com.ysoccer.android.match;

import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.FOLLOW_BALL;
import static com.ysoccer.android.match.ActionCamera.Speed.NORMAL;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;
import static com.ysoccer.android.match.MatchFsm.STATE_STARTING_POSITIONS;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_IDLE;
import static com.ysoccer.android.match.SceneFsm.ActionType.NEW_FOREGROUND;

class MatchStateExtraTimeStop extends MatchState {

    MatchStateExtraTimeStop(MatchFsm fsm) {
        super(fsm);

        displayTime = true;
        displayWindVane = true;
        displayRadar = true;
    }

    @Override
    void entryActions() {
        super.entryActions();

        sceneRenderer.sounds.play("end", 1f);

        match.resetAutomaticInputDevices();
        match.setPlayersState(STATE_IDLE, null);
    }

    @Override
    void onResume() {
        super.onResume();

        sceneRenderer.actionCamera
                .setMode(FOLLOW_BALL)
                .setSpeed(NORMAL);
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            if (match.subframe % GLGame.SUBFRAMES == 0) {
                match.updateAi();
            }

            match.updateBall();
            match.ball.inFieldKeep();

            match.updatePlayers(true);

            match.nextSubframe();

            sceneRenderer.save();

            sceneRenderer.actionCamera.update();

            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if (timer > 3 * GLGame.VIRTUAL_REFRESH_RATE) {
            match.ball.setPosition(0, 0, 0);
            match.ball.updatePrediction();

            sceneRenderer.actionCamera.setOffset(0, 0);

            // redo coin toss
            match.coinToss = Assets.random.nextInt(2); // 0 = home begins, 1 = away begins
            match.kickOffTeam = match.coinToss;

            // reassign teams sides
            match.team[HOME].setSide(1 - 2 * Assets.random.nextInt(2)); // -1 = up, 1 = down
            match.team[AWAY].setSide(-match.team[HOME].side);

            match.period = Match.Period.FIRST_EXTRA_TIME;
            match.clock = match.length;

            return newAction(NEW_FOREGROUND, STATE_STARTING_POSITIONS);
        }

        return checkCommonConditions();
    }
}
