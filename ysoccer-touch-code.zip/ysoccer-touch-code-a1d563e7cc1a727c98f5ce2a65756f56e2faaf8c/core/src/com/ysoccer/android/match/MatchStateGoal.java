package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.FOLLOW_BALL;
import static com.ysoccer.android.match.ActionCamera.Mode.REACH_TARGET;
import static com.ysoccer.android.match.ActionCamera.Speed.FAST;
import static com.ysoccer.android.match.ActionCamera.Speed.NORMAL;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;
import static com.ysoccer.android.match.MatchFsm.STATE_REPLAY;
import static com.ysoccer.android.match.MatchFsm.STATE_STARTING_POSITIONS;
import static com.ysoccer.android.match.SceneFsm.ActionType.HOLD_FOREGROUND;
import static com.ysoccer.android.match.SceneFsm.ActionType.NEW_FOREGROUND;

class MatchStateGoal extends MatchState {

    private Goal goal;
    private boolean replayDone;
    private boolean recordingDone;
    private boolean followBall;

    MatchStateGoal(MatchFsm fsm) {
        super(fsm);

        displayTime = true;
        displayWindVane = true;
        displayRadar = true;

        checkReplayKey = false;
    }

    @Override
    void entryActions() {
        super.entryActions();

        replayDone = false;
        recordingDone = false;
        followBall = true;

        sceneRenderer.sounds.play("goal", 1f);

        goal = match.goals.get(match.goals.size() - 1);

        if (match.team[HOME].side == match.ball.ySide) {
            match.kickOffTeam = HOME;
        } else if (match.team[AWAY].side == match.ball.ySide) {
            match.kickOffTeam = AWAY;
        } else {
            throw new RuntimeException("cannot decide kick_off_team!");
        }

        match.resetAutomaticInputDevices();

        match.setPointOfInterest(match.ball.x, match.ball.y);

        sceneRenderer.actionCamera.setLimited(true, true);
    }

    @Override
    void onResume() {
        super.onResume();

        setCameraMode();
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        // set states
        if (goal.type == Goal.Type.OWN_GOAL) {
            match.setStatesForOwnGoal(goal);
        } else {
            match.setStatesForGoal(goal);
        }

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            if (match.subframe % GLGame.SUBFRAMES == 0) {
                match.updateAi();
            }

            match.updateBall();
            match.ball.collisionGoal();
            match.ball.collisionNet();

            match.updatePlayers(true);

            match.nextSubframe();

            sceneRenderer.save();

            if (followBall) {
                if (match.ball.v == 0 && match.ball.vz == 0) {
                    followBall = false;
                    setCameraMode();
                }
            } else {
                sceneRenderer.actionCamera.setTarget(goal.player.x, goal.player.y);
            }
            sceneRenderer.actionCamera.update();
            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    private void setCameraMode() {
        if (followBall) {
            sceneRenderer.actionCamera
                    .setMode(FOLLOW_BALL)
                    .setSpeed(NORMAL);
        } else {
            sceneRenderer.actionCamera
                    .setMode(REACH_TARGET)
                    .setSpeed(FAST);
        }
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if ((match.ball.v < 5) && (match.ball.vz < 5)
                && (timer > 3 * GLGame.VIRTUAL_REFRESH_RATE)) {

            if (!recordingDone) {
                match.recorder.saveHighlight(sceneRenderer);
                recordingDone = true;
            }

            if (match.getSettings().autoReplays && !replayDone) {
                replayDone = true;
                return newFadedAction(HOLD_FOREGROUND, STATE_REPLAY);
            } else {
                match.ball.setPosition(0, 0, 0);
                match.ball.updatePrediction();
                sceneRenderer.actionCamera.setOffset(0, 0);

                return newAction(NEW_FOREGROUND, STATE_STARTING_POSITIONS);
            }
        }

        return checkCommonConditions();
    }
}
