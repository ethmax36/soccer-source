package com.ysoccer.android.match;

import com.ysoccer.android.framework.Color3;
import com.ysoccer.android.framework.RgbPair;

import java.util.List;

public class Hair {

    public enum Color {BLACK, BLOND, BROWN, RED, PLATINUM, GRAY, WHITE, PUNK_FUCHSIA, PUNK_BLOND}

    public static Color3[] colors = {
            new Color3(0x2A2A2A, 0x1A1A1A, 0x090909), // BLACK
            new Color3(0xA2A022, 0x81801A, 0x605F11), // BLOND
            new Color3(0xA26422, 0x7B4C1A, 0x543411), // BROWN
            new Color3(0xE48B00, 0xB26D01, 0x7F4E01), // RED
            new Color3(0xFFFD7E, 0xE5E33F, 0xCAC800), // PLATINUM
            new Color3(0x7A7A7A, 0x4E4E4E, 0x222222), // GRAY
            new Color3(0xD5D5D5, 0xADADAD, 0x848484), // WHITE
            new Color3(0xFF00A8, 0x722F2F, 0x421A1A), // PUNK_FUCHSIA
            new Color3(0xFDFB35, 0x808202, 0x595A05), // PUNK_BLOND
    };

    public static void addHairColors(Hair.Color hairColor, List<RgbPair> rgbPairs) {
        Color3 hc = Hair.colors[hairColor.ordinal()];
        rgbPairs.add(new RgbPair(0x907130, hc.color1));
        rgbPairs.add(new RgbPair(0x715930, hc.color2));
        rgbPairs.add(new RgbPair(0x514030, hc.color3));
    }
}
