package com.ysoccer.android.match;

import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.REACH_TARGET;
import static com.ysoccer.android.match.ActionCamera.Speed.NORMAL;
import static com.ysoccer.android.match.Const.GOAL_LINE;
import static com.ysoccer.android.match.MatchFsm.STATE_PENALTIES;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_IDLE;
import static com.ysoccer.android.match.SceneFsm.ActionType.NEW_FOREGROUND;

class MatchStatePenaltiesStop extends MatchState {

    MatchStatePenaltiesStop(MatchFsm fsm) {
        super(fsm);

        displayWindVane = true;
    }

    @Override
    void entryActions() {
        super.entryActions();

        sceneRenderer.sounds.play("end", 1f);

        match.resetAutomaticInputDevices();
        match.setPlayersState(STATE_IDLE, null);
    }

    @Override
    void onResume() {
        super.onResume();

        sceneRenderer.actionCamera
                .setMode(REACH_TARGET)
                .setTarget(0, -GOAL_LINE)
                .setOffset(0, 0)
                .setSpeed(NORMAL);
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            if (match.subframe % GLGame.SUBFRAMES == 0) {
                match.updateAi();
            }

            match.updateBall();
            match.ball.inFieldKeep();

            match.updatePlayers(false);

            match.nextSubframe();

            sceneRenderer.save();

            sceneRenderer.actionCamera.update();

            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if (timer > 3 * GLGame.VIRTUAL_REFRESH_RATE) {
            match.ball.setPosition(0, -Const.PENALTY_SPOT_Y, 0);
            match.ball.updatePrediction();

            match.penaltyKickingTeam = Assets.random.nextInt(2);

            match.period = Match.Period.PENALTIES;

            match.addPenalties(5);

            return newAction(NEW_FOREGROUND, STATE_PENALTIES);
        }

        return checkCommonConditions();
    }
}
