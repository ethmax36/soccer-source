package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLSpriteBatch;

import static com.ysoccer.android.match.Const.GOAL_LINE;

class GoalTopA extends Sprite {

    GoalTopA(GLSpriteBatch batch) {
        super(batch);
        x = -73;
        y = -691;
    }

    @Override
    public int getY(int subframe) {
        return -GOAL_LINE;
    }
}
