package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.FOLLOW_BALL;
import static com.ysoccer.android.match.ActionCamera.Speed.FAST;
import static com.ysoccer.android.match.MatchFsm.STATE_KICK_OFF;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_REACH_TARGET;
import static com.ysoccer.android.match.SceneFsm.ActionType.NEW_FOREGROUND;

class MatchStateStartingPositions extends MatchState {

    private boolean move;

    MatchStateStartingPositions(MatchFsm fsm) {
        super(fsm);

        displayTime = true;
        displayWindVane = true;
        displayRadar = true;
    }

    @Override
    void entryActions() {
        super.entryActions();

        match.setStartingPositions();
        match.setPlayersState(STATE_REACH_TARGET, null);
        match.setPointOfInterest(match.ball.x, match.ball.y);
    }

    @Override
    void onResume() {
        sceneRenderer.actionCamera
                .setMode(FOLLOW_BALL)
                .setSpeed(FAST)
                .setLimited(true, true);
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            move = match.updatePlayers(false);

            match.nextSubframe();

            sceneRenderer.save();

            sceneRenderer.actionCamera.update();

            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if (!move) {
            return newAction(NEW_FOREGROUND, STATE_KICK_OFF);
        }

        return checkCommonConditions();
    }
}
