package com.ysoccer.android.match;

import com.badlogic.gdx.Gdx;

import static com.badlogic.gdx.Input.Keys.P;
import static com.badlogic.gdx.Input.Keys.R;
import static com.ysoccer.android.match.MatchFsm.STATE_PAUSE;
import static com.ysoccer.android.match.MatchFsm.STATE_REPLAY;
import static com.ysoccer.android.match.SceneFsm.ActionType.HOLD_FOREGROUND;

abstract class MatchState extends SceneState {

    boolean displayControlledPlayer;
    boolean displayBallOwner;
    boolean displayTime;
    boolean displayWindVane;
    boolean displayScore;
    boolean displayPenaltiesScore;
    boolean displayStatistics;
    boolean displayRadar;

    boolean checkReplayKey = true;
    boolean checkPauseKey = true;
    boolean screenPaused = false;
    boolean keyBack = false;

    final Match match;
    final Ball ball;

    MatchState(MatchFsm matchFsm) {
        super(matchFsm);

        this.match = matchFsm.getMatch();
        this.ball = match.ball;
    }

    MatchFsm getFsm() {
        return (MatchFsm) fsm;
    }

    SceneFsm.Action[] checkCommonConditions() {

        if (checkReplayKey && Gdx.input.isKeyPressed(R)) {
            return newFadedAction(HOLD_FOREGROUND, STATE_REPLAY);
        }

        if (checkPauseKey && Gdx.input.isKeyPressed(P)) {
            return newAction(HOLD_FOREGROUND, STATE_PAUSE);
        }

        if (keyBack) {
            keyBack = false;
            if (checkPauseKey) {
                return newAction(HOLD_FOREGROUND, STATE_PAUSE);
            } else {
                quitMatch();
            }
        }

        if (screenPaused) {
            screenPaused = false;
            if (checkPauseKey) {
                return newAction(HOLD_FOREGROUND, STATE_PAUSE);
            }
        }

        return null;
    }

    void quitMatch() {
        match.quit();
    }

    void onScreenPaused() {
        screenPaused = true;
    }

    void onKeyBack() {
        keyBack = true;
    }
}
