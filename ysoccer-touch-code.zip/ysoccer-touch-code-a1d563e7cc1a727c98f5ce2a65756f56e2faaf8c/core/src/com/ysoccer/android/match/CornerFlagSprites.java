package com.ysoccer.android.match;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.TextureLoader;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.GLSpriteBatch;
import com.ysoccer.android.framework.RgbPair;

import java.util.ArrayList;
import java.util.List;

class CornerFlagSprites extends ArrayList<CornerFlagSprite> {

    public final TextureRegion[][] cornerFlags = new TextureRegion[6][3];
    public final TextureRegion[][][] cornerFlagsShadows = new TextureRegion[6][3][4];

    public CornerFlagSprites(Match match, GLSpriteBatch batch) {
        for (int i = 0; i < 4; i++) {
            CornerFlagSprite cornerFlagSprite = new CornerFlagSprite(batch, match.settings, i / 2 * 2 - 1, i % 2 * 2 - 1, this);
            add(cornerFlagSprite);
        }
    }

    public void drawShadows(int subframe) {
        for (CornerFlagSprite cornerFlagSprite : this) {
            cornerFlagSprite.drawShadow(subframe);
        }
    }

    public void loadTexture(AssetManager assetManager, SceneSettings.Time time, Grass grass) {
        List<RgbPair> rgbPairs = new ArrayList<>();
        switch (time) {
            case DAY:
                rgbPairs.add(new RgbPair(0x291000, grass.darkShadow));
                break;

            case NIGHT:
                rgbPairs.add(new RgbPair(0x291000, grass.lightShadow));
                break;
        }
        TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
        parameter.textureData = Assets.loadTextureData("images/stadium/corner_flags.png", rgbPairs);
        assetManager.load("corner_flags", Texture.class, parameter);
    }

    public void getTextureRegions(AssetManager assetManager) {
        Texture texture = assetManager.get("corner_flags");
        for (int frameX = 0; frameX < 6; frameX++) {
            for (int frameY = 0; frameY < 3; frameY++) {
                cornerFlags[frameX][frameY] = new TextureRegion(texture, 42 * frameX, 84 * frameY, 42, 36);
                cornerFlags[frameX][frameY].flip(false, true);
                for (int i = 0; i < 4; i++) {
                    cornerFlagsShadows[frameX][frameY][i] = new TextureRegion(texture, 42 * frameX, 84 * frameY + 36 + 12 * i, 42, 12);
                    cornerFlagsShadows[frameX][frameY][i].flip(false, true);
                }
            }
        }
    }

    public void unloadTexture(AssetManager assetManager) {
        assetManager.unload("corner_flags");
    }
}
