package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLSpriteBatch;

import static com.ysoccer.android.match.Const.JUMPER_H;
import static com.ysoccer.android.match.Const.JUMPER_X;
import static com.ysoccer.android.match.Const.JUMPER_Y;

class JumperSprite extends Sprite {

    JumperSprite(GLSpriteBatch batch, int xSide, int ySide) {
        super(batch);
        x = xSide * JUMPER_X -1;
        y = ySide * JUMPER_Y - JUMPER_H -1;
    }

    @Override
    public int getY(int subframe) {
        return y + JUMPER_H;
    }
}
