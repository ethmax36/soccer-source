package com.ysoccer.android.match;

public class MatchStats {
    public int goals;
    public int ballPossession = 1;
    public int overallShots;
    public int centeredShots;
    public int cornersWon;
    public int foulsConceded;
    public int yellowCards;
    public int redCards;
}
