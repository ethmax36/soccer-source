package com.ysoccer.android.match;

public class Data {
    public int x;
    public int y;
    public int z;
    public int fmx;
    public int fmy;
    public boolean isVisible;
    public boolean isHumanControlled;
}
