package com.ysoccer.android.match;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.EMath;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.GLSpriteBatch;

public class WeatherEffects {

    public static final int WIND = 0;
    public static final int RAIN = 1;
    public static final int SNOW = 2;
    public static final int FOG = 3;
    public static final int RANDOM = 4;

    public static class Strength {

        public static final int NONE = 0;
        public static final int LIGHT = 1;
        public static final int STRONG = 2;

        public static final String[] names = {"WEATHER.EFFECTS.OFF", "WEATHER.EFFECTS.LIGHT", "WEATHER.EFFECTS.STRONG"};
    }

    public static int[][] cap = {
            //      wind            rain           snow            fog
            {Strength.STRONG, Strength.NONE, Strength.LIGHT, Strength.NONE}, // frozen
            {Strength.STRONG, Strength.STRONG, Strength.NONE, Strength.STRONG}, // muddy
            {Strength.STRONG, Strength.STRONG, Strength.NONE, Strength.STRONG}, // wet
            {Strength.STRONG, Strength.LIGHT, Strength.NONE, Strength.STRONG}, // soft
            {Strength.STRONG, Strength.NONE, Strength.NONE, Strength.STRONG}, // normal
            {Strength.STRONG, Strength.NONE, Strength.NONE, Strength.NONE}, // dry
            {Strength.STRONG, Strength.NONE, Strength.NONE, Strength.STRONG}, // hard
            {Strength.STRONG, Strength.NONE, Strength.STRONG, Strength.STRONG}, // snowed
            {Strength.STRONG, Strength.NONE, Strength.STRONG, Strength.STRONG} // white
    };

    private final SceneRenderer sceneRenderer;
    private final GLSpriteBatch batch;
    private final SceneSettings sceneSettings;
    private final int modW = Const.REPLAY_FRAMES;
    private final int modH = 2 * Const.REPLAY_FRAMES;
    private final int modX = (int) Math.ceil(Const.PITCH_W / ((float) modW));
    private final int modY = (int) Math.ceil(Const.PITCH_H / ((float) modH));

    private final TextureRegion[] rain = new TextureRegion[4];
    private final TextureRegion[] snow = new TextureRegion[3];
    public Texture fog;

    WeatherEffects(SceneRenderer sceneRenderer) {
        this.sceneRenderer = sceneRenderer;
        this.batch = sceneRenderer.batch;
        this.sceneSettings = sceneRenderer.scene.settings;
    }

    public void loadTextures(AssetManager assetManager) {
        if (sceneSettings.weatherStrength != Strength.NONE) {
            switch (sceneSettings.weatherEffect) {
                case RAIN:
                    assetManager.load("images/weather/rain.png", Texture.class);
                    break;

                case SNOW:
                    assetManager.load("images/weather/snow.png", Texture.class);
                    break;

                case FOG:
                    assetManager.load("images/weather/fog.png", Texture.class);
                    break;
            }
        }
    }

    public void getTextureRegions(AssetManager assetManager) {
        if (sceneSettings.weatherStrength != Strength.NONE) {
            Texture texture;
            switch (sceneSettings.weatherEffect) {
                case RAIN:
                    texture = assetManager.get("images/weather/rain.png");
                    for (int i = 0; i < 4; i++) {
                        rain[i] = new TextureRegion(texture, 30 * i, 0, 30, 30);
                        rain[i].flip(false, true);
                    }
                    break;

                case SNOW:
                    texture = assetManager.get("images/weather/snow.png");
                    for (int i = 0; i < 3; i++) {
                        snow[i] = new TextureRegion(texture, 3 * i, 0, 3, 3);
                        snow[i].flip(false, true);
                    }
                    break;

                case FOG:
                    fog = assetManager.get("images/weather/fog.png");
                    break;
            }
        }
    }

    public void unloadTextures(AssetManager assetManager) {
        if (sceneSettings.weatherStrength != Strength.NONE) {
            switch (sceneSettings.weatherEffect) {
                case RAIN:
                    assetManager.unload("images/weather/rain.png");
                    break;

                case SNOW:
                    assetManager.unload("images/weather/snow.png");
                    break;

                case FOG:
                    assetManager.unload("images/weather/fog.png");
                    break;
            }
        }
    }

    public void draw(int subframe) {
        if (sceneSettings.weatherStrength != Strength.NONE) {
            switch (sceneSettings.weatherEffect) {
                case RAIN:
                    drawRain(subframe);
                    break;

                case SNOW:
                    drawSnow(subframe);
                    break;

                case FOG:
                    drawFog(subframe);
                    break;
            }
        }
    }

    void drawRain(int subframe) {
        batch.setColor(0xFFFFFF, 0.6f);
        Assets.random.setSeed(1);
        for (int i = 1; i <= 40 * sceneSettings.weatherStrength; i++) {
            int x = Assets.random.nextInt(modW);
            int y = Assets.random.nextInt(modH);
            int h = (Assets.random.nextInt(modH) + subframe) % modH;
            if (h > 0.3f * modH) {
                for (int fx = 0; fx <= modX; fx++) {
                    for (int fy = 0; fy <= modY; fy++) {
                        int px = ((x + modW - Math.round(subframe / ((float) GLGame.SUBFRAMES))) % modW) + modW * (fx - 1);
                        int py = ((y + 4 * Math.round(1f * subframe / GLGame.SUBFRAMES)) % modH) + modH * (fy - 1);
                        int f = 3 * h / modH;
                        if (h > 0.9f * modH) {
                            f = 3;
                        }
                        batch.draw(rain[f], -Const.CENTER_X + px, -Const.CENTER_Y + py);
                    }
                }
            }
        }
        Assets.random.setSeed(System.currentTimeMillis());
        batch.setColor(0xFFFFFF, 1f);
    }

    void drawSnow(int subframe) {
        batch.setColor(0xFFFFFF, 0.7f);

        Assets.random.setSeed(1);
        for (int i = 1; i <= 30 * sceneSettings.weatherStrength; i++) {
            int x = Assets.random.nextInt(modW);
            int y = Assets.random.nextInt(modH);
            int s = i % 3;
            int a = Assets.random.nextInt(360);
            for (int fx = 0; fx <= modX; fx++) {
                for (int fy = 0; fy <= modY; fy++) {
                    int px = (int) (((x + modW + 30 * EMath.sin(360 * subframe / ((float) Const.REPLAY_SUBFRAMES) + a)) % modW) + modW * (fx - 1));
                    int py = ((y + 2 * Math.round(1f * subframe / GLGame.SUBFRAMES)) % modH) + modH * (fy - 1);
                    batch.draw(snow[s], -Const.CENTER_X + px, -Const.CENTER_Y + py);
                }
            }
        }
        Assets.random.setSeed(System.currentTimeMillis());
        batch.setColor(0xFFFFFF, 1f);
    }

    void drawFog(int subframe) {
        batch.setColor(0xFFFFFF, 0.25f * sceneSettings.weatherStrength);

        int TILE_WIDTH = 256;
        int fogX = -Const.CENTER_X + sceneRenderer.vCameraX[subframe] - 2 * TILE_WIDTH
                + ((Const.CENTER_X - sceneRenderer.vCameraX[subframe]) % TILE_WIDTH + 2 * TILE_WIDTH) % TILE_WIDTH;
        int fogY = -Const.CENTER_Y + sceneRenderer.vCameraY[subframe] - 2 * TILE_WIDTH
                + ((Const.CENTER_Y - sceneRenderer.vCameraY[subframe]) % TILE_WIDTH + 2 * TILE_WIDTH) % TILE_WIDTH;
        int x = fogX;
        while (x < (fogX + sceneRenderer.screenWidth + 2 * TILE_WIDTH)) {
            int y = fogY;
            while (y < (fogY + sceneRenderer.screenHeight + 2 * TILE_WIDTH)) {
                batch.draw(fog, x + ((1f * subframe / GLGame.SUBFRAMES) % TILE_WIDTH), y + ((2f * subframe / GLGame.SUBFRAMES) % TILE_WIDTH), 256, 256, 0, 0, 256, 256, false, true);
                y = y + TILE_WIDTH;
            }
            x = x + TILE_WIDTH;
        }
        batch.setColor(0xFFFFFF, 1f);
    }
}
