package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.framework.EMath;

import static com.ysoccer.android.match.AiFsm.Id.STATE_THROWING_IN;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_THROW_IN_ANGLE;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_THROW_IN_SPEED;

class AiStateThrowingIn extends AiState {

    AiStateThrowingIn(AiFsm fsm) {
        super(STATE_THROWING_IN, fsm);
    }

    @Override
    void doActions() {
        super.doActions();
        if (timer > 1.5f * GLGame.VIRTUAL_REFRESH_RATE) {
            ai.x0 = player.team.side;
        }
        ai.fire10 = EMath.isIn(timer, 2.0f * GLGame.VIRTUAL_REFRESH_RATE, 2.31f * GLGame.VIRTUAL_REFRESH_RATE);
    }

    @Override
    State checkConditions() {
        PlayerState playerState = player.getState();
        if (playerState.checkId(STATE_THROW_IN_ANGLE)) {
            return null;
        }
        if (playerState.checkId(STATE_THROW_IN_SPEED)) {
            return null;
        }

        return fsm.stateIdle;
    }
}
