package com.ysoccer.android.match;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.TextureLoader;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.Assets;
import com.ysoccer.android.framework.EMath;
import com.ysoccer.android.framework.GLSpriteBatch;
import com.ysoccer.android.framework.RgbPair;

import java.util.ArrayList;
import java.util.List;

import static com.ysoccer.android.match.Const.BALL_R;
import static com.ysoccer.android.match.Const.CROSSBAR_H;
import static com.ysoccer.android.match.Const.GOAL_LINE;
import static com.ysoccer.android.match.Const.POST_X;
import static com.ysoccer.android.match.Const.isInsideGoal;

class BallSprite extends Sprite {

    Ball ball;
    public final TextureRegion[] textureRegions = new TextureRegion[5];

    BallSprite(GLSpriteBatch batch, Ball ball) {
        super(batch);
        this.ball = ball;
    }

    @Override
    public void draw(int subframe) {
        Data d = ball.data[subframe];
        batch.draw(textureRegions[d.fmx], d.x - Const.BALL_R, d.y - d.z - 2 - Const.BALL_R);
    }

    void redrawOverTopGoal(int subframe) {
        Data d = ball.data[subframe];
        if (EMath.isIn(d.x, -POST_X, POST_X)
                && d.y < -GOAL_LINE
                && d.z > (CROSSBAR_H - (Math.abs(d.y) - GOAL_LINE) / 3f)) {
            draw(subframe);
        }
    }

    void redrawOverBottomGoal(int subframe) {
        Data d = ball.data[subframe];
        if (EMath.isIn(d.x, -POST_X - BALL_R, POST_X + BALL_R)
                && (d.y >= GOAL_LINE + 21 || (d.y > GOAL_LINE && d.z > (CROSSBAR_H - (Math.abs(d.y) - GOAL_LINE) / 3f)))) {
            draw(subframe);
        }
    }

    public int getY(int subframe) {
        return ball.data[subframe].y;
    }

    void drawShadow(int subframe, SceneSettings.Time time, boolean redrawing) {
        Data d = ball.data[subframe];
        for (int i = 0; i < (time == MatchSettings.Time.NIGHT ? 4 : 1); i++) {
            float oX = (i == 0 || i == 3) ? -1 : -5;
            float mX = (i == 0 || i == 3) ? 0.65f : -0.65f;
            float oY = -3;
            float mY = (i == 0 || i == 1) ? 0.46f : -0.46f;
            float x = d.x + oX + mX * d.z;
            float y = d.y + oY + mY * d.z;

            boolean overTheGoal = false;
            if (d.z > CROSSBAR_H) {
                float x1 = d.x + oX + mX * (d.z - CROSSBAR_H);
                float y1 = d.y + oY + mY * (d.z - CROSSBAR_H);
                if (isInsideGoal(x1 + BALL_R, y1 + BALL_R)) {
                    overTheGoal = true;
                    x = x1;
                    y = y1 - CROSSBAR_H;
                }
            }

            // while drawing all shadows (redrawing == false) -> draw only on-the-ground shadows
            // while redrawing ball shadows (redrawing == true) -> draw only if over the goal
            if (!overTheGoal ^ redrawing) {
                batch.draw(textureRegions[4], x, y);
            }
        }
    }

    void redrawShadowsOverGoals(int subframe, SceneSettings sceneSettings) {
        batch.setColor(0xFFFFFF, sceneSettings.shadowAlpha);
        drawShadow(subframe, sceneSettings.time, true);
        batch.setColor(0xFFFFFF, 1f);
    }

    void loadTexture(AssetManager assetManager, SceneSettings sceneSettings) {
        List<RgbPair> rgbPairs = new ArrayList<>();
        switch (sceneSettings.time) {
            case DAY:
                rgbPairs.add(new RgbPair(0x005200, sceneSettings.grass.lightShadow));
                rgbPairs.add(new RgbPair(0x001800, sceneSettings.grass.darkShadow));
                break;

            case NIGHT:
                rgbPairs.add(new RgbPair(0x005200, sceneSettings.grass.lightShadow));
                rgbPairs.add(new RgbPair(0x001800, sceneSettings.grass.lightShadow));
                break;
        }

        TextureLoader.TextureParameter parameter = new TextureLoader.TextureParameter();
        parameter.textureData = Assets.loadTextureData("images/" + (sceneSettings.useOrangeBall() ? "ballsnow.png" : "ball.png"), rgbPairs);
        assetManager.load("ball", Texture.class, parameter);
    }

    void getTextureRegions(AssetManager assetManager) {
        Texture texture = assetManager.get("ball");
        for (int r = 0; r < 5; r++) {
            textureRegions[r] = new TextureRegion(texture, r * 8, 0, 8, 8);
            textureRegions[r].flip(false, true);
        }
    }

    void unloadTexture(AssetManager assetManager) {
        assetManager.unload("ball");
    }
}
