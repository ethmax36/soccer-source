package com.ysoccer.android.match;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Sound;

import java.util.HashMap;
import java.util.Map;

public class Sounds {

    private final Scene scene;
    private String[] names;

    Map<String, Sound> sounds = new HashMap<>();
    Map<String, Long> soundIds = new HashMap<>();

    Sounds(Scene scene) {
        this.scene = scene;
    }

    void setNames(String[] names) {
        this.names = names;
    }

    void play(String name, float volume) {
        Sound s = sounds.get(name);
        long id = s.play(volume * scene.game.settings.soundVolume / 100f);
        soundIds.put(name, id);
    }

    void stop(String name) {
        long soundId = soundIds.get(name);
        sounds.get(name).stop(soundId);
    }

    void setLooping(String name, boolean looping) {
        long soundId = soundIds.get(name);
        sounds.get(name).setLooping(soundId, looping);
    }

    void loadAssets(AssetManager assetManager) {
        for (String name : names) {
            assetManager.load("sounds/" + name + ".ogg", Sound.class);
        }
    }

    void getAssets(AssetManager assetManager) {
        for (String name : names) {
            Sound s = assetManager.get("sounds/" + name + ".ogg");
            sounds.put(name, s);
        }
    }

    void unloadAssets(AssetManager assetManager) {
        for (String name : names) {
            assetManager.unload("sounds/" + name + ".ogg");
        }
    }
}
