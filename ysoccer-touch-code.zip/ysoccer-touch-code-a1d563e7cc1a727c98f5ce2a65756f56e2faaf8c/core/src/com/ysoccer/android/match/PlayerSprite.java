package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLSpriteBatch;

public class PlayerSprite extends Sprite {

    Player player;
    PlayerSprites sprites;

    public PlayerSprite(GLSpriteBatch batch, Player player, PlayerSprites sprites) {
        super(batch);
        this.player = player;
        this.sprites = sprites;
    }

    @Override
    public void draw(int subframe) {
        Data d = player.data[subframe];
        if (!d.isVisible) {
            return;
        }

        if (player.role == Player.Role.GOALKEEPER) {
            Integer[] origin = sprites.keeperOrigins[d.fmy][d.fmx];
            batch.draw(
                    sprites.keeper[player.team.index][player.skinColor.ordinal()][d.fmx][d.fmy],
                    d.x - origin[0],
                    d.y - origin[1] - d.z
            );

            Integer[] hairMap = sprites.keeperHairMap[d.fmy][d.fmx];
            if (hairMap[2] != 0 || hairMap[3] != 0) {
                batch.draw(
                        sprites.hairs.get(player.hairColor.ordinal()).get(player.hairStyle)[hairMap[0]][hairMap[1]],
                        d.x - origin[0] + hairMap[2],
                        d.y - origin[1] - d.z + hairMap[3]
                );
            }
        } else {
            Integer[] origin = sprites.playerOrigins[d.fmy][d.fmx];
            batch.draw(
                    sprites.player[player.team.index][player.skinColor.ordinal()][d.fmx][d.fmy],
                    d.x - origin[0],
                    d.y - origin[1] - d.z
            );

            Integer[] hairMap = sprites.playerHairMap[d.fmy][d.fmx];
            if (hairMap[2] != 0 || hairMap[3] != 0) {
                batch.draw(
                        sprites.hairs.get(player.hairColor.ordinal()).get(player.hairStyle)[hairMap[0]][hairMap[1]],
                        d.x - origin[0] - 9 + hairMap[2],
                        d.y - origin[1] - d.z - 9 + hairMap[3]
                );
            }
        }
    }

    void drawShadow(int subframe, SceneSettings.Time time) {
        Data d = player.data[subframe];
        if (!d.isVisible) return;

        if (player.role == Player.Role.GOALKEEPER) {
            Integer[] origin = sprites.keeperOrigins[d.fmy][d.fmx];
            batch.draw(sprites.keeperShadow[d.fmx][d.fmy][0], d.x - origin[0] + 0.65f * d.z, d.y - origin[1] + 0.46f * d.z);
            if (time == MatchSettings.Time.NIGHT) {
                // TODO activate after getting keeper shadows
                // batch.draw(Assets.keeperShadow[d.fmx][d.fmy][1], d.x - 24 - 0.65f * d.z, d.y - 34 + 0.46f * d.z);
                // batch.draw(Assets.keeperShadow[d.fmx][d.fmy][2], d.x - 24 - 0.65f * d.z, d.y - 34 - 0.46f * d.z);
                // batch.draw(Assets.keeperShadow[d.fmx][d.fmy][3], d.x - 24 + 0.65f * d.z, d.y - 34 - 0.46f * d.z);
            }
        } else {
            Integer[] origin = sprites.playerOrigins[d.fmy][d.fmx];
            for (int i = 0; i < (time == MatchSettings.Time.NIGHT ? 4 : 1); i++) {
                float mX = (i == 0 || i == 3) ? 0.65f : -0.65f;
                float mY = (i == 0 || i == 1) ? 0.46f : -0.46f;
                batch.draw(sprites.playerShadow[d.fmx][d.fmy][i], d.x - origin[0] + mX * d.z, d.y - origin[1] + 5 + mY * d.z);
            }
        }
    }

    @Override
    public int getY(int subframe) {
        return player.data[subframe].y;
    }
}
