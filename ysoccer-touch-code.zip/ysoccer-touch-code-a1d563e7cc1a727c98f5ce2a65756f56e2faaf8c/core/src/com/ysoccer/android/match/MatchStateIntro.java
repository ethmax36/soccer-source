package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.FOLLOW_BALL;
import static com.ysoccer.android.match.ActionCamera.Mode.STILL;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;
import static com.ysoccer.android.match.MatchFsm.STATE_STARTING_POSITIONS;
import static com.ysoccer.android.match.SceneFsm.ActionType.NEW_FOREGROUND;

class MatchStateIntro extends MatchState {

    private final int enterDelay = GLGame.VIRTUAL_REFRESH_RATE / 16;
    private boolean stillCamera;
    private boolean soundsStarted;

    MatchStateIntro(MatchFsm fsm) {
        super(fsm);
    }

    @Override
    void entryActions() {
        super.entryActions();

        stillCamera = true;
        match.clock = 0;
        getFsm().matchCompleted = false;
        match.setIntroPositions();
        match.resetData();
    }

    @Override
    void onResume() {
        super.onResume();

        setCameraMode();
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        match.enterPlayers(timer - 1, enterDelay);

        if (!soundsStarted && timer > GLGame.VIRTUAL_REFRESH_RATE / 2) {
            sceneRenderer.sounds.play("intro", 1f);
            sceneRenderer.sounds.play("crowd", 1f);
            sceneRenderer.sounds.setLooping("crowd", true);
            soundsStarted = true;
        }

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            match.updatePlayers(false);
            match.playersPhoto();

            match.nextSubframe();

            sceneRenderer.save();

            if (stillCamera && timer > GLGame.VIRTUAL_REFRESH_RATE) {
                stillCamera = false;
                setCameraMode();
            }
            sceneRenderer.actionCamera.update();

            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    private void setCameraMode() {
        sceneRenderer.actionCamera.setMode(stillCamera ? STILL : FOLLOW_BALL);
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if (match.enterPlayersFinished(timer, enterDelay)) {
            if ((match.team[HOME].fire1Down() != null)
                    || (match.team[AWAY].fire1Down() != null)
                    || (timer >= 5 * GLGame.VIRTUAL_REFRESH_RATE)) {
                return newAction(NEW_FOREGROUND, STATE_STARTING_POSITIONS);
            }
        }

        return checkCommonConditions();
    }
}
