package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLSpriteBatch;

import static com.ysoccer.android.match.Const.GOAL_DEPTH;
import static com.ysoccer.android.match.Const.GOAL_LINE;

class GoalTopB extends Sprite {

    GoalTopB(GLSpriteBatch batch) {
        super(batch);
        x = -69;
        y = -673;
    }

    @Override
    public int getY(int subframe) {
        return -GOAL_LINE - GOAL_DEPTH;
    }
}
