package com.ysoccer.android.match;

import static com.ysoccer.android.match.PlayerFsm.Id.STATE_IDLE;

class PlayerStateIdle extends PlayerState {

    PlayerStateIdle(PlayerFsm fsm) {
        super(STATE_IDLE, fsm);
    }

    @Override
    void entryActions() {
        super.entryActions();
        player.v = 0;
        player.animationStandRun();
    }
}
