package com.ysoccer.android.match;

import com.ysoccer.android.competitions.Competition;
import com.ysoccer.android.framework.Settings;

public class MatchSettings extends SceneSettings {

    int matchLength;

    public int benchSize;
    boolean autoReplays;
    public boolean radar;
    boolean crowdChants;

    public MatchSettings(Competition competition, Settings gameSettings) {
        super(gameSettings);

        if (competition.type == Competition.Type.FRIENDLY || competition.category == Competition.Category.DIY_COMPETITION) {
            matchLength = gameSettings.matchLength;
        } else {
            matchLength = Settings.matchLengths[0];
        }

        this.time = competition.getTime();
        this.pitchType = competition.getPitchType();
        benchSize = competition.benchSize;
        autoReplays = gameSettings.autoReplays;
        radar = gameSettings.radar;
        crowdChants = true;
    }
}
