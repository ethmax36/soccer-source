package com.ysoccer.android.match;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.ysoccer.android.framework.Font;
import com.ysoccer.android.framework.GLGraphics;

import static com.badlogic.gdx.Gdx.gl;
import static com.ysoccer.android.framework.Font.Align.LEFT;
import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_BENCH_SITTING;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_OUTSIDE;

public class MatchRenderer extends SceneRenderer {

    private Match match;
    private MatchState matchState;

    Pixmap keeperCollisionDetection;

    final Stadium stadium;
    final BallSprite ballSprite;
    final PlayerSprites playerSprites;
    final CoachSprite[] coachSprites = new CoachSprite[2];
    final CornerFlagSprites cornerFlagSprites;

    public final TextureRegion[][] shirtNumbers = new TextureRegion[10][2];
    public final TextureRegion[] timeDigits = new TextureRegion[11];
    public final TextureRegion[][] windVane = new TextureRegion[8][2];
    public final TextureRegion[] scoreDigits = new TextureRegion[11];
    public final TextureRegion[] tinyNumbers = new TextureRegion[10];
    public final TextureRegion[] countryFlags = new TextureRegion[2];

    private final String[] soundNames = {"bounce", "celebration", "chant", "crowd", "deflect", "end", "goal", "hold", "intro", "kick", "post", "whistle"};

    MatchRenderer(GLGraphics glGraphics, Match match) {
        super(glGraphics, match);
        this.match = match;
        this.camera = glGraphics.camera;
        this.ball = match.ball;
        actionCamera = new ActionCamera(ball);

        resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), scene.settings.zoom);

        actionCamera.x = 0.5f * (Const.PITCH_W - screenWidth / (zoom / 100.0f));
        actionCamera.y = Const.CENTER_Y - screenHeight / (2 * zoom / 100.0f);
        for (int i = 0; i < Const.REPLAY_SUBFRAMES; i++) {
            vCameraX[i] = Math.round(actionCamera.x);
            vCameraY[i] = Math.round(actionCamera.y);
        }

        stadium = new Stadium(batch, match);
        stadium.addSprites(allSprites);

        ballSprite = new BallSprite(batch, ball);
        allSprites.add(ballSprite);

        for (int t = HOME; t <= AWAY; t++) {
            coachSprites[t] = new CoachSprite(batch, match.team[t].coach);
            allSprites.add(coachSprites[t]);
        }

        playerSprites = new PlayerSprites(match, assetManager, batch);
        allSprites.addAll(playerSprites);

        cornerFlagSprites = new CornerFlagSprites(match, batch);
        allSprites.addAll(cornerFlagSprites);

        sounds.setNames(soundNames);
    }

    public void render() {
        matchState = match.getFsm().getState();

        gl.glEnable(GL20.GL_BLEND);
        gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.setToOrtho(true, Gdx.graphics.getWidth() * 100f / zoom, Gdx.graphics.getHeight() * 100f / zoom);
        camera.translate(-Const.CENTER_X + vCameraX[scene.subframe], -Const.CENTER_Y + vCameraY[scene.subframe], 0);
        camera.update();
        batch.setProjectionMatrix(camera.combined);

        batch.begin();
        stadium.draw();
        renderSprites();

        ballSprite.redrawShadowsOverGoals(scene.subframe, scene.settings);
        ballSprite.redrawOverTopGoal(scene.subframe);

        stadium.redrawBottomGoal();
        ballSprite.redrawShadowsOverGoals(scene.subframe, scene.settings);
        ballSprite.redrawOverBottomGoal(scene.subframe);

        weatherEffects.draw(scene.subframe);

        if (matchState.displayControlledPlayer) {
            drawControlledPlayersNumbers();
        }

        batch.end();

        renderGui();

        if (match.hasTouchControls()) {
            match.game.touchInput.render(batch);
        }
    }

    private void renderGui() {
        camera.setToOrtho(true, guiWidth, guiHeight);
        camera.update();
        batch.setProjectionMatrix(camera.combined);
        shapeRenderer.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.setColor(0xFFFFFF, guiAlpha);

        // clock
        if (matchState.displayTime) {
            drawTime();
        }

        // radar
        if (matchState.displayRadar && match.getSettings().radar) {
            drawRadar();
        }

        // wind vane
        if (matchState.displayWindVane && (scene.settings.wind.speed > 0)) {
            batch.draw(windVane[scene.settings.wind.direction][scene.settings.wind.speed - 1], guiWidth - 50, 20);
        }

        // score
        if (matchState.displayScore) {
            drawScore();
        }

        // penalties score
        if (matchState.displayPenaltiesScore) {
            drawPenaltiesScore();
        }

        // statistics
        if (matchState.displayStatistics) {
            drawStatistics();
        }

        // additional state-specific render
        if (matchState != null) {
            matchState.render();
        }
        batch.end();
    }

    @Override
    protected void drawShadows() {
        batch.setColor(0xFFFFFF, scene.settings.shadowAlpha);

        ballSprite.drawShadow(scene.subframe, scene.settings.time, false);
        cornerFlagSprites.drawShadows(scene.subframe);
        playerSprites.drawShadows(scene.subframe, scene.settings.time);

        batch.setColor(0xFFFFFF, 1f);
    }

    private void drawControlledPlayersNumbers() {
        for (int t = Match.HOME; t <= Match.AWAY; t++) {
            if (match.team[t] != null) {
                for (Player player : match.team[t].lineup) {
                    Data d = player.data[scene.subframe];
                    if (d.isVisible) {
                        if (d.isHumanControlled) {
                            drawShirtNumber(player);
                        }
                    }
                }
            }
        }
    }

    void drawShirtNumber(Player player) {
        Data d = player.data[scene.subframe];

        int f0 = player.number % 10;
        int f1 = (player.number - f0) / 10 % 10;

        int dx = Math.round(d.x) + 1;
        int dy = Math.round(d.y) - 40 - Math.round(d.z);

        int w0 = 6 - ((f0 == 1) ? 2 : 1);
        int w1 = 6 - ((f1 == 1) ? 2 : 1);

        int fy = scene.settings.pitchType == Pitch.Type.WHITE ? 1 : 0;
        if (f1 > 0) {
            dx = dx - (w0 + 2 + w1) / 2;
            batch.draw(shirtNumbers[f1][fy], dx, dy, 6, 10);
            dx = dx + w1 + 2;
            batch.draw(shirtNumbers[f0][fy], dx, dy, 6, 10);
        } else {
            batch.draw(shirtNumbers[f0][fy], dx - w0 / 2f, dy, 6, 10);
        }
    }

    private void drawTime() {

        int minute = match.getMinute();

        // "minutes"
        match.game.font10.draw(batch, match.game.gettext("MINS"), 49, 27, LEFT);

        // units
        int digit = minute % 10;
        batch.draw(timeDigits[digit], 34, 22);

        // tens
        minute = (minute - digit) / 10;
        digit = minute % 10;
        if (minute > 0) {
            batch.draw(timeDigits[digit], 22, 22);
        }

        // hundreds
        minute = (minute - digit) / 10;
        digit = minute % 10;
        if (digit > 0) {
            batch.draw(timeDigits[digit], 10, 22);
        }
    }

    private void drawRadar() {

        final int RX = 10;
        final int RY = 60;
        final int RW = 132;
        final int RH = 166;

        batch.end();
        gl.glEnable(GL20.GL_BLEND);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        fadeRect(RX, RY, RX + RW, RY + RH, 0.6f, scene.settings.grass.darkShadow);

        shapeRenderer.setColor(0x000000, 1f);
        shapeRenderer.rect(RX, RY, 1, RH);
        shapeRenderer.rect(RX + 1, RY, RW - 2, 1);
        shapeRenderer.rect(RX + 1, RY + RH / 2f, RW - 2, 1);
        shapeRenderer.rect(RX + 1, RY + RH - 1, RW - 2, 1);
        shapeRenderer.rect(RX + RW - 1, RY, 1, RH);

        // prepare y-sorted list
        spriteComparator.setSubframe(scene.subframe);

        // shirt colors
        int[] shirt1 = new int[2];
        int[] shirt2 = new int[2];
        for (int t = Match.HOME; t <= Match.AWAY; t++) {
            Kit kit = match.team[t].getKit();
            shirt1[t] = kit.shirt1;
            shirt2[t] = kit.shirt2;
        }

        // placeholders
        for (Sprite sprite : allSprites) {
            if (sprite.getClass() == PlayerSprite.class) {
                Player player = ((PlayerSprite) sprite).player;
                if (player.checkState(STATE_BENCH_SITTING) || player.checkState(STATE_OUTSIDE)) {
                    continue;
                }
                Data d = player.data[scene.subframe];
                if (d.isVisible) {
                    int dx = RX + RW / 2 + d.x / 8;
                    int dy = RY + RH / 2 + d.y / 8;

                    shapeRenderer.setColor(0x242424, 1f);
                    shapeRenderer.rect(dx - 3, dy - 3, 6, 1);
                    shapeRenderer.rect(dx - 4, dy - 2, 1, 4);
                    shapeRenderer.rect(dx - 3, dy + 2, 6, 1);
                    shapeRenderer.rect(dx + 3, dy - 2, 1, 4);

                    shapeRenderer.setColor(shirt1[player.team.index], 1f);
                    shapeRenderer.rect(dx - 3, dy - 2, 3, 4);

                    shapeRenderer.setColor(shirt2[player.team.index], 1f);
                    shapeRenderer.rect(dx, dy - 2, 3, 4);
                }
            }
        }

        shapeRenderer.end();
        batch.begin();
        batch.setColor(0xFFFFFF, guiAlpha);

        // controlled players numbers
        if (matchState.displayControlledPlayer) {
            for (Sprite sprite : allSprites) {
                if (sprite.getClass() == PlayerSprite.class) {
                    Player player = ((PlayerSprite) sprite).player;
                    if (player.checkState(STATE_BENCH_SITTING) || player.checkState(STATE_OUTSIDE)) {
                        continue;
                    }
                    Data d = player.data[scene.subframe];
                    if ((d.isVisible) && (player.inputDevice != player.ai)) {
                        int dx = RX + RW / 2 + d.x / 8 + 1;
                        int dy = RY + RH / 2 + d.y / 8 - 10;

                        int f0 = player.number % 10;
                        int f1 = (player.number - f0) / 10 % 10;

                        int w0, w1;
                        if (f1 > 0) {
                            w0 = 4 - (f0 == 1 ? 2 : 0);
                            w1 = 4 - (f1 == 1 ? 2 : 0);
                            dx = dx - (w0 + w1) / 2;
                            batch.draw(tinyNumbers[f1], dx, dy);
                            dx = dx + w1;
                            batch.draw(tinyNumbers[f0], dx, dy);
                        } else {
                            w0 = 4 - (f0 == 1 ? 2 : 0);
                            dx = dx - w0 / 2;
                            batch.draw(tinyNumbers[f0], dx, dy);
                        }
                    }
                }
            }
        }
    }

    private void drawScore() {

        int m = match.hasTouchControls() ? 160 : 10;

        // max rows
        int rows = Math.max(match.scorers.rows[HOME].size(), match.scorers.rows[AWAY].size());

        // size of country flags
        int h0 = countryFlags[HOME].getRegionHeight();

        int w1 = countryFlags[AWAY].getRegionWidth();
        int h1 = countryFlags[AWAY].getRegionHeight();

        int hMax = Math.max(h0, h1);
        int y0 = guiHeight - 16 - Math.max(hMax, 14 * rows);

        // country flags
        int x = m + 2;
        int y = y0 + 8 + (hMax - h0) / 2;
        batch.setColor(0x242424, guiAlpha);
        batch.draw(countryFlags[HOME], x + 2, y + 2);
        batch.setColor(0xFFFFFF, guiAlpha);
        batch.draw(countryFlags[HOME], x, y);

        x = guiWidth - m - w1 - 2;
        y = y0 + 8 + (hMax - h1) / 2;
        batch.setColor(0x242424, guiAlpha);
        batch.draw(countryFlags[AWAY], x + 2, y + 2);
        batch.setColor(0xFFFFFF, guiAlpha);
        batch.draw(countryFlags[AWAY], x, y);

        // teams
        match.game.font14.draw(batch, match.game.gettext("NAMES." + match.team[HOME].name), m + 2, y0 - 22, LEFT);
        match.game.font14.draw(batch, match.game.gettext("NAMES." + match.team[AWAY].name), guiWidth - m, y0 - 22, Font.Align.RIGHT);

        // bars
        batch.end();
        gl.glEnable(GL20.GL_BLEND);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(0xFFFFFF, guiAlpha);

        shapeRenderer.rect(m, y0, guiWidth / 2f - 12 - m, 2);
        shapeRenderer.rect(guiWidth / 2f + 12, y0, guiWidth / 2f - 12 - m, 2);

        shapeRenderer.setColor(0x242424, guiAlpha);
        shapeRenderer.rect(m + 2, y0 + 2, guiWidth / 2f - 12 - m, 2);
        shapeRenderer.rect(guiWidth / 2f + 14, y0 + 2, guiWidth / 2f - 12 - m, 2);

        shapeRenderer.end();
        batch.begin();
        batch.setColor(0xFFFFFF, guiAlpha);

        // home score
        int f0 = match.stats[Match.HOME].goals % 10;
        int f1 = ((match.stats[Match.HOME].goals - f0) / 10) % 10;

        if (f1 > 0) {
            batch.draw(scoreDigits[f1], guiWidth / 2f - 15 - 48, y0 - 40);
        }
        batch.draw(scoreDigits[f0], guiWidth / 2f - 15 - 24, y0 - 40);

        // "-"
        batch.draw(scoreDigits[10], guiWidth / 2f - 9, y0 - 40);

        // away score
        f0 = match.stats[Match.AWAY].goals % 10;
        f1 = (match.stats[Match.AWAY].goals - f0) / 10 % 10;

        if (f1 > 0) {
            batch.draw(scoreDigits[f1], guiWidth / 2f + 17, y0 - 40);
            batch.draw(scoreDigits[f0], guiWidth / 2f + 17 + 24, y0 - 40);
        } else {
            batch.draw(scoreDigits[f0], guiWidth / 2f + 17, y0 - 40);
        }
    }

    private void drawPenaltiesScore() {

        int m = match.hasTouchControls() ? 160 : 10;

        // max rows of rows
        int rows = Math.max(match.penalties[HOME].size(), match.penalties[AWAY].size());

        // size of country flags
        int h0 = countryFlags[HOME].getRegionHeight();

        int w1 = countryFlags[AWAY].getRegionWidth();
        int h1 = countryFlags[AWAY].getRegionHeight();

        int hMax = Math.max(h0, h1);
        int y0 = guiHeight - 16 - Math.max(hMax, 14 * rows);

        // country flags
        int x = m + 2;
        int y = y0 + 8 + (hMax - h0) / 2;
        batch.setColor(0x242424, guiAlpha);
        batch.draw(countryFlags[HOME], x + 2, y + 2);
        batch.setColor(0xFFFFFF, guiAlpha);
        batch.draw(countryFlags[HOME], x, y);

        x = guiWidth - m - w1 - 2;
        y = y0 + 8 + (hMax - h1) / 2;
        batch.setColor(0x242424, guiAlpha);
        batch.draw(countryFlags[AWAY], x + 2, y + 2);
        batch.setColor(0xFFFFFF, guiAlpha);
        batch.draw(countryFlags[AWAY], x, y);

        // teams
        match.game.font14.draw(batch, match.game.gettext("NAMES." + match.team[HOME].name), +m + 2, y0 - 22, LEFT);
        match.game.font14.draw(batch, match.game.gettext("NAMES." + match.team[AWAY].name), guiWidth - m, y0 - 22, Font.Align.RIGHT);

        // bars
        batch.end();
        gl.glEnable(GL20.GL_BLEND);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(0xFFFFFF, guiAlpha);

        shapeRenderer.rect(m, y0, guiWidth / 2f - 12 - m, 2);
        shapeRenderer.rect(guiWidth / 2f + 12, y0, guiWidth / 2f - 12 - m, 2);

        shapeRenderer.setColor(0x242424, guiAlpha);
        shapeRenderer.rect(m + 2, y0 + 2, guiWidth / 2f - 12 - m, 2);
        shapeRenderer.rect(guiWidth / 2f + 14, y0 + 2, guiWidth / 2f - 12 - m, 2);

        shapeRenderer.end();
        batch.begin();
        batch.setColor(0xFFFFFF, guiAlpha);

        // home score
        int homeScore = match.penaltyGoals(HOME);
        int f0 = homeScore % 10;
        int f1 = ((homeScore - f0) / 10) % 10;

        if (f1 > 0) {
            batch.draw(scoreDigits[f1], guiWidth / 2f - 15 - 48, y0 - 40);
        }
        batch.draw(scoreDigits[f0], guiWidth / 2f - 15 - 24, y0 - 40);

        // "-"
        batch.draw(scoreDigits[10], guiWidth / 2f - 9, y0 - 40);

        // away score
        int awayScore = match.penaltyGoals(AWAY);
        f0 = awayScore % 10;
        f1 = (awayScore - f0) / 10 % 10;

        if (f1 > 0) {
            batch.draw(scoreDigits[f1], guiWidth / 2f + 17, y0 - 40);
            batch.draw(scoreDigits[f0], guiWidth / 2f + 17 + 24, y0 - 40);
        } else {
            batch.draw(scoreDigits[f0], guiWidth / 2f + 17, y0 - 40);
        }

        // scorers
        for (int t = HOME; t <= AWAY; t++) {
            int y1 = y0 + 4;
            for (Match.Penalty penalty : match.penalties[t]) {
                int x1 = guiWidth / 2 + (t == HOME ? -12 : +14);
                String text = "";
                switch (penalty.state) {
                    case TO_KICK:
                        break;
                    case SCORED:
                        text += (char) 25;
                        break;
                    case MISSED:
                        text += (char) 26;
                        break;
                }

                Font.Align align = t == HOME ? Font.Align.RIGHT : LEFT;
                match.game.font10.draw(batch, text, x1, y1, align);
                y1 += 14;
            }
        }
    }

    private void drawStatistics() {

        int l = 13 + (guiWidth - 460) / 5 + 2;
        int r = guiWidth - l + 2;
        int w = r - l;
        int t = guiHeight / 2 - 210 + 2;
        int b = guiHeight / 2 + 210 + 2;
        int h = b - t;
        int hw = guiWidth / 2;
        int rows = 8;
        int rowHeight = h / rows;

        // fading
        batch.end();
        gl.glEnable(GL20.GL_BLEND);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        // top strip
        fadeRect(l + 2, t + 2, r - 2, t + rowHeight + 1, 0.35f, 0x000000);

        // middle strips
        int i = t + rowHeight + 2;
        for (int j = 1; j < (rows - 1); j++) {
            fadeRect(l + 2, i + 1, r - 2, i + rowHeight - 1, 0.35f, 0x000000);
            i = i + rowHeight;
        }

        // bottom strip
        fadeRect(l + 2, i + 1, r - 2, b - 2, 0.35f, 0x000000);

        // frame shadow
        shapeRenderer.setColor(0x242424, guiAlpha);
        drawFrame(l, t, r - l, b - t);

        l = l - 2;
        r = r - 2;
        t = t - 2;
        b = b - 2;

        // frame
        shapeRenderer.setColor(0xFFFFFF, guiAlpha);
        drawFrame(l, t, r - l, b - t);

        shapeRenderer.end();
        batch.begin();
        batch.setColor(0xFFFFFF, guiAlpha);

        MatchStats homeStats = match.stats[Match.HOME];
        MatchStats awayStats = match.stats[Match.AWAY];

        int possHome = Math.round(100 * (1f + match.stats[Match.HOME].ballPossession) / (2f + homeStats.ballPossession + awayStats.ballPossession));
        int possAway = 100 - possHome;

        // text
        Font font14 = match.game.font14;

        int lc = l + w / 5;
        int rc = r - w / 5;
        i = t + rowHeight / 2 - 8;
        font14.draw(batch, match.game.gettext("MATCH STATISTICS"), hw, i, Font.Align.CENTER);

        i = i + rowHeight;
        font14.draw(batch, match.game.gettext("NAMES." + match.team[Match.HOME].name), lc, i, Font.Align.CENTER);
        font14.draw(batch, match.game.gettext("NAMES." + match.team[Match.AWAY].name), rc, i, Font.Align.CENTER);

        i = i + rowHeight;
        int homeGoals = (match.penalties[HOME].size() > 0) ? match.penaltiesScore(HOME) : homeStats.goals;
        int awayGoals = (match.penalties[AWAY].size() > 0) ? match.penaltiesScore(AWAY) : awayStats.goals;
        font14.draw(batch, homeGoals, lc, i, Font.Align.CENTER);
        font14.draw(batch, match.game.gettext("MATCH STATISTICS.GOALS"), hw, i, Font.Align.CENTER);
        font14.draw(batch, awayGoals, rc, i, Font.Align.CENTER);

        i = i + rowHeight;
        font14.draw(batch, possHome, lc, i, Font.Align.CENTER);
        font14.draw(batch, match.game.gettext("MATCH STATISTICS.POSSESSION"), hw, i, Font.Align.CENTER);
        font14.draw(batch, possAway, rc, i, Font.Align.CENTER);

        i = i + rowHeight;
        font14.draw(batch, homeStats.overallShots, lc, i, Font.Align.CENTER);
        font14.draw(batch, match.game.gettext("MATCH STATISTICS.GOAL ATTEMPTS"), hw, i, Font.Align.CENTER);
        font14.draw(batch, awayStats.overallShots, rc, i, Font.Align.CENTER);

        i = i + rowHeight;
        font14.draw(batch, homeStats.centeredShots, lc, i, Font.Align.CENTER);
        font14.draw(batch, match.game.gettext("MATCH STATISTICS.ON TARGET"), hw, i, Font.Align.CENTER);
        font14.draw(batch, awayStats.centeredShots, rc, i, Font.Align.CENTER);

        i = i + rowHeight;
        font14.draw(batch, homeStats.cornersWon, lc, i, Font.Align.CENTER);
        font14.draw(batch, match.game.gettext("MATCH STATISTICS.CORNERS WON"), hw, i, Font.Align.CENTER);
        font14.draw(batch, awayStats.cornersWon, rc, i, Font.Align.CENTER);

        i = i + rowHeight;
        font14.draw(batch, homeStats.foulsConceded, lc, i, Font.Align.CENTER);
        font14.draw(batch, match.game.gettext("MATCH STATISTICS.FOULS CONCEDED"), hw, i, Font.Align.CENTER);
        font14.draw(batch, awayStats.foulsConceded, rc, i, Font.Align.CENTER);

        batch.setColor(0xFFFFFF, 1f);
    }

    @Override
    public void loadAssets() {
        super.loadAssets();
        stadium.loadTextures(assetManager, scene.settings);
        cornerFlagSprites.loadTexture(assetManager, scene.settings.time, scene.settings.grass);
        ballSprite.loadTexture(assetManager, scene.settings);
        playerSprites.loadAssets();
        assetManager.load("images/player/keeper_cd.png", Pixmap.class);
        assetManager.load("images/match.atlas", TextureAtlas.class);
        loadCountryFlags();
        coachSprites[HOME].loadTexture(assetManager);
        coachSprites[AWAY].loadTexture(assetManager);
    }

    @Override
    public void getAssets() {
        super.getAssets();
        stadium.getTextureRegions(assetManager);
        cornerFlagSprites.getTextureRegions(assetManager);
        ballSprite.getTextureRegions(assetManager);
        playerSprites.getAssets();
        keeperCollisionDetection = assetManager.get("images/player/keeper_cd.png");

        // atlas
        TextureAtlas atlas = assetManager.get("images/match.atlas");
        TextureAtlas.AtlasRegion atlasRegion;

        atlasRegion = atlas.findRegion("shirt_numbers");
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 2; j++) {
                shirtNumbers[i][j] = new TextureRegion(atlasRegion, 6 * i, 16 * j, 6, 10);
                shirtNumbers[i][j].flip(false, true);
            }
        }

        atlasRegion = atlas.findRegion("time_digits");
        for (int i = 0; i < 11; i++) {
            timeDigits[i] = new TextureRegion(atlasRegion, 12 * i, 0, i < 10 ? 12 : 48, 20);
            timeDigits[i].flip(false, true);
        }

        atlasRegion = atlas.findRegion("wind_vane");
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 2; j++) {
                windVane[i][j] = new TextureRegion(atlasRegion, 30 * i, 30 * j, 30, 30);
                windVane[i][j].flip(false, true);
            }
        }

        atlasRegion = atlas.findRegion("score_digits");
        for (int i = 0; i < 11; i++) {
            scoreDigits[i] = new TextureRegion(atlasRegion, 24 * i, 0, 24, 38);
            scoreDigits[i].flip(false, true);
        }

        atlasRegion = atlas.findRegion("tiny_numbers");
        for (int i = 0; i < 10; i++) {
            tinyNumbers[i] = new TextureRegion(atlasRegion, 4 * i + (i == 1 ? 2 : 0), 0, (i == 1 ? 2 : 4), 6);
            tinyNumbers[i].flip(false, true);
        }

        getCountryFlags();

        coachSprites[HOME].getTextureRegions(assetManager);
        coachSprites[AWAY].getTextureRegions(assetManager);
    }

    @Override
    public void unloadAssets() {
        super.unloadAssets();
        coachSprites[HOME].unloadTexture(assetManager);
        coachSprites[AWAY].unloadTexture(assetManager);
        unloadCountryFlags();
        assetManager.unload("images/match.atlas");
        assetManager.unload("images/player/keeper_cd.png");
        playerSprites.unloadAssets();
        ballSprite.unloadTexture(assetManager);
        cornerFlagSprites.unloadTexture(assetManager);
        stadium.unloadTextures(assetManager);
    }

    private void loadCountryFlags() {
        for (int t = HOME; t <= AWAY; t++) {
            Team team = match.team[t];
            String flagPath = team.path.replaceFirst("/team.", "/flag.").replaceFirst(".json", ".png");
            assetManager.load(team.getFlagPath(), Texture.class);
        }
    }

    private void getCountryFlags() {
        for (int t = HOME; t <= AWAY; t++) {
            Team team = match.team[t];
            Texture texture = assetManager.get(team.getFlagPath());
            countryFlags[t] = new TextureRegion(texture, 87, 54);
            countryFlags[t].flip(false, true);
        }
    }

    private void unloadCountryFlags() {
        for (int t = HOME; t <= AWAY; t++) {
            Team team = match.team[t];
            assetManager.unload(team.getFlagPath());
        }
    }

    @Override
    void save() {
        ball.save(scene.subframe);
        match.team[HOME].save(scene.subframe);
        match.team[AWAY].save(scene.subframe);
        vCameraX[scene.subframe] = Math.round(actionCamera.x);
        vCameraY[scene.subframe] = Math.round(actionCamera.y);
    }

    @Override
    void quit() {
        super.quit();
        sounds.stop("crowd");
    }
}
