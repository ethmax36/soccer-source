package com.ysoccer.android.match;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.ysoccer.android.framework.GLSpriteBatch;

import java.util.Comparator;

class Sprite {

    final GLSpriteBatch batch;

    TextureRegion textureRegion;
    int x;
    int y;
    int z;

    Sprite(GLSpriteBatch batch) {
        this.batch = batch;
    }

    public void draw(int subframe) {
        batch.draw(textureRegion, x, y - z);
    }

    public int getY(int subframe) {
        return y;
    }

    static class SpriteComparator implements Comparator<Sprite> {

        private int subframe;

        public void setSubframe(int subframe) {
            this.subframe = subframe;
        }

        @Override
        public int compare(Sprite sprite1, Sprite sprite2) {
            return sprite1.getY(subframe) - sprite2.getY(subframe);
        }
    }
}
