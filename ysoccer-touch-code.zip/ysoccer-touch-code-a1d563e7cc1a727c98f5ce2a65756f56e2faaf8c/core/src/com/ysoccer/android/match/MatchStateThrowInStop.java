package com.ysoccer.android.match;

import com.ysoccer.android.framework.GLGame;

import static com.ysoccer.android.match.ActionCamera.Mode.FOLLOW_BALL;
import static com.ysoccer.android.match.ActionCamera.Speed.NORMAL;
import static com.ysoccer.android.match.MatchFsm.STATE_THROW_IN;
import static com.ysoccer.android.match.PlayerFsm.Id.STATE_REACH_TARGET;
import static com.ysoccer.android.match.SceneFsm.ActionType.NEW_FOREGROUND;

class MatchStateThrowInStop extends MatchState {

    private boolean move;

    MatchStateThrowInStop(MatchFsm fsm) {
        super(fsm);

        displayControlledPlayer = true;
        displayBallOwner = true;
        displayTime = true;
        displayWindVane = true;
        displayRadar = true;
    }

    @Override
    void entryActions() {
        super.entryActions();

        sceneRenderer.sounds.play("whistle", 1f);

        getFsm().throwInPosition.set(match.ball.xSide * Const.TOUCH_LINE, match.ball.y);

        match.resetAutomaticInputDevices();
        match.setPlayersState(STATE_REACH_TARGET, null);
    }

    @Override
    void onResume() {
        match.setPointOfInterest(getFsm().throwInPosition);

        sceneRenderer.actionCamera
                .setMode(FOLLOW_BALL)
                .setSpeed(NORMAL)
                .setLimited(true, true);
    }

    @Override
    void doActions(float deltaTime) {
        super.doActions(deltaTime);

        float timeLeft = deltaTime;
        while (timeLeft >= GLGame.SUBFRAME_DURATION) {

            if (match.subframe % GLGame.SUBFRAMES == 0) {
                match.updateAi();
            }

            match.updateBall();
            match.ball.inFieldKeep();

            move = match.updatePlayers(true);
            match.updateTeamTactics();

            match.nextSubframe();

            sceneRenderer.save();

            sceneRenderer.actionCamera.update();

            timeLeft -= GLGame.SUBFRAME_DURATION;
        }
    }

    @Override
    SceneFsm.Action[] checkConditions() {
        if (!move) {
            match.ball.setPosition(getFsm().throwInPosition);
            match.ball.updatePrediction();

            return newAction(NEW_FOREGROUND, STATE_THROW_IN);
        }

        return checkCommonConditions();
    }
}
