package com.ysoccer.android.match;

import java.util.ArrayList;

import static com.ysoccer.android.match.Match.AWAY;
import static com.ysoccer.android.match.Match.HOME;

class Scorers {

    ArrayList<String>[] rows = new ArrayList[2];

    Scorers() {
        this.rows[HOME] = new ArrayList<>();
        this.rows[AWAY] = new ArrayList<>();
    }
}
