package com.ysoccer.android.framework;

import com.badlogic.gdx.utils.GdxRuntimeException;

import java.util.ArrayList;

public class InputDeviceList extends ArrayList<InputDevice> {

    public void setAvailability(boolean n) {
        for (InputDevice inputDevice : this) {
            inputDevice.available = n;
        }
    }

    public InputDevice assignFirstAvailable() {
        for (InputDevice inputDevice : this) {
            if (inputDevice.available) {
                inputDevice.available = false;
                return inputDevice;
            }
        }
        return null;
    }

    public InputDevice assignThisOrFirstAvailable(int index) {
        try {
            InputDevice inputDevice = get(index);
            if (inputDevice.available) {
                inputDevice.available = false;
                return inputDevice;
            } else {
                return assignFirstAvailable();
            }
        } catch (IndexOutOfBoundsException e) {
            return assignFirstAvailable();
        }
    }

    public InputDevice rotateAvailable(InputDevice inputDevice, int n) {
        int index = this.indexOf(inputDevice);
        if (index == -1) {
            throw new GdxRuntimeException("item not found");
        }
        inputDevice.available = true;
        do {
            index = EMath.rotate(index, 0, this.size() - 1, n);
            inputDevice = this.get(index);
        } while (!inputDevice.available);

        inputDevice.available = false;
        return inputDevice;
    }
}
