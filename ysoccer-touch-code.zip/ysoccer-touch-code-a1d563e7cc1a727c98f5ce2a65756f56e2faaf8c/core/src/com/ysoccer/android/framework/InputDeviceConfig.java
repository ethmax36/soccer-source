package com.ysoccer.android.framework;

public abstract class InputDeviceConfig {

    public InputDevice.Type type;

    InputDeviceConfig(InputDevice.Type type) {
        this.type = type;
    }
}
