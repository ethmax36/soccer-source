package com.ysoccer.android.framework;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector3;
import com.ysoccer.android.competitions.Competition;
import com.ysoccer.android.gui.Button;
import com.ysoccer.android.gui.Gui;
import com.ysoccer.android.gui.Widget;

import java.util.ArrayList;
import java.util.List;

public abstract class GLScreen extends InputAdapter implements Screen {

    protected GLGame game;
    private boolean assetsLoaded;
    protected boolean playMenuMusic;

    protected static class Navigation {
        public Competition competition;
    }

    protected static final Navigation navigation = new Navigation();

    // convenience references
    protected AssetManager assetManager;
    protected GLSpriteBatch batch;
    protected GLShapeRenderer shapeRenderer;
    protected OrthographicCamera camera;
    protected Gui gui;

    protected String background;
    private Texture backgroundTexture;
    protected List<Widget> widgets;
    protected Widget selectedWidget;
    protected Widget.Event widgetEvent;
    private final Vector3 vector3;

    protected boolean paused;
    protected boolean catchBackKey;

    public GLScreen(GLGame game) {
        this.game = game;
        this.assetManager = game.getAssetManager();
        this.batch = game.getBatch();
        this.shapeRenderer = game.getShapeRenderer();
        this.camera = game.getCamera();
        this.gui = game.getGui();
        widgets = new ArrayList<>();
        paused = false;
        catchBackKey = true;
        vector3 = new Vector3();
        playMenuMusic = true;
    }

    protected class TitleBar extends Button {

        public TitleBar(String text, int color) {
            setGeometry((gui.WIDTH - 800) / 2, 20, 800, 40);
            setColor(color);
            setText(text, Font.Align.CENTER, game.font14);
            setActive(false);
        }
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        vector3.x = screenX;
        vector3.y = screenY;
        vector3.z = 0;
        camera.unproject(vector3);
        int len = widgets.size();
        for (int i = 0; i < len; i++) {
            Widget widget = widgets.get(i);
            if (widget.contains(vector3.x, vector3.y)) {
                setSelectedWidget(widget);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        vector3.x = screenX;
        vector3.y = screenY;
        vector3.z = 0;
        camera.unproject(vector3);
        int len = widgets.size();
        for (int i = 0; i < len; i++) {
            Widget widget = widgets.get(i);
            if (widget.contains(vector3.x, vector3.y)) {
                setSelectedWidget(widget);
                widget.fireEvent(Widget.Event.FIRE1_DOWN);
            }
        }
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        vector3.x = screenX;
        vector3.y = screenY;
        vector3.z = 0;
        camera.unproject(vector3);
        int len = widgets.size();
        for (int i = 0; i < len; i++) {
            Widget widget = widgets.get(i);
            if (widget.contains(vector3.x, vector3.y)) {
                widget.fireEvent(Widget.Event.FIRE1_UP);
            }
        }
        return true;
    }

    @Override
    public boolean keyDown(int keycode) {
        switch (keycode) {
            case Input.Keys.BACK:
                onKeyBack();
                return true;
        }
        return false;
    }

    protected void onKeyBack() {
    }

    @Override
    public void dispose() {
        Gdx.app.debug(this.getClass().getSimpleName(), "dispose");
    }

    @Override
    public void hide() {
        Gdx.app.debug(this.getClass().getSimpleName(), "hide");
        if (assetsLoaded) {
            unloadAssets();
        }
        if (catchBackKey) {
            Gdx.input.setCatchKey(Input.Keys.BACK, false);
        }
    }

    @Override
    public void pause() {
        Gdx.app.debug(this.getClass().getSimpleName(), "pause");
        unloadAssets();
        paused = true;
    }

    protected void unloadAssets() {
        Gdx.app.debug(this.getClass().getSimpleName(), "unloadAssets");
        if (background != null) {
            assetManager.unload(background);
        }
        assetsLoaded = false;
    }

    @Override
    public void render(float deltaTime) {
        if (paused) return;

        if (GLGame.inputConfigurationChanged) {
            game.reloadInputDevices();
            GLGame.inputConfigurationChanged = false;
        }

        updateMenuMusic();

        for (InputDevice inputDevice : game.inputDevices) {
            inputDevice.update();
        }

        game.menuInput.read(this);

        // update
        int len = widgets.size();
        for (int i = 0; i < len; i++) {
            Widget widget = widgets.get(i);
            if (widget.getDirty()) {
                widget.refresh();
            }
            widget.setDirty(false);
        }

        widgetEvent = game.menuInput.getWidgetEvent();

        if (widgetEvent != null && selectedWidget != null) {
            selectedWidget.fireEvent(widgetEvent);
        }

        if (!assetsLoaded) return;

        // render
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.setToOrtho(true, gui.screenWidth, gui.screenHeight);
        camera.translate(-gui.originX, -gui.originY);
        camera.update();

        batch.setProjectionMatrix(camera.combined);
        batch.setColor(0xFFFFFF, 1f);

        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.setColor(0xFFFFFF, 1f);

        if (background != null) {
            batch.begin();
            batch.draw(backgroundTexture, 0, 0, gui.WIDTH, gui.HEIGHT, 0, 0, 512, 512, false, true);
            batch.end();
        }

        len = widgets.size();
        for (int i = 0; i < len; i++) {
            widgets.get(i).render(batch, shapeRenderer);
        }

        if (game.menuMusic.isPlaying()) {
            String s = "" + (char) (16 + (int) (Gdx.graphics.getFrameId() % 24) / 6);
            batch.begin();
            game.font10.draw(batch, s, 8, gui.HEIGHT - 20, Font.Align.LEFT);
            batch.end();
        }
    }

    public Widget getSelectedWidget() {
        return selectedWidget;
    }

    public boolean setSelectedWidget(Widget widget) {
        if (widget == null || widget == selectedWidget || !widget.visible || !widget.active) {
            return false;
        }
        if (selectedWidget != null) {
            if (selectedWidget.entryMode) {
                return false;
            }
            selectedWidget.setSelected(false);
        }
        selectedWidget = widget;
        selectedWidget.setSelected(true);
        return true;
    }

    protected void refreshAllWidgets() {
        for (Widget widget : widgets) {
            widget.setDirty(true);
        }
    }

    @Override
    public void resize(int width, int height) {
        Gdx.app.debug(this.getClass().getSimpleName(), "resize");
        gui.resize(width, height);
    }

    @Override
    public void resume() {
        Gdx.app.debug(this.getClass().getSimpleName(), "resume");
        loadAssets();
        assetManager.finishLoading();
        getAssets();
        refreshAllWidgets();
        paused = false;
    }

    @Override
    public void show() {
        Gdx.app.debug(this.getClass().getSimpleName(), "show");
        loadAssets();
        assetManager.finishLoading();
        Gdx.app.debug(this.getClass().getSimpleName(), "finish loading");
        getAssets();
        Gdx.input.setInputProcessor(this);
        if (catchBackKey) {
            Gdx.input.setCatchKey(Input.Keys.BACK, true);
        }
    }

    protected void loadAssets() {
        Gdx.app.debug(this.getClass().getSimpleName(), "loadAssets");
        if (background != null) {
            assetManager.load(background, Texture.class);
        }
        assetsLoaded = true;
    }

    protected void getAssets() {
        Gdx.app.debug(this.getClass().getSimpleName(), "getAssets");
        if (background != null) {
            backgroundTexture = assetManager.get(background, Texture.class);
        }
    }

    private void updateMenuMusic() {
        int volume = (int) (100 * game.menuMusic.getVolume());
        int target = playMenuMusic ? game.settings.musicVolume : 0;
        if (volume != target) {
            volume += 10 * EMath.sgn(target - volume);
            game.menuMusic.setVolume(volume / 100f);
        }

        if (game.menuMusic.isPlaying()) {
            if (volume == 0) {
                game.menuMusic.pause();
            }
        } else if (target > 0) {
            game.menuMusic.play();
        }
    }
}
