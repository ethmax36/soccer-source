package com.ysoccer.android.framework;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class GLShapeRenderer extends ShapeRenderer {

    private GLGraphics graphics;

    GLShapeRenderer(GLGraphics graphics) {
        this.graphics = graphics;
    }

    public void setColor(int rgb, float alpha) {
        setColor(graphics.getLight() * GLColor.red(rgb) / 65025f, graphics.getLight() * GLColor.green(rgb) / 65025f, graphics.getLight() * GLColor.blue(rgb) / 65025f, alpha);
    }
}
