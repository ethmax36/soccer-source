package com.ysoccer.android.framework;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;

import java.util.ArrayList;
import java.util.List;

public class Touch extends InputDevice {

    private final int CAMERA_WIDTH = 1024;
    private final int CAMERA_HEIGHT = 576;

    private final int JOYSTICK_R = 64;
    private final int JOYSTICK_DEFAULT_X = 30 + JOYSTICK_R;
    private final int JOYSTICK_DEFAULT_Y = CAMERA_HEIGHT - JOYSTICK_R - 30;

    private final int BUTTON_R = 64;
    private final int BUTTON_DEFAULT_X = CAMERA_WIDTH - BUTTON_R - 30;
    private final int BUTTON_DEFAULT_Y = CAMERA_HEIGHT - BUTTON_R - 30;

    private boolean joystickHold = false;
    private final Vector2 joystickPosition = new Vector2(JOYSTICK_DEFAULT_X, JOYSTICK_DEFAULT_Y);
    private final Vector2 joystickVelocity = new Vector2();
    private final Vector2 joystickTarget = new Vector2(JOYSTICK_DEFAULT_X, JOYSTICK_DEFAULT_Y);


    private boolean button1Hold = false;
    private final Vector2 button1Position = new Vector2(BUTTON_DEFAULT_X, BUTTON_DEFAULT_Y);
    private final Vector2 button1Velocity = new Vector2();
    private final Vector2 button1Target = new Vector2(BUTTON_DEFAULT_X, BUTTON_DEFAULT_Y);


    private final OrthographicCamera touchCam = new OrthographicCamera(CAMERA_WIDTH, CAMERA_HEIGHT);
    private final Vector3 vector3 = new Vector3();
    private final Vector2 touchPoint = new Vector2();
    private final Vector2 joystickDirection = new Vector2();
    private final List<TouchEvent> touchEvents = new ArrayList<>();

    private boolean f1;
    private boolean f2;
    private boolean v;
    private int a;

    private final TextureRegion[] joystickRegions = new TextureRegion[4];

    Touch() {
        super(Type.TOUCH, 0);

        touchCam.setToOrtho(true);
        touchCam.update();
    }

    @Override
    void read() {
        for (TouchEvent event : touchEvents) {
            touchPoint.set(event.x, event.y);

            // Joystick
            if (touchPoint.x < CAMERA_WIDTH / 2f) {

                float touchJoystickDist;
                switch (event.type) {

                    case TOUCH_DOWN:
                        touchJoystickDist = touchPoint.dst(joystickPosition);
                        v = false;
                        if (touchJoystickDist < JOYSTICK_R) {
                            joystickHold = true;
                            if (touchJoystickDist > 0.25f * JOYSTICK_R) {
                                joystickDirection.set(joystickPosition);
                                joystickDirection.sub(touchPoint);
                                joystickDirection.rotate(180);
                                a = Math.round(joystickDirection.angle());
                                v = true;
                            }
                        }
                        break;

                    case TOUCH_DRAGGED:
                        if (!joystickHold) continue;

                        touchJoystickDist = touchPoint.dst(joystickPosition);
                        joystickDirection.set(joystickPosition);
                        joystickDirection.sub(touchPoint);

                        if (touchJoystickDist > 2 * JOYSTICK_R) {
                            joystickDirection.setLength(JOYSTICK_R);
                            joystickTarget.set(touchPoint).add(joystickDirection);
                            joystickTarget.x = EMath.clamp(joystickTarget.x, JOYSTICK_DEFAULT_X, CAMERA_WIDTH / 3f - JOYSTICK_R);
                            joystickTarget.y = EMath.clamp(joystickTarget.y, CAMERA_HEIGHT / 2f + JOYSTICK_R / 2f, JOYSTICK_DEFAULT_Y);
                        }

                        v = false;
                        if (touchJoystickDist > 0.25f * JOYSTICK_R) {
                            joystickDirection.rotate(180);
                            a = Math.round(joystickDirection.angle());
                            v = true;
                        }
                        break;

                    case TOUCH_UP:
                        joystickHold = false;
                        v = false;
                        break;
                }
            }

            // button 1
            else {
                switch (event.type) {

                    case TOUCH_DOWN:
                        float touchButtonDist = EMath.dist(touchPoint.x, touchPoint.y, button1Position.x, button1Position.y);
                        button1Hold = touchButtonDist < BUTTON_R;
                        f1 = touchButtonDist < BUTTON_R;
                        break;

                    case TOUCH_DRAGGED:
                        if (button1Hold) {
                            button1Target.set(touchPoint);
                            button1Target.x = EMath.clamp(button1Target.x, BUTTON_DEFAULT_X - 2 * BUTTON_R, BUTTON_DEFAULT_X);
                            button1Target.y = EMath.clamp(button1Target.y, BUTTON_DEFAULT_Y - 2 * BUTTON_R, BUTTON_DEFAULT_Y);
                        }
                        break;

                    case TOUCH_UP:
                        button1Hold = false;
                        f1 = false;
                        break;
                }
            }
        }

        touchEvents.clear();

        // update input
        x0 = v ? Math.round(EMath.cos((a / 45.0f) * 45)) : 0;
        y0 = v ? Math.round(EMath.sin((a / 45.0f) * 45)) : 0;
        fire10 = f1;
        fire20 = f2;

        // update joystick position
        if (!joystickHold) {
            joystickTarget.set(JOYSTICK_DEFAULT_X, JOYSTICK_DEFAULT_Y);
        }
        joystickVelocity.set(joystickTarget);
        joystickVelocity.sub(joystickPosition);
        if (joystickVelocity.len() > 1) {
            if (joystickVelocity.len() > 8) {
                joystickVelocity.setLength(8);
            }
            joystickPosition.add(joystickVelocity);
        }

        // update button position
        button1Velocity.set(button1Target);
        button1Velocity.sub(button1Position);
        if (button1Velocity.len() > 1) {
            if (button1Velocity.len() > 8) {
                button1Velocity.setLength(8);
            }
            button1Position.add(button1Velocity);
        }
    }

    public void addTouchEvent(TouchEvent.Type type, int screenX, int screenY) {
        vector3.x = screenX;
        vector3.y = screenY;
        vector3.z = 0;
        touchCam.unproject(vector3);

        TouchEvent event = new TouchEvent();
        event.type = type;
        event.x = (int) vector3.x;
        event.y = (int) vector3.y;
        touchEvents.add(event);
    }

    public static class TouchEvent {

        public enum Type {TOUCH_DOWN, TOUCH_UP, TOUCH_DRAGGED}

        public Type type;
        public int x, y;
        public int pointer;
    }

    public void render(GLSpriteBatch batch) {
        touchCam.setToOrtho(true, CAMERA_WIDTH, CAMERA_HEIGHT);
        touchCam.update();

        batch.setProjectionMatrix(touchCam.combined);
        batch.setColor(0xFFFFFF, 1f);

        batch.begin();
        batch.draw(joystickRegions[0],
                joystickPosition.x - JOYSTICK_R,
                joystickPosition.y - JOYSTICK_R,
                128, 128
        );
        batch.draw(joystickRegions[1],
                joystickPosition.x + ((value ? EMath.cos(angle) : 0) - 2) * JOYSTICK_R / 2,
                joystickPosition.y + ((value ? EMath.sin(angle) : 0) - 2) * JOYSTICK_R / 2,
                128, 128
        );
        batch.draw(joystickRegions[2],
                button1Position.x - BUTTON_R,
                button1Position.y - BUTTON_R,
                128, 128
        );
        batch.draw(joystickRegions[3],
                button1Position.x - BUTTON_R,
                button1Position.y - BUTTON_R,
                128, 128
        );

        batch.end();
    }

    public void loadAssets(AssetManager assetManager) {
        assetManager.load("images/joystick.png", Texture.class);
    }

    public void getAssets(AssetManager assetManager) {
        Texture texture = assetManager.get("images/joystick.png");
        for (int i = 0; i < 4; i++) {
            joystickRegions[i] = new TextureRegion(
                    texture,
                    128 * EMath.floor(i / 2f), 128 * (i % 2),
                    128, 128
            );
        }
    }

    public void unloadAssets(AssetManager assetManager) {
        assetManager.unload("images/joystick.png");
    }
}
