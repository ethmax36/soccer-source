package com.ysoccer.android.framework;

public class RgbPair {

    int rgbOld;
    int rgbNew;

    public RgbPair(int rgbOld, int rgbNew) {
        this.rgbOld = rgbOld;
        this.rgbNew = rgbNew;
    }
}
