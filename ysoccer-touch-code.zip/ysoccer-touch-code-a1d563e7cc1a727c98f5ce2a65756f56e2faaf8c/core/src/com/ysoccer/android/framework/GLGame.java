package com.ysoccer.android.framework;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.resolvers.InternalFileHandleResolver;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.controllers.Controller;
import com.badlogic.gdx.controllers.Controllers;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.I18NBundle;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonWriter;
import com.ysoccer.android.competitions.Competition;
import com.ysoccer.android.competitions.Cup;
import com.ysoccer.android.gui.Gui;
import com.ysoccer.android.match.Tactics;

import java.util.ArrayList;
import java.util.MissingResourceException;

import static com.ysoccer.android.framework.GLGame.State.COMPETITION;

public class GLGame extends Game {

    public static final int SUBFRAMES = 8;
    public static final int VIRTUAL_REFRESH_RATE = 64;
    public static final int SUBFRAMES_PER_SECOND = VIRTUAL_REFRESH_RATE * SUBFRAMES;
    public static final float SUBFRAME_DURATION = 1.0f / SUBFRAMES_PER_SECOND;

    private final String I18N_FILE = "i18n/strings";
    private final String FONT_14_FILE = "images/font_14.png";
    private final String FONT_10_FILE = "images/font_10.png";
    private final String CURSOR_FILE = "images/cursor.png";
    private final String GUI_ATLAS_FILE = "images/gui.atlas";
    private final String MENU_MUSIC_FILE = "music/menu.ogg";
    private final String SAVEGAME_FILE = "data/saves/competitions/savegame.json";

    public Settings settings;
    public AssetManager assetManager;
    public GLGraphics glGraphics;
    private I18NBundle strings;
    private Gui gui;
    public Font font14;
    public Font font10;
    private Pixmap cursor;
    public TextureAtlas guiAtlas;
    public static Json json;
    public InputDeviceList inputDevices;
    public static boolean inputConfigurationChanged;
    public int preferredInputDevice;
    public Touch touchInput;
    public MenuInput menuInput;
    Music menuMusic;

    public enum State {
        NONE, FRIENDLY, COMPETITION
    }

    private State state;
    public int stateColor;

    public Competition competition;

    @Override
    public void create() {
        Gdx.app.debug(this.getClass().getSimpleName(), "create");
        settings = new Settings();
        assetManager = new AssetManager();
        assetManager.setLoader(String.class, new StringLoader(new InternalFileHandleResolver()));
        glGraphics = new GLGraphics();
        gui = new Gui();
        font14 = new Font(14, 16, 23, 16, 22);
        font10 = new Font(10, 13, 17, 12, 16);
        loadAssets();
        assetManager.finishLoading();
        getAssets();
        Tactics.load();

        state = State.NONE;

        json = new Json();
        json.addClassTag("CUP", Cup.class);
        json.setOutputType(JsonWriter.OutputType.json);
        json.setUsePrototypes(false);

        inputDevices = new InputDeviceList();
        reloadInputDevices();

        menuInput = new MenuInput(this);

        restoreSaveGame();
    }

    private void loadAssets() {
        assetManager.load(I18N_FILE, I18NBundle.class);
        assetManager.load(FONT_14_FILE, Texture.class);
        assetManager.load(FONT_10_FILE, Texture.class);
        assetManager.load(CURSOR_FILE, Pixmap.class);
        assetManager.load(GUI_ATLAS_FILE, TextureAtlas.class);
        assetManager.load(MENU_MUSIC_FILE, Music.class);
    }

    private void getAssets() {
        strings = assetManager.get(I18N_FILE);

        Texture texture = assetManager.get(FONT_14_FILE);
        font14.setTexture(texture);

        texture = assetManager.get(FONT_10_FILE);
        font10.setTexture(texture);

        cursor = assetManager.get(CURSOR_FILE);
        Gdx.graphics.setCursor(Gdx.graphics.newCursor(cursor, 0, 0));

        guiAtlas = assetManager.get(GUI_ATLAS_FILE);
        gui.setTextures(guiAtlas);

        menuMusic = assetManager.get(MENU_MUSIC_FILE);
        menuMusic.setLooping(true);
        menuMusic.setVolume(0);
    }

    @Override
    public void dispose() {
        Gdx.app.debug(this.getClass().getSimpleName(), "dispose");
        super.dispose();
        glGraphics.dispose();
        assetManager.dispose();
        createSaveGame();
    }

    private void createSaveGame() {
        FileHandle fileHandle = Gdx.files.local(SAVEGAME_FILE);
        if (hasCompetition()) {
            competition.save(fileHandle);
        } else if (fileHandle.exists()) {
            fileHandle.delete();
        }
    }

    private void restoreSaveGame() {
        FileHandle fileHandle = Gdx.files.local(SAVEGAME_FILE);
        if (fileHandle.exists()) {
            Competition competition = Competition.load(fileHandle);
            setCompetition(competition);
            setState(COMPETITION);
        }
    }

    @Override
    public void pause() {
        Gdx.app.debug(this.getClass().getSimpleName(), "pause");
        super.pause();
        unloadAssets();
    }

    private void unloadAssets() {
        assetManager.unload(MENU_MUSIC_FILE);
        assetManager.unload(GUI_ATLAS_FILE);
        assetManager.unload(CURSOR_FILE);
        assetManager.unload(FONT_10_FILE);
        assetManager.unload(FONT_14_FILE);
        assetManager.unload(I18N_FILE);
    }

    @Override
    public void resume() {
        Gdx.app.debug(this.getClass().getSimpleName(), "resume");
        loadAssets();
        assetManager.finishLoading();
        getAssets();
        super.resume();
    }

    @Override
    public void resize(int width, int height) {
        Gdx.app.debug(this.getClass().getSimpleName(), "resize");
        super.resize(width, height);
    }

    public void setState(State state) {

        this.state = state;

        switch (state) {
            case COMPETITION:
                stateColor = 0x415600;
                break;

            case FRIENDLY:
                stateColor = 0x2D855D;
                break;
        }
    }

    public boolean hasCompetition() {
        return competition != null;
    }

    public void setCompetition(Competition competition) {
        this.competition = competition;
    }

    public void clearCompetition() {
        this.competition = null;
    }

    public void reloadInputDevices() {
        inputDevices.clear();

        // joysticks
        int port = 0;
        for (Controller controller : Controllers.getControllers()) {
            JoystickConfig joystickConfig = settings.getJoystickConfigByName(controller.getName());
            if (joystickConfig != null) {
                inputDevices.add(new Joystick(controller, joystickConfig, port));
                port++;
            }
        }

        // keyboard
        if (Gdx.input.isPeripheralAvailable(Input.Peripheral.HardwareKeyboard)) {
            ArrayList<KeyboardConfig> keyboardConfigs = settings.getKeyboardConfigs();
            inputDevices.add(new Keyboard(0, keyboardConfigs.get(0)));
        }

        // touch
        touchInput = new Touch();
        inputDevices.add(touchInput);
    }

    AssetManager getAssetManager() {
        return assetManager;
    }

    GLGraphics getGlGraphics() {
        return glGraphics;
    }

    GLSpriteBatch getBatch() {
        return glGraphics.getBatch();
    }

    GLShapeRenderer getShapeRenderer() {
        return glGraphics.getShapeRenderer();
    }

    OrthographicCamera getCamera() {
        return glGraphics.getCamera();
    }

    Gui getGui() {
        return gui;
    }

    public String gettext(String label) {
        try {
            return strings.get(label);
        } catch (MissingResourceException e) {
            return label;
        }
    }

    public enum LogType {
        AI_ATTACKING,
        AI_KICKING,
        BALL,
        GUI,
        PASSING,
        PLAYER_SELECTION
    }

    public static void debug(LogType type, Object Object, String message) {
        debug(type, Object.getClass().getSimpleName(), message);
    }

    public static void debug(LogType type, String tag, String message) {
        if (Settings.development && isSetLogFilter(type)) {
            Gdx.app.debug(tag, message);
        }
    }

    public static boolean isSetLogFilter(LogType type) {
        return (type == null) || (Settings.logFilter & (1 << type.ordinal())) != 0;
    }
}
