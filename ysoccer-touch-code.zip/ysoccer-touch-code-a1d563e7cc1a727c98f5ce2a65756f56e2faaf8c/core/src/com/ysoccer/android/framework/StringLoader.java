package com.ysoccer.android.framework;

import com.badlogic.gdx.assets.AssetDescriptor;
import com.badlogic.gdx.assets.AssetLoaderParameters;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.AsynchronousAssetLoader;
import com.badlogic.gdx.assets.loaders.FileHandleResolver;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.Array;

public class StringLoader extends AsynchronousAssetLoader<String, StringLoader.StringParameter> {

    private String string;

    public StringLoader(FileHandleResolver resolver) {
        super(resolver);
    }

    /**
     * Returns the {@link String} instance currently loaded by this
     * {@link StringLoader}.
     *
     * @return the currently loaded {@link String}, otherwise {@code null} if
     * no {@link String} has been loaded yet.
     */
    protected String getLoadedString() {
        return string;
    }

    @Override
    public void loadAsync(AssetManager manager, String fileName, FileHandle file, StringParameter parameter) {
        string = file.readString("UTF-8");
    }

    @Override
    public String loadSync(AssetManager manager, String fileName, FileHandle file, StringParameter parameter) {
        String string = this.string;
        this.string = null;
        return string;
    }

    @Override
    public Array<AssetDescriptor> getDependencies(String fileName, FileHandle file, StringParameter parameter) {
        return null;
    }

    static public class StringParameter extends AssetLoaderParameters<String> {
    }
}
