package com.ysoccer.android.util;

import com.badlogic.gdx.files.FileHandle;

import java.io.File;
import java.io.FilenameFilter;

public class Constants {

    public static final float VIEWPORT_WIDTH = 36.0f;
    public static final float VIEWPORT_HEIGHT = 20.0f;

    public static final int GUI_WIDTH = 960;
    public static final int GUI_HEIGHT = 540;

    public static final String MENU_MAIN = "images/backgrounds/menu_main.jpg";
    public static final String LOGO = "images/logo.png";

    public static final String teamsRootFolder = "data/teams/";
    public static final String competitionsFolder = "data/competitions/";

    public static String getRelativeTeamPath(FileHandle fileHandle) {
        return fileHandle.path().replaceFirst(teamsRootFolder, "");
    }

    public static FilenameFilter teamFilenameFilter = new FilenameFilter() {
        public boolean accept(File dir, String name) {
            return name.startsWith("team.");
        }
    };
}
