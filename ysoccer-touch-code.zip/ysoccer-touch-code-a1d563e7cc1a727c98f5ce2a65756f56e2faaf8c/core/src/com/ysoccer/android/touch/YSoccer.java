package com.ysoccer.android.touch;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.ysoccer.android.framework.GLGame;
import com.ysoccer.android.screens.Main;

public class YSoccer extends GLGame {

    @Override
    public void create() {
        Gdx.app.setLogLevel(Application.LOG_DEBUG);
        super.create();
        setScreen(new Main(this));
    }
}
